"""US National Weather Service alerts (free, no key, US locations only)."""

from strands import tool

from weather_agent.clients.http import UpstreamError, get_json
from weather_agent.config import get_settings


@tool
def get_weather_alerts(latitude: float, longitude: float) -> dict:
    """Get active official weather alerts (warnings, watches) for a US location.

    Args:
        latitude: Latitude in decimal degrees (must be inside the United States).
        longitude: Longitude in decimal degrees.
    """
    s = get_settings()
    try:
        data = get_json(
            s.nws_alerts_url,
            {"point": f"{latitude:.4f},{longitude:.4f}"},
            headers={"User-Agent": s.nws_user_agent, "Accept": "application/geo+json"},
        )
    except UpstreamError as e:
        return {"error": f"{e} (note: NWS only covers US locations)"}
    alerts = [
        {
            "event": f["properties"].get("event"),
            "severity": f["properties"].get("severity"),
            "headline": f["properties"].get("headline"),
            "expires": f["properties"].get("expires"),
        }
        for f in data.get("features", [])[:5]
    ]
    return {"active_alert_count": len(alerts), "alerts": alerts}
