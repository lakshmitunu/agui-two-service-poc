#!/usr/bin/env bash
# Build and start the stack (agent + OTel collector + Jaeger) in Docker, then wait until healthy.
set -euo pipefail
cd "$(dirname "$0")/.."

command -v docker >/dev/null || { echo "docker not found"; exit 1; }
docker info >/dev/null 2>&1 || { echo "Docker daemon is not running"; exit 1; }

if [[ ! -f .env ]]; then
  cp .env.example .env
  echo "Created .env from .env.example (LLM_PROVIDER=stub: works without an API key)."
fi

docker compose up -d --build

echo -n "Waiting for http://localhost:8000/healthz "
for _ in $(seq 1 40); do
  if curl -fsS http://localhost:8000/healthz >/dev/null 2>&1; then
    echo " OK"
    echo "API:    http://localhost:8000/docs"
    echo "Jaeger: http://localhost:16686  (service: strands-weather-agent)"
    echo "Logs:   docker compose logs -f agent"
    exit 0
  fi
  echo -n "."; sleep 1
done
echo " FAILED"; docker compose logs --tail=50 agent; exit 1
