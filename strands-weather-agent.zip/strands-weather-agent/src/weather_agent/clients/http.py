"""Shared HTTP helper for weather APIs: timeout, retries on transport errors, errors as data."""

from typing import Any

import httpx

from weather_agent.config import get_settings
from weather_agent.observability.logging import get_logger

log = get_logger()


class UpstreamError(Exception):
    """Raised for any upstream weather API failure; message is safe to show the model."""


def get_json(url: str, params: dict[str, Any], headers: dict[str, str] | None = None) -> dict:
    s = get_settings()
    transport = httpx.HTTPTransport(retries=2)  # connection-level retries only
    try:
        with httpx.Client(timeout=s.http_timeout_seconds, transport=transport, headers=headers) as client:
            resp = client.get(url, params=params)
            resp.raise_for_status()
            return resp.json()
    except httpx.HTTPStatusError as e:
        log.warning("weather_api.http_error", url=url, status=e.response.status_code)
        raise UpstreamError(f"weather API returned HTTP {e.response.status_code}") from e
    except httpx.HTTPError as e:
        log.warning("weather_api.transport_error", url=url, error=type(e).__name__)
        raise UpstreamError(f"weather API unreachable ({type(e).__name__})") from e
