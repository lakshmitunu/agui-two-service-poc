# Curated Output Verification

## Input

For a supplied `run_id`, the verification reads:

```text
s3://vsf-parent-insights-curated/daily-communication/run_id=<run-id>/data/
s3://vsf-parent-insights-curated/daily-communication-quarantine/run_id=<run-id>/data/
s3://vsf-parent-insights-curated/daily-communication-validation/run_id=<run-id>/summary.json
s3://vsf-parent-insights-raw/daily-communication/history/run_id=<run-id>/manifest.json
s3://vsf-parent-insights-raw/daily-communication/history/run_id=<run-id>/part-*.jsonl.gz
```

## What it does

The shell script:

1. verifies the AWS identity and required S3 prefixes;
2. creates an isolated Python virtual environment;
3. installs the pinned `pyarrow==25.0.1` reader;
4. downloads summary, manifest, raw parts, curated Parquet, and quarantine Parquet to a temporary directory;
5. validates summary count reconciliation;
6. validates curated and quarantine schemas;
7. reads the actual Parquet rows;
8. validates row counts, profile counts, rows per profile, date range, and duplicate keys;
9. verifies Snappy compression;
10. recalculates raw-part sizes and SHA-256 hashes against the manifest;
11. prints five curated sample records;
12. removes the temporary download directory on exit.

The script reads AWS data but does not modify it.

## Output

Successful execution prints:

```text
VERIFICATION PASSED
Curated rows: 600
Quarantine rows: 0
Profiles: 10
Rows per profile: 60
Date range: 2026-04-06 through 2026-06-04
Compression: SNAPPY
Raw checksums: matched
```

Any failed check is listed and the script exits with a nonzero status.

## Flow

```mermaid
flowchart TD
    A["run_id + AWS profile"] --> B["Verify AWS identity"]
    B --> C["Create isolated Python environment"]
    C --> D["Install pinned PyArrow"]
    D --> E["Download summary, manifest,<br/>raw and Parquet files"]
    E --> F["Read binary Parquet"]
    F --> G["Validate schemas, counts,<br/>dates, profiles and duplicates"]
    G --> H["Validate Snappy compression"]
    H --> I["Recalculate raw size<br/>and SHA-256"]
    I --> J{"Every check passes?"}
    J -- Yes --> K["Print samples and<br/>VERIFICATION PASSED"]
    J -- No --> L["Print failures and<br/>exit nonzero"]
```

## Command

From the project root:

```bash
cd /Volumes/work/codex_projects/parent_insights
bash ./phase1b-data-preparation/verify_curated_output.sh \
  --run-id 20260830T055411Z
```

The defaults are:

```text
AWS profile:              parent-insights-personal
AWS region:               us-east-2
Expected profiles:        10
Expected days per profile: 60
Expected start date:      2026-04-06
Expected end date:        2026-06-04
```

The first run downloads and installs PyArrow. Later runs reuse the isolated virtual environment.

