"""Tiny mock of POST /{domain}/chat/stream for trying the playground without a real agent."""
import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get("content-length", 0))) or b"{}")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Transfer-Encoding", "chunked")
        self.end_headers()
        time.sleep(2)  # show the dancing dots
        text = f"[{self.path}] session={body.get('session_id')} you asked: {body.get('question')}. This is a streamed mock reply, word by word."
        for word in text.split(" "):
            data = (word + " ").encode()
            self.wfile.write(f"{len(data):x}\r\n".encode() + data + b"\r\n")
            self.wfile.flush()
            time.sleep(0.12)
        self.wfile.write(b"0\r\n\r\n")


ThreadingHTTPServer(("127.0.0.1", 8081), Handler).serve_forever()
