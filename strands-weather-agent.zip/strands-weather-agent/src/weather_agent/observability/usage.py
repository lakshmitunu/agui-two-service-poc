"""Token usage + cost accounting.

Anthropic reports four disjoint token buckets per call:
  input_tokens                 - uncached input (billed at the base rate)
  cache_creation_input_tokens  - written to cache this call (base * cache_write_multiplier)
  cache_read_input_tokens      - served from cache (base * cache_read_multiplier)
  output_tokens                - generated (output rate)
Strands exposes them as inputTokens / cacheWriteInputTokens / cacheReadInputTokens / outputTokens.
"""

from dataclasses import asdict, dataclass

from weather_agent.config import Settings


@dataclass
class Cost:
    input_usd: float = 0.0
    output_usd: float = 0.0
    cache_write_usd: float = 0.0
    cache_read_usd: float = 0.0
    total_usd: float = 0.0
    # What the same tokens would have cost with no caching at all (everything at base input rate).
    uncached_equivalent_usd: float = 0.0


@dataclass
class TokenUsage:
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0

    @classmethod
    def from_strands(cls, usage: dict) -> "TokenUsage":
        return cls(
            input_tokens=int(usage.get("inputTokens", 0) or 0),
            output_tokens=int(usage.get("outputTokens", 0) or 0),
            cache_read_tokens=int(usage.get("cacheReadInputTokens", 0) or 0),
            cache_write_tokens=int(usage.get("cacheWriteInputTokens", 0) or 0),
        )

    @property
    def total_input_tokens(self) -> int:
        return self.input_tokens + self.cache_read_tokens + self.cache_write_tokens

    @property
    def cache_hit_ratio(self) -> float:
        total = self.total_input_tokens
        return round(self.cache_read_tokens / total, 4) if total else 0.0


def compute_cost(tokens: TokenUsage, s: Settings) -> Cost:
    per_tok_in = s.price_input_per_mtok / 1_000_000
    per_tok_out = s.price_output_per_mtok / 1_000_000
    c = Cost(
        input_usd=tokens.input_tokens * per_tok_in,
        output_usd=tokens.output_tokens * per_tok_out,
        cache_write_usd=tokens.cache_write_tokens * per_tok_in * s.cache_write_multiplier,
        cache_read_usd=tokens.cache_read_tokens * per_tok_in * s.cache_read_multiplier,
        uncached_equivalent_usd=tokens.total_input_tokens * per_tok_in + tokens.output_tokens * per_tok_out,
    )
    c.total_usd = c.input_usd + c.output_usd + c.cache_write_usd + c.cache_read_usd
    return Cost(**{k: round(v, 8) for k, v in asdict(c).items()})
