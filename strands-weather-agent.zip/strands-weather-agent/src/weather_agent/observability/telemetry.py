"""OpenTelemetry setup. Strands emits agent / model-call / tool spans (GenAI semantic conventions);
we only configure where they are exported."""

import os

from weather_agent.config import Settings
from weather_agent.observability.logging import get_logger

log = get_logger()


def setup_telemetry(settings: Settings) -> bool:
    if not settings.otel_enabled:
        log.info("otel.disabled")
        return False

    # The OTel SDK reads these env vars itself.
    os.environ.setdefault("OTEL_SERVICE_NAME", settings.otel_service_name)
    if settings.otel_exporter_otlp_endpoint:
        os.environ.setdefault("OTEL_EXPORTER_OTLP_ENDPOINT", settings.otel_exporter_otlp_endpoint)

    from strands.telemetry import StrandsTelemetry

    telemetry = StrandsTelemetry()  # creates + registers the global TracerProvider
    exporters = []
    if settings.otel_exporter_otlp_endpoint:
        telemetry.setup_otlp_exporter()  # OTLP/HTTP -> collector -> Jaeger
        exporters.append(f"otlp:{settings.otel_exporter_otlp_endpoint}")
    if settings.otel_console_exporter:
        telemetry.setup_console_exporter()
        exporters.append("console")
    log.info("otel.enabled", exporters=exporters, service=settings.otel_service_name)
    return True
