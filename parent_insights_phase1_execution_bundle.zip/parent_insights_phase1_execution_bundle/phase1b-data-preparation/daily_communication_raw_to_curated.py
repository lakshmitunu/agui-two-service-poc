#!/usr/bin/env python3
"""Validate and curate daily communication history with AWS Glue."""

import hashlib
import json
import re
import sys
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


PART_NAME_PATTERN = re.compile(r"part-[0-9]{5}\.jsonl\.gz")
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}")
SUPPORTED_SCHEMA_VERSION = "1.0"
CONTRACT_FIELDS = (
    "childProfileId",
    "aggDate",
    "timezone",
    "communicationStatus",
    "callCount",
    "textCount",
    "nightCount",
    "nightStartTime",
    "nightEndTime",
    "schoolCount",
    "schoolStartTime",
    "schoolEndTime",
)
INTEGER_FIELDS = (
    "childProfileId",
    "callCount",
    "textCount",
    "nightCount",
    "schoolCount",
)
STRING_FIELDS = tuple(field for field in CONTRACT_FIELDS if field not in INTEGER_FIELDS)
COUNT_FIELDS = ("callCount", "textCount", "nightCount", "schoolCount")
TIME_FIELDS = ("nightStartTime", "nightEndTime", "schoolStartTime", "schoolEndTime")
DATE_PATTERN = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
TIME_PATTERN = re.compile(r"(?:[01][0-9]|2[0-3]):[0-5][0-9]")
TIMEZONE_PATTERN = re.compile(r"[A-Za-z_+-]+(?:/[A-Za-z0-9_+-]+)+")


class PreflightError(RuntimeError):
    """Raised when a raw run is incomplete, inconsistent, or corrupted."""


@dataclass(frozen=True)
class PreflightResult:
    run_id: str
    raw_prefix: str
    manifest: dict[str, Any]
    part_uris: tuple[str, ...]


def require_nonnegative_integer(value: Any, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise PreflightError(f"manifest.{field_name} must be a nonnegative integer")
    return value


def load_json_object(s3_client: Any, bucket: str, key: str) -> dict[str, Any]:
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
    except Exception as exc:
        raise PreflightError(f"Unable to read s3://{bucket}/{key}: {exc}") from exc

    try:
        document = json.loads(response["Body"].read().decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PreflightError(f"s3://{bucket}/{key} is not valid UTF-8 JSON") from exc

    if not isinstance(document, dict):
        raise PreflightError(f"s3://{bucket}/{key} must contain one JSON object")
    return document


def require_object(s3_client: Any, bucket: str, key: str) -> dict[str, Any]:
    try:
        return s3_client.head_object(Bucket=bucket, Key=key)
    except Exception as exc:
        raise PreflightError(f"Required object is missing: s3://{bucket}/{key}") from exc


def sha256_s3_object(s3_client: Any, bucket: str, key: str) -> str:
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        body = response["Body"]
        digest = hashlib.sha256()
        while True:
            chunk = body.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
        return digest.hexdigest()
    except Exception as exc:
        raise PreflightError(f"Unable to checksum s3://{bucket}/{key}: {exc}") from exc


def list_part_names(s3_client: Any, bucket: str, prefix: str) -> set[str]:
    names: set[str] = set()
    continuation_token = None

    while True:
        request = {"Bucket": bucket, "Prefix": prefix}
        if continuation_token:
            request["ContinuationToken"] = continuation_token
        try:
            response = s3_client.list_objects_v2(**request)
        except Exception as exc:
            raise PreflightError(f"Unable to list s3://{bucket}/{prefix}: {exc}") from exc

        for item in response.get("Contents", []):
            key = item["Key"]
            name = key.removeprefix(prefix)
            if "/" not in name and PART_NAME_PATTERN.fullmatch(name):
                names.add(name)

        if not response.get("IsTruncated"):
            return names
        continuation_token = response.get("NextContinuationToken")
        if not continuation_token:
            raise PreflightError("S3 listing was truncated without a continuation token")


def validate_manifest(manifest: dict[str, Any], run_id: str) -> list[dict[str, Any]]:
    if manifest.get("schemaVersion") != SUPPORTED_SCHEMA_VERSION:
        raise PreflightError(
            f"Unsupported manifest.schemaVersion: {manifest.get('schemaVersion')!r}"
        )
    if manifest.get("runId") != run_id:
        raise PreflightError(
            f"manifest.runId {manifest.get('runId')!r} does not match requested run {run_id!r}"
        )
    if manifest.get("status") != "COMPLETE":
        raise PreflightError("manifest.status must be COMPLETE")

    record_count = require_nonnegative_integer(manifest.get("recordCount"), "recordCount")
    file_count = require_nonnegative_integer(manifest.get("fileCount"), "fileCount")
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise PreflightError("manifest.files must be a nonempty array")
    if file_count != len(files):
        raise PreflightError("manifest.fileCount does not equal the number of manifest files")

    seen_names: set[str] = set()
    part_record_total = 0
    for index, part in enumerate(files):
        if not isinstance(part, dict):
            raise PreflightError(f"manifest.files[{index}] must be an object")

        name = part.get("name")
        if not isinstance(name, str) or not PART_NAME_PATTERN.fullmatch(name):
            raise PreflightError(f"Unsafe or invalid manifest part name: {name!r}")
        if name in seen_names:
            raise PreflightError(f"Duplicate manifest part name: {name}")
        seen_names.add(name)

        part_record_total += require_nonnegative_integer(
            part.get("recordCount"), f"files[{index}].recordCount"
        )
        require_nonnegative_integer(
            part.get("compressedBytes"), f"files[{index}].compressedBytes"
        )
        checksum = part.get("sha256")
        if not isinstance(checksum, str) or not SHA256_PATTERN.fullmatch(checksum):
            raise PreflightError(f"manifest.files[{index}].sha256 is invalid")

    if part_record_total != record_count:
        raise PreflightError("Sum of part record counts does not equal manifest.recordCount")
    return files


def preflight_raw_run(s3_client: Any, raw_bucket: str, run_id: str) -> PreflightResult:
    if not re.fullmatch(r"[0-9]{8}T[0-9]{6}Z", run_id):
        raise PreflightError("run_id must use the YYYYMMDDTHHMMSSZ format")
    if not raw_bucket or "/" in raw_bucket:
        raise PreflightError("raw_bucket must be an S3 bucket name, not a path")

    prefix = f"daily-communication/history/run_id={run_id}/"
    require_object(s3_client, raw_bucket, f"{prefix}_SUCCESS")
    manifest = load_json_object(s3_client, raw_bucket, f"{prefix}manifest.json")
    files = validate_manifest(manifest, run_id)

    expected_names = {part["name"] for part in files}
    actual_names = list_part_names(s3_client, raw_bucket, prefix)
    if actual_names != expected_names:
        missing = sorted(expected_names - actual_names)
        unlisted = sorted(actual_names - expected_names)
        raise PreflightError(f"Part-file listing mismatch; missing={missing}, unlisted={unlisted}")

    part_uris = []
    for part in files:
        key = f"{prefix}{part['name']}"
        metadata = require_object(s3_client, raw_bucket, key)
        actual_size = metadata.get("ContentLength")
        if actual_size != part["compressedBytes"]:
            raise PreflightError(
                f"Size mismatch for {part['name']}: expected {part['compressedBytes']}, "
                f"found {actual_size}"
            )

        actual_sha256 = sha256_s3_object(s3_client, raw_bucket, key)
        if actual_sha256 != part["sha256"]:
            raise PreflightError(
                f"SHA-256 mismatch for {part['name']}: expected {part['sha256']}, "
                f"found {actual_sha256}"
            )
        part_uris.append(f"s3://{raw_bucket}/{key}")

    return PreflightResult(
        run_id=run_id,
        raw_prefix=f"s3://{raw_bucket}/{prefix}",
        manifest=manifest,
        part_uris=tuple(part_uris),
    )


def ingest_raw_records(spark: Any, preflight: PreflightResult) -> tuple[Any, int]:
    """Read verified Gzip JSONL parts as raw lines without parsing the JSON."""
    from pyspark.sql import functions as sql_functions

    if not preflight.part_uris:
        raise PreflightError("Preflight returned no part URIs for Spark ingestion")

    raw_records = (
        spark.read.text(list(preflight.part_uris))
        .select(
            sql_functions.col("value").alias("rawRecord"),
            sql_functions.input_file_name().alias("sourceFile"),
        )
        .withColumn(
            "recordFingerprint",
            sql_functions.sha2(sql_functions.col("rawRecord"), 256),
        )
    )

    input_record_count = raw_records.count()
    manifest_record_count = preflight.manifest["recordCount"]
    if input_record_count != manifest_record_count:
        raise PreflightError(
            "Physical input record count does not match the manifest: "
            f"expected {manifest_record_count}, found {input_record_count}"
        )

    return raw_records, input_record_count


def parse_and_validate_structure(raw_record: str) -> tuple[Any, ...]:
    """Strictly parse one JSON object and return typed fields plus failure reasons."""
    values: dict[str, Any] = {field: None for field in CONTRACT_FIELDS}
    reasons: list[str] = []

    try:
        document = json.loads(raw_record)
    except (TypeError, json.JSONDecodeError):
        return tuple(values[field] for field in CONTRACT_FIELDS) + (["MALFORMED_JSON"],)

    if not isinstance(document, dict):
        return tuple(values[field] for field in CONTRACT_FIELDS) + (["MALFORMED_JSON"],)

    for field in CONTRACT_FIELDS:
        if field not in document or document[field] is None:
            reasons.append(f"MISSING_FIELD:{field}")

    for field in sorted(set(document) - set(CONTRACT_FIELDS)):
        reasons.append(f"UNEXPECTED_FIELD:{field}")

    for field in INTEGER_FIELDS:
        raw_value = document.get(field)
        if raw_value is None:
            continue
        if isinstance(raw_value, bool) or not isinstance(raw_value, int):
            reasons.append(f"INVALID_TYPE:{field}")
        else:
            values[field] = raw_value

    for field in STRING_FIELDS:
        raw_value = document.get(field)
        if raw_value is None:
            continue
        if not isinstance(raw_value, str):
            reasons.append(f"INVALID_TYPE:{field}")
        else:
            values[field] = raw_value

    child_profile_id = values["childProfileId"]
    if child_profile_id is not None and child_profile_id < 1:
        reasons.append("INVALID_CHILD_PROFILE_ID")

    for field in COUNT_FIELDS:
        if values[field] is not None and values[field] < 0:
            reasons.append(f"NEGATIVE_COUNT:{field}")

    activity_date = values["aggDate"]
    if activity_date is not None:
        try:
            if not DATE_PATTERN.fullmatch(activity_date):
                raise ValueError("date must use YYYY-MM-DD")
            date.fromisoformat(activity_date)
        except ValueError:
            reasons.append("INVALID_DATE")

    for field in TIME_FIELDS:
        value = values[field]
        if value is not None and not TIME_PATTERN.fullmatch(value):
            reasons.append(f"INVALID_TIME:{field}")

    zone_name = values["timezone"]
    if zone_name is not None:
        try:
            if not TIMEZONE_PATTERN.fullmatch(zone_name):
                raise ValueError("timezone must be a region-based IANA name")
            ZoneInfo(zone_name)
        except (ZoneInfoNotFoundError, ValueError):
            reasons.append("INVALID_TIMEZONE")

    status = values["communicationStatus"]
    if status is not None and status not in {"ACTIVE", "INACTIVE"}:
        reasons.append("INVALID_COMMUNICATION_STATUS")

    return tuple(values[field] for field in CONTRACT_FIELDS) + (reasons,)


def time_to_minutes(value: str) -> int:
    hours, minutes = value.split(":")
    return int(hours) * 60 + int(minutes)


def window_intervals(start_time: str, end_time: str) -> list[tuple[int, int]]:
    start = time_to_minutes(start_time)
    end = time_to_minutes(end_time)
    if start < end:
        return [(start, end)]
    if start > end:
        return [(start, 24 * 60), (0, end)]
    return []


def windows_overlap(
    first_start: str, first_end: str, second_start: str, second_end: str
) -> bool:
    return any(
        max(first[0], second[0]) < min(first[1], second[1])
        for first in window_intervals(first_start, first_end)
        for second in window_intervals(second_start, second_end)
    )


def validate_cross_fields(*field_values: Any) -> list[str]:
    values = dict(zip(CONTRACT_FIELDS, field_values))
    reasons: list[str] = []
    call_count = values["callCount"]
    night_count = values["nightCount"]
    school_count = values["schoolCount"]
    valid_call_count = call_count is not None and call_count >= 0
    valid_night_count = night_count is not None and night_count >= 0
    valid_school_count = school_count is not None and school_count >= 0

    if valid_call_count and valid_night_count and night_count > call_count:
        reasons.append("NIGHT_COUNT_EXCEEDS_CALL_COUNT")
    if valid_call_count and valid_school_count and school_count > call_count:
        reasons.append("SCHOOL_COUNT_EXCEEDS_CALL_COUNT")

    window_values = [values[field] for field in TIME_FIELDS]
    if (
        valid_call_count
        and valid_night_count
        and valid_school_count
        and all(value is not None and TIME_PATTERN.fullmatch(value) for value in window_values)
        and not windows_overlap(*window_values)
        and night_count + school_count > call_count
    ):
        reasons.append("DISJOINT_WINDOW_COUNTS_EXCEED_CALL_COUNT")

    counts = [values[field] for field in COUNT_FIELDS]
    if (
        values["communicationStatus"] == "INACTIVE"
        and all(value is not None and value >= 0 for value in counts)
        and any(value != 0 for value in counts)
    ):
        reasons.append("INACTIVE_WITH_ACTIVITY")

    activity_date = values["aggDate"]
    if activity_date is not None:
        try:
            parsed_date = date.fromisoformat(activity_date)
            if valid_school_count and parsed_date.weekday() >= 5 and school_count != 0:
                reasons.append("WEEKEND_SCHOOL_ACTIVITY")
        except ValueError:
            pass

    return reasons


def build_validated_records(raw_records: Any) -> tuple[Any, int, int, int]:
    """Parse, validate, and mark every member of otherwise-valid duplicate keys."""
    from pyspark.sql import functions as sql_functions
    from pyspark.sql import types as sql_types

    validation_schema = sql_types.StructType(
        [
            sql_types.StructField(
                field,
                sql_types.LongType() if field in INTEGER_FIELDS else sql_types.StringType(),
                True,
            )
            for field in CONTRACT_FIELDS
        ]
        + [
            sql_types.StructField(
                "structuralFailureReasons",
                sql_types.ArrayType(sql_types.StringType(), containsNull=False),
                False,
            )
        ]
    )
    parse_udf = sql_functions.udf(parse_and_validate_structure, validation_schema)
    cross_udf = sql_functions.udf(
        validate_cross_fields,
        sql_types.ArrayType(sql_types.StringType(), containsNull=False),
    )

    parsed = (
        raw_records.withColumn("_parsed", parse_udf(sql_functions.col("rawRecord")))
        .select("rawRecord", "sourceFile", "recordFingerprint", "_parsed.*")
        .withColumn(
            "crossFieldFailureReasons",
            cross_udf(*[sql_functions.col(field) for field in CONTRACT_FIELDS]),
        )
        .withColumn(
            "failureReasons",
            sql_functions.concat(
                sql_functions.col("structuralFailureReasons"),
                sql_functions.col("crossFieldFailureReasons"),
            ),
        )
        .cache()
    )

    duplicate_keys = (
        parsed.filter(sql_functions.size("failureReasons") == 0)
        .groupBy("childProfileId", "aggDate")
        .count()
        .filter(sql_functions.col("count") > 1)
        .select("childProfileId", "aggDate")
        .withColumn("_duplicateKey", sql_functions.lit(True))
        .cache()
    )
    duplicate_key_count = duplicate_keys.count()

    validated = (
        parsed.join(duplicate_keys, ["childProfileId", "aggDate"], "left")
        .withColumn(
            "failureReasons",
            sql_functions.when(
                (sql_functions.size("failureReasons") == 0)
                & sql_functions.coalesce("_duplicateKey", sql_functions.lit(False)),
                sql_functions.array(sql_functions.lit("DUPLICATE_PROFILE_DATE")),
            ).otherwise(sql_functions.col("failureReasons")),
        )
        .drop("_duplicateKey", "structuralFailureReasons", "crossFieldFailureReasons")
        .cache()
    )
    invalid_count = validated.filter(sql_functions.size("failureReasons") > 0).count()
    valid_count = validated.filter(sql_functions.size("failureReasons") == 0).count()
    return validated, valid_count, invalid_count, duplicate_key_count


def prefix_has_objects(s3_client: Any, bucket: str, prefix: str) -> bool:
    response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix, MaxKeys=1)
    return bool(response.get("Contents"))


def list_keys(s3_client: Any, bucket: str, prefix: str) -> list[str]:
    keys: list[str] = []
    paginator = s3_client.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        keys.extend(item["Key"] for item in page.get("Contents", []))
    return keys


def delete_keys(s3_client: Any, bucket: str, keys: list[str]) -> None:
    for start in range(0, len(keys), 1000):
        batch = keys[start : start + 1000]
        if batch:
            s3_client.delete_objects(
                Bucket=bucket,
                Delete={"Objects": [{"Key": key} for key in batch], "Quiet": True},
            )


def publish_staged_prefixes(
    s3_client: Any,
    bucket: str,
    prefix_pairs: list[tuple[str, str]],
) -> list[str]:
    copied_keys: list[str] = []
    try:
        for source_prefix, destination_prefix in prefix_pairs:
            for source_key in list_keys(s3_client, bucket, source_prefix):
                relative_key = source_key.removeprefix(source_prefix)
                destination_key = f"{destination_prefix}{relative_key}"
                s3_client.copy_object(
                    Bucket=bucket,
                    Key=destination_key,
                    CopySource={"Bucket": bucket, "Key": source_key},
                    ServerSideEncryption="AES256",
                    MetadataDirective="COPY",
                )
                copied_keys.append(destination_key)
        return copied_keys
    except Exception:
        delete_keys(s3_client, bucket, copied_keys)
        raise


def utc_now_text() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def write_curated_outputs(
    spark: Any,
    s3_client: Any,
    validated: Any,
    arguments: dict[str, str],
    preflight: PreflightResult,
    input_record_count: int,
    valid_record_count: int,
    invalid_record_count: int,
    duplicate_key_count: int,
    started_at: str,
) -> dict[str, Any]:
    from pyspark.sql import functions as sql_functions

    curated_bucket = arguments["curated_bucket"]
    run_id = preflight.run_id
    job_run_id = arguments["JOB_RUN_ID"]
    valid_prefix = f"daily-communication/run_id={run_id}/data/"
    quarantine_prefix = f"daily-communication-quarantine/run_id={run_id}/data/"
    validation_prefix = f"daily-communication-validation/run_id={run_id}/"

    for prefix in (valid_prefix, quarantine_prefix, validation_prefix):
        if prefix_has_objects(s3_client, curated_bucket, prefix):
            raise PreflightError(
                f"Refusing to overwrite existing output: s3://{curated_bucket}/{prefix}"
            )

    staging_root = (
        f"daily-communication-staging/run_id={run_id}/job_run_id={job_run_id}/"
    )
    staging_valid_prefix = f"{staging_root}valid/"
    staging_quarantine_prefix = f"{staging_root}quarantine/"
    staging_keys = list_keys(s3_client, curated_bucket, staging_root)
    if staging_keys:
        raise PreflightError(
            f"Unexpected existing staging output: s3://{curated_bucket}/{staging_root}"
        )

    valid_records = validated.filter(sql_functions.size("failureReasons") == 0).select(
        sql_functions.col("childProfileId").cast("long").alias("childProfileId"),
        sql_functions.to_date("aggDate", "yyyy-MM-dd").alias("aggDate"),
        "timezone",
        "communicationStatus",
        *[sql_functions.col(field).cast("long").alias(field) for field in COUNT_FIELDS[:2]],
        sql_functions.col("nightCount").cast("long").alias("nightCount"),
        "nightStartTime",
        "nightEndTime",
        sql_functions.col("schoolCount").cast("long").alias("schoolCount"),
        "schoolStartTime",
        "schoolEndTime",
    )
    quarantine_records = validated.filter(sql_functions.size("failureReasons") > 0).select(
        sql_functions.lit(run_id).alias("runId"),
        "sourceFile",
        "recordFingerprint",
        "rawRecord",
        sql_functions.col("childProfileId").cast("long").alias("childProfileId"),
        sql_functions.to_date("aggDate", "yyyy-MM-dd").alias("aggDate"),
        "failureReasons",
    )

    valid_records.write.mode("errorifexists").option("compression", "snappy").parquet(
        f"s3://{curated_bucket}/{staging_valid_prefix}"
    )
    quarantine_records.write.mode("errorifexists").option(
        "compression", "snappy"
    ).parquet(f"s3://{curated_bucket}/{staging_quarantine_prefix}")

    failure_reason_counts = {
        row["failureReason"]: row["count"]
        for row in (
            validated.select(sql_functions.explode("failureReasons").alias("failureReason"))
            .groupBy("failureReason")
            .count()
            .orderBy("failureReason")
            .collect()
        )
    }
    summary = {
        "runId": run_id,
        "jobRunId": job_run_id,
        "startedAt": started_at,
        "completedAt": utc_now_text(),
        "status": (
            "COMPLETED" if invalid_record_count == 0 else "COMPLETED_WITH_INVALID_RECORDS"
        ),
        "manifestRecordCount": preflight.manifest["recordCount"],
        "inputRecordCount": input_record_count,
        "validRecordCount": valid_record_count,
        "invalidRecordCount": invalid_record_count,
        "duplicateKeyCount": duplicate_key_count,
        "failureReasonCounts": failure_reason_counts,
        "validOutputUri": f"s3://{curated_bucket}/{valid_prefix}",
        "quarantineOutputUri": f"s3://{curated_bucket}/{quarantine_prefix}",
    }

    if not (
        input_record_count
        == valid_record_count + invalid_record_count
        == preflight.manifest["recordCount"]
    ):
        raise PreflightError("Output record counts do not reconcile with the manifest")

    copied_keys: list[str] = []
    try:
        copied_keys = publish_staged_prefixes(
            s3_client,
            curated_bucket,
            [
                (staging_valid_prefix, valid_prefix),
                (staging_quarantine_prefix, quarantine_prefix),
            ],
        )
        s3_client.put_object(
            Bucket=curated_bucket,
            Key=f"{validation_prefix}summary.json",
            Body=(json.dumps(summary, indent=2, sort_keys=True) + "\n").encode("utf-8"),
            ContentType="application/json",
            ServerSideEncryption="AES256",
        )
    except Exception:
        delete_keys(s3_client, curated_bucket, copied_keys)
        raise
    finally:
        delete_keys(s3_client, curated_bucket, list_keys(s3_client, curated_bucket, staging_root))

    return summary


def resolve_glue_arguments(argv: list[str]) -> dict[str, str]:
    try:
        from awsglue.utils import getResolvedOptions
    except ImportError as exc:
        raise RuntimeError("This entry point must run in an AWS Glue Python environment") from exc

    # GlueArgumentParser registers JOB_RUN_ID internally. Requesting it again
    # causes argparse to report a conflicting option string, but the resolved
    # result still includes the built-in value.
    return getResolvedOptions(argv, ["JOB_NAME", "run_id", "raw_bucket", "curated_bucket"])


def main() -> None:
    import boto3
    from awsglue.context import GlueContext
    from pyspark.context import SparkContext

    started_at = utc_now_text()
    arguments = resolve_glue_arguments(sys.argv)
    s3_client = boto3.client("s3")
    result = preflight_raw_run(
        s3_client=s3_client,
        raw_bucket=arguments["raw_bucket"],
        run_id=arguments["run_id"],
    )
    print(
        json.dumps(
            {
                "event": "RAW_RUN_PREFLIGHT_PASSED",
                "runId": result.run_id,
                "rawPrefix": result.raw_prefix,
                "manifestRecordCount": result.manifest["recordCount"],
                "verifiedPartCount": len(result.part_uris),
                "partUris": result.part_uris,
            },
            sort_keys=True,
        )
    )

    glue_context = GlueContext(SparkContext.getOrCreate())
    raw_records, input_record_count = ingest_raw_records(glue_context.spark_session, result)
    print(
        json.dumps(
            {
                "event": "RAW_RECORDS_INGESTED",
                "runId": result.run_id,
                "inputRecordCount": input_record_count,
                "manifestRecordCount": result.manifest["recordCount"],
                "columns": raw_records.columns,
            },
            sort_keys=True,
        )
    )

    validated, valid_count, invalid_count, duplicate_key_count = build_validated_records(
        raw_records
    )
    print(
        json.dumps(
            {
                "event": "VALIDATION_COMPLETED",
                "runId": result.run_id,
                "validRecordCount": valid_count,
                "invalidRecordCount": invalid_count,
                "duplicateKeyCount": duplicate_key_count,
            },
            sort_keys=True,
        )
    )

    summary = write_curated_outputs(
        spark=glue_context.spark_session,
        s3_client=s3_client,
        validated=validated,
        arguments=arguments,
        preflight=result,
        input_record_count=input_record_count,
        valid_record_count=valid_count,
        invalid_record_count=invalid_count,
        duplicate_key_count=duplicate_key_count,
        started_at=started_at,
    )
    print(json.dumps({"event": "CURATED_RUN_PUBLISHED", **summary}, sort_keys=True))


if __name__ == "__main__":
    main()
