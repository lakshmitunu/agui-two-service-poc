"""Guardrails: turn limit and tool-call limits, enforced with Strands lifecycle hooks.

One LimitsHook instance (and one RequestState) exists per request, so counters never leak
between requests.

  BeforeModelCallEvent.cancel      -> stops the loop: Strands ends the turn with our message
  BeforeToolCallEvent.cancel_tool  -> the tool is NOT run; the model receives our message as an
                                      error tool result and can still answer with what it has
"""

from collections import Counter
from dataclasses import dataclass, field

from strands.hooks import BeforeModelCallEvent, BeforeToolCallEvent, HookProvider, HookRegistry

from weather_agent.observability.logging import get_logger

log = get_logger()


@dataclass
class RequestState:
    turns: int = 0  # model calls started
    tool_calls: int = 0  # tool calls allowed through
    tool_calls_blocked: int = 0
    per_tool: Counter = field(default_factory=Counter)
    limit_hit: str | None = None  # "max_turns" | "max_tool_calls" | "max_calls_per_tool"


class LimitsHook(HookProvider):
    def __init__(self, state: RequestState, max_turns: int, max_tool_calls: int, max_calls_per_tool: int):
        self.state = state
        self.max_turns = max_turns
        self.max_tool_calls = max_tool_calls
        self.max_calls_per_tool = max_calls_per_tool

    def register_hooks(self, registry: HookRegistry, **kwargs) -> None:
        registry.add_callback(BeforeModelCallEvent, self._before_model)
        registry.add_callback(BeforeToolCallEvent, self._before_tool)

    def _before_model(self, event: BeforeModelCallEvent) -> None:
        st = self.state
        if st.turns >= self.max_turns:
            st.limit_hit = st.limit_hit or "max_turns"
            log.warning("limit.hit", limit="max_turns", max=self.max_turns, turns=st.turns)
            event.cancel = (
                f"I reached my limit of {self.max_turns} reasoning turns for one request, "
                "so I have to stop here. Please try a simpler or more specific question."
            )
            return
        st.turns += 1

    def _before_tool(self, event: BeforeToolCallEvent) -> None:
        st = self.state
        name = event.tool_use["name"]
        reason = None
        if st.tool_calls >= self.max_tool_calls:
            reason, limit = "max_tool_calls", self.max_tool_calls
        elif st.per_tool[name] >= self.max_calls_per_tool:
            reason, limit = "max_calls_per_tool", self.max_calls_per_tool

        if reason:
            st.tool_calls_blocked += 1
            st.limit_hit = st.limit_hit or reason
            log.warning("limit.hit", limit=reason, max=limit, tool=name, tool_calls=st.tool_calls)
            # Tell the model why, so it stops asking and answers with what it already has.
            event.cancel_tool = (
                f"Tool call blocked: {reason} limit ({limit}) reached. Do not call more tools; "
                "answer using the information you already have and say what is missing."
            )
            return
        st.tool_calls += 1
        st.per_tool[name] += 1
