# Parent Insights Phase 1 Execution Runbook

## Purpose

This runbook starts after a raw batch folder has already been created:

```text
raw-batches/run_id=<run-id>/
├── part-00000.jsonl.gz
├── manifest.json
└── _SUCCESS
```

Replace `<run-id>` in every command with the new batch identifier, for example:

```text
20260830T055411Z
```

Do not rerun a completed Glue job for the same `run_id`. The jobs intentionally refuse to overwrite existing curated or feature outputs.

## About `.txts` files in the ZIP

Shell files are renamed from `.sh` to `.txts` only inside the delivery ZIP. This makes the archive easier to transfer without changing the working project.

Bash can execute these files without renaming them:

```bash
bash ./example.txts
```

In the original project directory, continue using the existing `.sh` filenames.

## Execution order after data is created

### Step 1: upload the completed raw batch

#### Input

```text
raw-batches/run_id=<run-id>/
```

#### Command in the original project

```bash
cd /Volumes/work/codex_projects/parent_insights

bash ./upload_raw_batch.sh \
  /Volumes/work/codex_projects/parent_insights/raw-batches/run_id=<run-id>
```

#### Command from the ZIP copy

```bash
bash ./upload_raw_batch.txts /absolute/path/to/raw-batches/run_id=<run-id>
```

#### Output

```text
s3://vsf-parent-insights-raw/daily-communication/history/run_id=<run-id>/
```

The uploader sends the Gzip part files first, `manifest.json` second, and `_SUCCESS` last.

### Step 2: run Glue Job 1 unit tests

#### Command

```bash
cd /Volumes/work/codex_projects/parent_insights/phase1b-data-preparation

python3 -m unittest -v test_daily_communication_raw_to_curated.py
```

#### Expected result

```text
OK
```

These tests check raw-record contract and cross-field validation logic. They do not access AWS.

### Step 3: deploy and execute Glue Job 1

#### Input

```text
s3://vsf-parent-insights-raw/daily-communication/history/run_id=<run-id>/
```

#### Command in the original project

```bash
cd /Volumes/work/codex_projects/parent_insights

bash ./phase1b-data-preparation/deploy_daily_communication_raw_to_curated.sh \
  --release-version v1.4 \
  --run-id <run-id>
```

#### Command from the ZIP copy

```bash
bash ./phase1b-data-preparation/deploy_daily_communication_raw_to_curated.txts \
  --release-version v1.4 \
  --run-id <run-id>
```

#### Approvals

1. Type `apply` to upload or verify the immutable Glue script and create or update the Glue job.
2. Type `run` to execute the job for the supplied `run_id`.

#### Output

```text
s3://vsf-parent-insights-curated/daily-communication/run_id=<run-id>/data/
s3://vsf-parent-insights-curated/daily-communication-quarantine/run_id=<run-id>/data/
s3://vsf-parent-insights-curated/daily-communication-validation/run_id=<run-id>/summary.json
```

Wait for the Glue state to become `SUCCEEDED` before continuing.

### Step 4: verify Glue Job 1 curated output

#### Command in the original project

```bash
bash ./phase1b-data-preparation/verify_curated_output.sh \
  --run-id <run-id>
```

#### Command from the ZIP copy

```bash
bash ./phase1b-data-preparation/verify_curated_output.txts \
  --run-id <run-id>
```

#### What it validates

- summary and manifest counts reconcile;
- curated schema and data types match;
- profile/date keys are unique;
- expected profiles, dates, and rows exist;
- quarantine count matches the summary;
- Parquet uses Snappy compression;
- raw part sizes and SHA-256 checksums match the manifest.

#### Required result

```text
VERIFICATION PASSED
```

Do not run Glue Job 2 unless this verification passes.

### Step 5: run Glue Job 2 local Spark tests

#### Command in the original project

```bash
bash ./phase1b-data-preparation/run_glue_job_2_tests.sh
```

#### Command from the ZIP copy

```bash
bash ./phase1b-data-preparation/run_glue_job_2_tests.txts
```

The runner creates an isolated Python 3.11 environment and installs PySpark `3.5.4` when needed.

#### Required result

```text
Ran 6 tests
OK
```

### Step 6: deploy and execute Glue Job 2

#### Input

```text
s3://vsf-parent-insights-curated/daily-communication/run_id=<run-id>/data/
```

#### Command in the original project

```bash
bash ./phase1b-data-preparation/deploy_daily_communication_curated_to_features.sh \
  --release-version v1.0 \
  --run-id <run-id>
```

#### Command from the ZIP copy

```bash
bash ./phase1b-data-preparation/deploy_daily_communication_curated_to_features.txts \
  --release-version v1.0 \
  --run-id <run-id>
```

#### Approvals

1. Type `apply` to upload or verify the immutable feature script and create or update Glue Job 2.
2. Type `run` to execute the job for the supplied `run_id`.

#### Output

```text
s3://vsf-parent-insights-features/daily-communication/run_id=<run-id>/data/
s3://vsf-parent-insights-features/daily-communication-validation/run_id=<run-id>/summary.json
```

For the 10-profile, 60-day dataset, the expected summary counts are:

```text
Input rows:          600
Output rows:         600
7-day ready rows:    530
30-day ready rows:   300
Both-ready rows:     300
```

### Step 7: verify Glue Job 2 feature output

#### Command in the original project

```bash
bash ./phase1b-data-preparation/verify_feature_output.sh \
  --run-id <run-id>
```

#### Command from the ZIP copy

```bash
bash ./phase1b-data-preparation/verify_feature_output.txts \
  --run-id <run-id>
```

#### What it validates

- feature schema and data types;
- 600 unique profile/date rows;
- 7-day and 30-day readiness counts;
- every average, population standard deviation, difference, and Z-score by independent recalculation;
- current-day exclusion from historical windows;
- null behavior during warm-up and zero variance;
- absence of NaN and infinite values;
- Snappy compression.

#### Required result

```text
FEATURE VERIFICATION PASSED
```

## Short command checklist

For the original project:

```bash
cd /Volumes/work/codex_projects/parent_insights

bash ./upload_raw_batch.sh \
  /Volumes/work/codex_projects/parent_insights/raw-batches/run_id=<run-id>

python3 -m unittest -v \
  ./phase1b-data-preparation/test_daily_communication_raw_to_curated.py

bash ./phase1b-data-preparation/deploy_daily_communication_raw_to_curated.sh \
  --release-version v1.4 --run-id <run-id>

bash ./phase1b-data-preparation/verify_curated_output.sh \
  --run-id <run-id>

bash ./phase1b-data-preparation/run_glue_job_2_tests.sh

bash ./phase1b-data-preparation/deploy_daily_communication_curated_to_features.sh \
  --release-version v1.0 --run-id <run-id>

bash ./phase1b-data-preparation/verify_feature_output.sh \
  --run-id <run-id>
```

## Supporting files that are not executed directly

| File | Purpose |
|---|---|
| `daily_communication_raw_to_curated.py` | Glue Job 1 program uploaded and executed by AWS Glue. |
| `daily_communication_curated_to_features.py` | Glue Job 2 program uploaded and executed by AWS Glue. |
| `daily-communication.schema.json` | Raw daily communication schema definition. |
| `daily-communication-data-contract.md` | Human-readable data contract. |
| `glue-job-1-design.md` | Glue Job 1 input, processing, and output design. |
| `glue-job-1-deployment-design.md` | Glue Job 1 production deployment design. |
| `glue-job-2-feature-engineering-design.md` | Glue Job 2 feature calculations and examples. |
| `glue-job-2-deployment-design.md` | Glue Job 2 production deployment design. |

## Completed current run

The already completed example run is:

```text
run_id=20260830T055411Z
```

Its Job 1 and Job 2 outputs already exist. Only the read-only verification scripts should be rerun for this identifier.
