"""Builds one Agent per request. A fresh Agent means fresh message history, fresh metrics
(so usage is exactly this request's usage) and fresh limit counters: the service is stateless."""

from strands import Agent
from strands.models import Model
from strands.models.model import CacheConfig

from weather_agent.agent.hooks import LimitsHook, LoggingHook, RequestState
from weather_agent.agent.prompts import SYSTEM_PROMPT
from weather_agent.agent.stub_model import StubModel
from weather_agent.config import Settings
from weather_agent.tools import ALL_TOOLS


def build_model(s: Settings) -> Model:
    if s.llm_provider == "stub":
        return StubModel()

    from strands.models.anthropic import AnthropicModel  # imported lazily: stub mode needs no key

    if s.anthropic_api_key is None:
        raise RuntimeError("LLM_PROVIDER=anthropic requires ANTHROPIC_API_KEY to be set")

    cache_config = None
    if s.prompt_caching_enabled:
        # Cache breakpoints on: tool definitions, system prompt, and the last user message
        # (the growing conversation prefix, so turn N+1 re-reads turn N within one request).
        cache_config = CacheConfig(strategy="anthropic", ttl=s.cache_ttl, system_prompt_ttl=True, tools_ttl=True)

    return AnthropicModel(
        client_args={"api_key": s.anthropic_api_key.get_secret_value()},
        model_id=s.model_id,
        max_tokens=s.max_output_tokens,
        params={"temperature": s.temperature},
        cache_config=cache_config,
    )


def build_agent(s: Settings, request_id: str, model: Model | None = None) -> tuple[Agent, RequestState]:
    state = RequestState()
    agent = Agent(
        model=model or build_model(s),
        system_prompt=SYSTEM_PROMPT,
        tools=ALL_TOOLS,
        hooks=[
            LimitsHook(state, s.max_turns, s.max_tool_calls, s.max_calls_per_tool),
            LoggingHook(s.log_message_chars),
        ],
        callback_handler=None,  # no stdout streaming; we log via hooks
        trace_attributes={"request.id": request_id},  # appears on the OTEL agent span
    )
    return agent, state
