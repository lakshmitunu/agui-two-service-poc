MCP Gateway Control Plane V19

Open mcp_gateway_v19.html in a modern browser. No build is required.
Serve it alongside your backend to use backend-dependent operations.

Sidebar order:
Overview → Tool Registration → Registry Explorer → Agent Management →
MCP Configuration → Session Management → Activity Insights → Settings

Agent Management now uses a robot icon. MCP Configuration uses a connected-node
icon; Session Management uses conversation bubbles.

Agent Management: name, owner, description, searchable registry-tool selection,
backend creation and one-time key display. No expiry input. The original eight
Registered Agents columns remain, including optional backend-supplied Expires At.

MCP Configuration: agent-key guidance, gateway and authentication setup, copyable
client configuration template, backend verification, test message and compact
architecture diagram.

Session Management: mandatory Customer ID and API Key, 10-minute default TTL,
styled masking-mode dropdown, optional Include Mapping and Session ID. Aligned
fields, returned sessionId JSON and a Sample cURL placeholder awaiting your example.
Unmask response, backend session list, search and inspect remain available.

See BACKEND_INTEGRATION.md for request/response contracts and route overrides.
No backend or fake results are included. Keys and session response content are
not persisted. Agent metadata and a tool-registry snapshot retain local caching.

All seven original V18.8 page sections are preserved. Original discovery/batch
registration require their existing backend endpoints, activity figures remain
illustrative and Settings remains Under Construction.

Validation: JavaScript syntax, isolated agent/platform flow tests, structural
checks and ZIP integrity passed. Browser rendering and live backend connections
remain unverified.

V19.2 correction: Get Configuration generates locally without a backend call.
Set window.MCP_GATEWAY_URL or replace YOUR_GATEWAY_HOST in the generated template.
The entered key is included in the copyable configuration and is not persisted.
Architecture now uses a dark connected SVG diagram matching the reference structure.
