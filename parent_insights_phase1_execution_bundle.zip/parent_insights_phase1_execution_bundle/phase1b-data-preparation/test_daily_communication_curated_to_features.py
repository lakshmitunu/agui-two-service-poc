#!/usr/bin/env python3
"""Unit tests for Glue Job 2 personalized rolling feature calculations."""

import math
import unittest
from datetime import date, timedelta

try:
    from pyspark.sql import SparkSession

    PYSPARK_AVAILABLE = True
except ImportError:
    SparkSession = None
    PYSPARK_AVAILABLE = False

from daily_communication_curated_to_features import build_rolling_features


def curated_row(
    activity_date: date,
    call_count: int,
    child_profile_id: int = 9001,
    text_count: int = 20,
    night_count: int = 1,
    school_count: int = 1,
) -> tuple:
    return (
        child_profile_id,
        activity_date,
        "America/New_York",
        "ACTIVE",
        call_count,
        text_count,
        night_count,
        "21:00",
        "06:00",
        school_count,
        "08:00",
        "15:00",
    )


CURATED_COLUMNS = (
    "childProfileId",
    "aggDate",
    "timezone",
    "communicationStatus",
    "callCount",
    "textCount",
    "nightCount",
    "nightStartTime",
    "nightEndTime",
    "schoolCount",
    "schoolStartTime",
    "schoolEndTime",
)


@unittest.skipUnless(PYSPARK_AVAILABLE, "PySpark is required for Glue Job 2 tests")
class RollingFeatureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spark = (
            SparkSession.builder.master("local[1]")
            .appName("daily-communication-feature-tests")
            .config("spark.ui.enabled", "false")
            .config("spark.sql.shuffle.partitions", "1")
            .getOrCreate()
        )
        cls.spark.sparkContext.setLogLevel("ERROR")

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    def make_features(self, rows):
        curated = self.spark.createDataFrame(rows, CURATED_COLUMNS)
        return build_rolling_features(curated)

    def test_seven_day_example_excludes_current_day(self):
        start = date(2026, 8, 23)
        historical_calls = [8, 9, 6, 10, 7, 11, 9]
        rows = [
            curated_row(start + timedelta(days=index), calls)
            for index, calls in enumerate(historical_calls)
        ]
        rows.append(curated_row(date(2026, 8, 30), 13))

        result = (
            self.make_features(rows)
            .filter("aggDate = DATE '2026-08-30'")
            .first()
        )

        self.assertEqual(7, result.historyDays7d)
        self.assertTrue(result.featuresReady7d)
        self.assertAlmostEqual(8.5714285714, result.callCountAvg7d, places=9)
        self.assertAlmostEqual(1.5907898179, result.callCountStd7d, places=9)
        self.assertAlmostEqual(4.4285714286, result.callCountDifference7d, places=9)
        self.assertAlmostEqual(2.7838821814, result.callCountZScore7d, places=9)

        # If today's 13 calls accidentally entered the average, it would be 9.125.
        self.assertNotAlmostEqual(9.125, result.callCountAvg7d, places=3)

    def test_first_seven_rows_are_warming_up(self):
        start = date(2026, 8, 1)
        rows = [curated_row(start + timedelta(days=index), 10) for index in range(8)]
        results = self.make_features(rows).orderBy("aggDate").collect()

        for index, result in enumerate(results[:7]):
            with self.subTest(day=index + 1):
                self.assertEqual(index, result.historyDays7d)
                self.assertFalse(result.featuresReady7d)
                self.assertIsNone(result.callCountAvg7d)
                self.assertIsNone(result.callCountStd7d)
                self.assertIsNone(result.callCountDifference7d)
                self.assertIsNone(result.callCountZScore7d)

        self.assertEqual(7, results[7].historyDays7d)
        self.assertTrue(results[7].featuresReady7d)

    def test_thirtieth_history_day_makes_day_31_ready(self):
        start = date(2026, 7, 31)
        rows = [curated_row(start + timedelta(days=index), index + 1) for index in range(31)]
        results = self.make_features(rows).orderBy("aggDate").collect()

        self.assertFalse(results[29].featuresReady30d)
        self.assertEqual(29, results[29].historyDays30d)
        self.assertTrue(results[30].featuresReady30d)
        self.assertEqual(30, results[30].historyDays30d)
        self.assertAlmostEqual(15.5, results[30].callCountAvg30d)

    def test_missing_calendar_day_prevents_readiness(self):
        rows = [
            curated_row(date(2026, 8, 22), 8),
            curated_row(date(2026, 8, 23), 9),
            # August 24 is deliberately missing.
            curated_row(date(2026, 8, 25), 6),
            curated_row(date(2026, 8, 26), 10),
            curated_row(date(2026, 8, 27), 7),
            curated_row(date(2026, 8, 28), 11),
            curated_row(date(2026, 8, 29), 9),
            curated_row(date(2026, 8, 30), 13),
        ]
        result = (
            self.make_features(rows)
            .filter("aggDate = DATE '2026-08-30'")
            .first()
        )

        # August 22 lies outside Aug 23–29, leaving only six calendar-day records.
        self.assertEqual(6, result.historyDays7d)
        self.assertFalse(result.featuresReady7d)
        self.assertIsNone(result.callCountAvg7d)

    def test_zero_variation_produces_null_z_score(self):
        start = date(2026, 8, 23)
        rows = [curated_row(start + timedelta(days=index), 10) for index in range(7)]
        rows.append(curated_row(date(2026, 8, 30), 13))
        result = (
            self.make_features(rows)
            .filter("aggDate = DATE '2026-08-30'")
            .first()
        )

        self.assertTrue(result.featuresReady7d)
        self.assertEqual(10.0, result.callCountAvg7d)
        self.assertEqual(0.0, result.callCountStd7d)
        self.assertEqual(3.0, result.callCountDifference7d)
        self.assertIsNone(result.callCountZScore7d)

    def test_output_count_matches_input_and_contains_no_infinity(self):
        start = date(2026, 7, 1)
        rows = []
        for child_profile_id in (9001, 9002):
            rows.extend(
                curated_row(
                    start + timedelta(days=index),
                    (index % 7) + 5,
                    child_profile_id=child_profile_id,
                )
                for index in range(60)
            )

        results = self.make_features(rows).collect()
        self.assertEqual(len(rows), len(results))
        self.assertEqual(106, sum(row.featuresReady7d for row in results))
        self.assertEqual(60, sum(row.featuresReady30d for row in results))
        for row in results:
            for field_name in row.__fields__:
                if "ZScore" in field_name:
                    value = row[field_name]
                    self.assertTrue(value is None or math.isfinite(value))


if __name__ == "__main__":
    unittest.main(verbosity=2)
