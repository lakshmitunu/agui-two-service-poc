"""Tool registry: add a new weather tool by writing a @tool function and listing it here."""

from weather_agent.tools.nws import get_weather_alerts
from weather_agent.tools.open_meteo import (
    geocode_location,
    get_air_quality,
    get_current_weather,
    get_forecast,
)

ALL_TOOLS = [geocode_location, get_current_weather, get_forecast, get_air_quality, get_weather_alerts]

__all__ = ["ALL_TOOLS"]
