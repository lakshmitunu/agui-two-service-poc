"""Observability hook: logs the agent's reasoning, tool calls and tool results as they happen."""

import json
import time

from strands.hooks import (
    AfterModelCallEvent,
    AfterToolCallEvent,
    BeforeModelCallEvent,
    BeforeToolCallEvent,
    HookProvider,
    HookRegistry,
)

from weather_agent.observability.logging import get_logger, truncate

log = get_logger()


class LoggingHook(HookProvider):
    def __init__(self, max_chars: int):
        self.max_chars = max_chars
        self._model_started: float = 0.0
        self._tool_started: dict[str, float] = {}
        self._turn = 0

    def register_hooks(self, registry: HookRegistry, **kwargs) -> None:
        registry.add_callback(BeforeModelCallEvent, self._before_model)
        registry.add_callback(AfterModelCallEvent, self._after_model)
        registry.add_callback(BeforeToolCallEvent, self._before_tool)
        registry.add_callback(AfterToolCallEvent, self._after_tool)

    def _before_model(self, event: BeforeModelCallEvent) -> None:
        self._turn += 1
        self._model_started = time.perf_counter()
        log.info("model.call", turn=self._turn, projected_input_tokens=event.projected_input_tokens)

    def _after_model(self, event: AfterModelCallEvent) -> None:
        latency_ms = round((time.perf_counter() - self._model_started) * 1000)
        if event.exception or not event.stop_response:
            log.error("model.error", turn=self._turn, error=repr(event.exception), latency_ms=latency_ms)
            return
        resp = event.stop_response
        reasoning, text, tool_requests = [], [], []
        for block in resp.message.get("content", []):
            if "reasoningContent" in block:  # extended thinking, if enabled
                reasoning.append(block["reasoningContent"].get("reasoningText", {}).get("text", ""))
            elif "text" in block:
                text.append(block["text"])
            elif "toolUse" in block:
                tool_requests.append({"tool": block["toolUse"]["name"], "input": block["toolUse"]["input"]})
        # Text emitted alongside a tool_use block is the model's visible "thinking out loud".
        log.info(
            "agent.reasoning",
            turn=self._turn,
            stop_reason=resp.stop_reason,
            latency_ms=latency_ms,
            thinking=truncate(" ".join(reasoning), self.max_chars) or None,
            text=truncate(" ".join(text), self.max_chars) or None,
            tool_requests=tool_requests or None,
        )

    def _before_tool(self, event: BeforeToolCallEvent) -> None:
        self._tool_started[event.tool_use["toolUseId"]] = time.perf_counter()
        log.info("tool.call", tool=event.tool_use["name"], input=event.tool_use["input"])

    def _after_tool(self, event: AfterToolCallEvent) -> None:
        started = self._tool_started.pop(event.tool_use["toolUseId"], time.perf_counter())
        result = event.result
        preview = json.dumps(result.get("content", []), default=str)
        log.info(
            "tool.result",
            tool=event.tool_use["name"],
            status=result.get("status"),
            duration_ms=round((time.perf_counter() - started) * 1000),
            result_chars=len(preview),
            result_preview=truncate(preview, self.max_chars),
            error=repr(event.exception) if event.exception else None,
        )
