# Glue Job 1 Production Deployment Design

## At a glance

### Input

- reviewed source file: `phase1b-data-preparation/daily_communication_raw_to_curated.py`;
- existing CloudFormation stack: `vsf-parent-insights`;
- existing Glue execution role: `vsf-parent-insights-glue-role`;
- AWS profile `parent-insights-personal` in `us-east-2`;
- an explicit release version, starting with `v1.0`.

### What this deployment does

1. Provisions a dedicated, protected S3 bucket for executable artifacts.
2. Uploads an immutable, content-addressed copy of the reviewed Glue script.
3. Creates or updates the Glue job through a reviewed AWS CLI script.
4. Pins the job definition to that exact script object.
5. Configures runtime, IAM, logging, retries, concurrency, and safe defaults.
6. Starts one job run only when a `run_id` is explicitly supplied.

### Output

| Output | Example |
|---|---|
| Artifact bucket | `s3://vsf-parent-insights-artifacts/` |
| Versioned script | `glue/jobs/daily-communication-raw-to-curated/releases/v1.4/daily_communication_raw_to_curated.py` |
| Glue job | `vsf-parent-insights-raw-to-curated` |
| Execution logs | CloudWatch Logs for the Glue job run |
| Valid curated data | `s3://vsf-parent-insights-curated/daily-communication/run_id=<run-id>/data/` |
| Invalid quarantine data | `s3://vsf-parent-insights-curated/daily-communication-quarantine/run_id=<run-id>/data/` |
| Validation summary | `s3://vsf-parent-insights-curated/daily-communication-validation/run_id=<run-id>/summary.json` |

Release `v1.4` completes the raw-to-curated stage. It writes final outputs only after preflight, ingestion, validation, duplicate detection, and count reconciliation succeed.

## Deployment flow

```mermaid
flowchart TD
    A["Run deployment shell script"]
    B["Perform read-only AWS checks"]
    C["Select v1.0 and calculate<br/>Python file SHA-256"]
    D["Display deployment plan"]
    E{"User types apply?"}
    F["Create or secure<br/>artifact bucket"]
    G["Upload Python file<br/>to releases/v1.0"]
    H["Download and verify<br/>uploaded file checksum"]
    I["Create or update<br/>Glue job configuration"]
    J["Set ScriptLocation to<br/>the exact versioned S3 file"]
    K["Verify saved ScriptLocation<br/>and display start-job-run command"]
    L{"User types run?"}
    M["Start Glue job with<br/>explicit run_id"]
    N["Glue reads ScriptLocation<br/>and downloads Python from S3"]
    O["Glue assumes execution role<br/>and runs Python script"]
    P["Python verifies the<br/>raw S3 batch"]
    Q["Wait for completion and show<br/>CloudWatch preflight result"]
    X["Stop with no deployment"]
    Y["Leave job deployed;<br/>do not execute it"]

    A --> B --> C --> D --> E
    E -- No --> X
    E -- Yes --> F --> G --> H --> I --> J --> K --> L
    L -- No --> Y
    L -- Yes --> M --> N --> O --> P --> Q
```

## 1. Why code gets a separate bucket

Raw, curated, feature, and model buckets contain data products. Glue scripts are executable deployment artifacts and have a different lifecycle and access pattern. Keeping them separate provides clearer IAM boundaries, auditability, retention rules, and ownership.

Proposed bucket:

```text
vsf-parent-insights-artifacts
```

Required protections:

- S3 Block Public Access enabled;
- bucket-owner-enforced object ownership;
- default server-side encryption;
- S3 versioning enabled;
- incomplete multipart uploads aborted after seven days;
- bucket policy denies requests that do not use TLS;
- CloudFormation deletion and update-replacement policies retain the bucket;
- tags identify product, project, environment, purpose, and CloudFormation ownership.

Retention is intentional: deleting an infrastructure stack must not silently remove the code needed to reproduce an earlier data-processing run.

## 2. Versioned, verified script releases

The deployer uses a readable release version in the S3 key:

```text
glue/jobs/daily-communication-raw-to-curated/releases/v1.0/daily_communication_raw_to_curated.py
```

Rules:

1. Never overwrite an existing release key with different bytes.
2. If the key already exists, verify that its SHA-256 matches and reuse it.
3. Record both the release version and SHA-256 as Glue job tags.
4. Updating code means choosing a new release such as `v1.1` and approving the displayed job update.
5. Rollback means deliberately repointing the job to a previously verified release.

The readable version identifies the release; SHA-256 verifies that the uploaded bytes exactly match the reviewed local file. S3 versioning remains an additional safeguard.

## 3. Deployment approach for Phase 1

For Phase 1, one reviewed shell script will use the AWS CLI to create or verify the artifact bucket, upload the immutable script release, and create or update the Glue job. This avoids adding CI/CD overhead while preserving explicit approval, checksum verification, and repeatability.

The existing `vsf-parent-insights` CloudFormation stack continues to own the existing raw, curated, feature, and model buckets, Glue database, and execution roles. The Phase 1 deployment script must discover and verify those resources rather than silently replacing them.

The artifact bucket and Glue job created by this workflow are not yet CloudFormation-managed. Moving them into infrastructure as code remains a future hardening step before a shared production release. The script must therefore be idempotent: it creates missing resources, compares existing configuration, and updates only after showing the proposed action.

## 4. Glue job configuration

| Setting | Production design |
|---|---|
| Name | `vsf-parent-insights-raw-to-curated` |
| IAM role | Existing `vsf-parent-insights-glue-role` |
| Command | `glueetl` |
| Script location | Exact content-addressed S3 release URI |
| Runtime | Explicitly pinned Glue version, confirmed as available in `us-east-2` before implementation |
| Python | Version supplied by the pinned Glue runtime |
| Capacity | Small explicit worker type and worker count for Phase 1; changed only through reviewed infrastructure |
| Max concurrency | `1` to prevent overlapping writes while run-level output locking is being built |
| Retries | `0` initially; checksum or contract failures are deterministic and should be investigated, not retried blindly |
| Timeout | Explicit finite timeout appropriate for the small Phase 1 batch |
| Metrics | Glue metrics and continuous CloudWatch logging enabled |
| Job bookmarks | Disabled; `run_id` and manifest provide explicit batch selection |

We will verify the currently supported Glue runtime in AWS before selecting the pinned version. Runtime selection should not silently float to a newer release.

## 5. Job arguments

Configured defaults:

```text
--raw_bucket=vsf-parent-insights-raw
--curated_bucket=vsf-parent-insights-curated
```

Required for every execution:

```text
--run_id=<YYYYMMDDTHHMMSSZ>
```

`run_id` is deliberately not stored as a default in the Glue job. Requiring it at start time prevents accidentally reprocessing an old batch because someone clicked **Run** without choosing a run.

## 6. Least-privilege access

For the current preflight checkpoint, the Glue job needs:

- list access limited to the raw bucket;
- read access to `daily-communication/history/*` in the raw bucket;
- read access to its versioned script under `glue/jobs/raw-to-curated/releases/*`;
- standard Glue service logging permissions.

It does not yet need to write curated data. Curated write permissions will be narrowed to the agreed daily-communication output prefixes when Parquet writing is implemented. The current broad project-bucket policy should be tightened incrementally rather than copied to the artifact bucket.

The deployment identity—not the Glue execution role—uploads release artifacts.

## 7. Safe deployment sequence

The planned `deploy_daily_communication_raw_to_curated.sh` script uses two separate approval gates.

### Gate 1: deploy the job

**Input:** reviewed local `daily_communication_raw_to_curated.py`, release version, AWS identity, existing Glue role, and selected Glue runtime configuration.

**Read-only work before approval:**

1. verify the caller's AWS account and region;
2. verify the raw and curated buckets and Glue execution role;
3. calculate the local script's SHA-256;
4. inspect the artifact bucket and existing Glue job, if present;
5. print the exact artifact URI and whether resources will be created, reused, or updated;
6. print a readable summary of the proposed Glue configuration.

The script then requires:

```text
Type 'apply' to upload the artifact and create or update the Glue job:
```

Anything except `apply` cancels without mutation.

After approval, the script creates or secures the artifact bucket if necessary, uploads the digest-specific object, verifies its checksum, and creates or updates the Glue job pinned to that object.

### Gate 2: execute the preflight

After deployment succeeds, the script prints the equivalent `aws glue start-job-run` command and requires:

```text
Type 'run' to execute Glue Job 1 for run_id=20260830T055411Z:
```

Anything except `run` leaves the deployed job unchanged and does not start it. After approval, the script starts the run, waits for a terminal state, and retrieves the relevant result or failure information.

## 8. Failure behavior

- Failed identity or dependency checks: make no AWS changes.
- Rejected `apply` prompt: make no AWS changes.
- Artifact key exists with a different checksum: stop deployment.
- Artifact upload or verification fails: do not create or update the Glue job.
- Rejected `run` prompt: leave the job deployed but do not start a run.
- Glue validation or publication fails: preserve logs, publish no completion summary, and leave raw objects unchanged.
- A concurrent job run is attempted: reject it through maximum concurrency of one.

## 9. Acceptance criteria

- The artifact bucket is encrypted, versioned, private, TLS-only, and tagged.
- The deployed script's SHA-256 equals the local reviewed script's SHA-256.
- The Glue job references the exact `v1.4` release key, not a mutable `latest` key.
- The job cannot start without an explicit `run_id` supplied by the launcher.
- The execution role can read the required artifact and raw scopes and write the intended curated output scopes. The existing shared Phase 1 Glue role still has broader project-bucket access; replacing it with a job-specific role is a documented IAM-hardening follow-up.
- A run for `20260830T055411Z` emits `CURATED_RUN_PUBLISHED` with 600 valid and zero invalid records.
- Curated and quarantine outputs use Snappy-compressed Parquet, and the validation summary is written last.
- The Glue run makes no changes to the raw bucket.

## 10. Operator runbook

### Files involved

The deployment script to execute will be:

```text
phase1b-data-preparation/deploy_daily_communication_raw_to_curated.sh
```

It will upload this local Glue source file:

```text
phase1b-data-preparation/daily_communication_raw_to_curated.py
```

The destination uses the approved release version. SHA-256 is used to verify the file, not as the folder name:

```text
s3://vsf-parent-insights-artifacts/glue/jobs/daily-communication-raw-to-curated/releases/v1.0/daily_communication_raw_to_curated.py
```

The Glue job will be:

```text
vsf-parent-insights-raw-to-curated
```

### Command the operator executes

From the project root:

```bash
cd /Volumes/work/codex_projects/parent_insights
bash ./phase1b-data-preparation/deploy_daily_communication_raw_to_curated.sh \
  --release-version v1.0 \
  --run-id 20260830T055411Z
```

The script uses these defaults unless explicitly overridden:

```text
AWS profile:       parent-insights-personal
AWS region:        us-east-2
Raw bucket:        vsf-parent-insights-raw
Curated bucket:    vsf-parent-insights-curated
Artifact bucket:   vsf-parent-insights-artifacts
Glue role:         vsf-parent-insights-glue-role
Glue job:          vsf-parent-insights-raw-to-curated
```

### Equivalent Glue execution command

After deployment, the script will display a command equivalent to:

```bash
aws glue start-job-run \
  --profile parent-insights-personal \
  --region us-east-2 \
  --job-name vsf-parent-insights-raw-to-curated \
  --arguments '{"--run_id":"20260830T055411Z","--raw_bucket":"vsf-parent-insights-raw","--curated_bucket":"vsf-parent-insights-curated"}'
```

The deployment script, rather than the operator, executes this command only after the operator types `run`.

### Verified `v1.0` result

The Glue run should finish with `SUCCEEDED` and log an event containing:

```json
{
  "event": "RAW_RUN_PREFLIGHT_PASSED",
  "manifestRecordCount": 600,
  "verifiedPartCount": 1,
  "runId": "20260830T055411Z"
}
```

The `v1.0` preflight event was observed for the expected 600-record, one-part run. No curated Parquet was expected or written.

## 11. Release progression

| Release | Implemented behavior | Expected success event |
|---|---|---|
| `v1.0` | Raw-run preflight: completion marker, manifest, file listing, size, and checksum | `RAW_RUN_PREFLIGHT_PASSED` |
| `v1.1` | Preflight plus Spark Gzip JSONL text ingestion and manifest-count reconciliation | `RAW_RECORDS_INGESTED` |
| `v1.2` | First complete implementation; failed before processing because `JOB_RUN_ID` was registered twice | No success event |
| `v1.3` | Reached summary publication; failed because Glue's bundled botocore did not support `IfNoneMatch` for `put_object`; rollback removed outputs | No success event |
| `v1.4` | Corrected complete validation, duplicate detection, curated/quarantine Snappy Parquet, and validation summary | `CURATED_RUN_PUBLISHED` |

Release `v1.1` wrote no curated Parquet. It proved that Spark could read all 600 physical records without losing raw-line provenance. Release `v1.2` failed during argument initialization. Release `v1.3` reached final publication but its unsupported conditional S3 parameter caused rollback. Release `v1.4` uses the existing output-prefix guard plus maximum concurrency of one and completes the job with Glue's bundled SDK.

Deploy and run `v1.1` with:

```bash
cd /Volumes/work/codex_projects/parent_insights
bash ./phase1b-data-preparation/deploy_daily_communication_raw_to_curated.sh \
  --release-version v1.1 \
  --run-id 20260830T055411Z
```

The expected `v1.1` event was:

```json
{
  "columns": ["rawRecord", "sourceFile", "recordFingerprint"],
  "event": "RAW_RECORDS_INGESTED",
  "inputRecordCount": 600,
  "manifestRecordCount": 600,
  "runId": "20260830T055411Z"
}
```

Deploy the corrected complete `v1.4` release with:

```bash
cd /Volumes/work/codex_projects/parent_insights
bash ./phase1b-data-preparation/deploy_daily_communication_raw_to_curated.sh \
  --release-version v1.4 \
  --run-id 20260830T055411Z
```

For the clean 600-record batch, the final event should report:

```json
{
  "event": "CURATED_RUN_PUBLISHED",
  "runId": "20260830T055411Z",
  "status": "COMPLETED",
  "manifestRecordCount": 600,
  "inputRecordCount": 600,
  "validRecordCount": 600,
  "invalidRecordCount": 0,
  "duplicateKeyCount": 0,
  "failureReasonCounts": {}
}
```

The published outputs are:

```text
s3://vsf-parent-insights-curated/daily-communication/run_id=20260830T055411Z/data/
s3://vsf-parent-insights-curated/daily-communication-quarantine/run_id=20260830T055411Z/data/
s3://vsf-parent-insights-curated/daily-communication-validation/run_id=20260830T055411Z/summary.json
```
