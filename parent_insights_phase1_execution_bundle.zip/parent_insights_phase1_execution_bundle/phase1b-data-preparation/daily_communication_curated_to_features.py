#!/usr/bin/env python3
"""Create personalized rolling features from validated daily communication data."""

import json
import re
import sys
from datetime import datetime, timezone
from typing import Any


RUN_ID_PATTERN = re.compile(r"[0-9]{8}T[0-9]{6}Z")
MEASUREMENT_FIELDS = ("callCount", "textCount", "nightCount", "schoolCount")
WINDOWS = ((7, "7d"), (30, "30d"))


class FeatureJobError(RuntimeError):
    """Raised when feature input or output violates the job contract."""


def utc_now_text() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def load_json_object(s3_client: Any, bucket: str, key: str) -> dict[str, Any]:
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        document = json.loads(response["Body"].read().decode("utf-8"))
    except Exception as exc:
        raise FeatureJobError(f"Unable to read valid JSON from s3://{bucket}/{key}: {exc}") from exc
    if not isinstance(document, dict):
        raise FeatureJobError(f"s3://{bucket}/{key} must contain one JSON object")
    return document


def prefix_has_objects(s3_client: Any, bucket: str, prefix: str) -> bool:
    response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix, MaxKeys=1)
    return bool(response.get("Contents"))


def list_keys(s3_client: Any, bucket: str, prefix: str) -> list[str]:
    keys: list[str] = []
    paginator = s3_client.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        keys.extend(item["Key"] for item in page.get("Contents", []))
    return keys


def delete_keys(s3_client: Any, bucket: str, keys: list[str]) -> None:
    for start in range(0, len(keys), 1000):
        batch = keys[start : start + 1000]
        if batch:
            s3_client.delete_objects(
                Bucket=bucket,
                Delete={"Objects": [{"Key": key} for key in batch], "Quiet": True},
            )


def publish_staged_prefix(
    s3_client: Any,
    bucket: str,
    source_prefix: str,
    destination_prefix: str,
) -> list[str]:
    copied_keys: list[str] = []
    try:
        for source_key in list_keys(s3_client, bucket, source_prefix):
            relative_key = source_key.removeprefix(source_prefix)
            destination_key = f"{destination_prefix}{relative_key}"
            s3_client.copy_object(
                Bucket=bucket,
                Key=destination_key,
                CopySource={"Bucket": bucket, "Key": source_key},
                ServerSideEncryption="AES256",
                MetadataDirective="COPY",
            )
            copied_keys.append(destination_key)
        return copied_keys
    except Exception:
        delete_keys(s3_client, bucket, copied_keys)
        raise


def validate_run_id(run_id: str) -> None:
    if not RUN_ID_PATTERN.fullmatch(run_id):
        raise FeatureJobError("run_id must use the YYYYMMDDTHHMMSSZ format")


def preflight_curated_run(
    s3_client: Any,
    curated_bucket: str,
    run_id: str,
) -> tuple[str, int]:
    validate_run_id(run_id)
    if not curated_bucket or "/" in curated_bucket:
        raise FeatureJobError("curated_bucket must be an S3 bucket name, not a path")

    data_prefix = f"daily-communication/run_id={run_id}/data/"
    summary_key = f"daily-communication-validation/run_id={run_id}/summary.json"
    summary = load_json_object(s3_client, curated_bucket, summary_key)
    if summary.get("runId") != run_id:
        raise FeatureJobError("Curated validation summary runId does not match the requested run")
    if summary.get("status") not in {"COMPLETED", "COMPLETED_WITH_INVALID_RECORDS"}:
        raise FeatureJobError(f"Curated run is not complete: {summary.get('status')!r}")
    expected_uri = f"s3://{curated_bucket}/{data_prefix}"
    if summary.get("validOutputUri") != expected_uri:
        raise FeatureJobError("Curated validation summary points to an unexpected valid output URI")
    expected_count = summary.get("validRecordCount")
    if isinstance(expected_count, bool) or not isinstance(expected_count, int) or expected_count <= 0:
        raise FeatureJobError("Curated validation summary validRecordCount must be positive")
    if not prefix_has_objects(s3_client, curated_bucket, data_prefix):
        raise FeatureJobError(f"Curated Parquet input is missing: {expected_uri}")
    return expected_uri, expected_count


def read_and_validate_curated(spark: Any, input_uri: str, expected_count: int) -> Any:
    from pyspark.sql import functions as F

    required_columns = {
        "childProfileId",
        "aggDate",
        "timezone",
        "communicationStatus",
        "callCount",
        "textCount",
        "nightCount",
        "nightStartTime",
        "nightEndTime",
        "schoolCount",
        "schoolStartTime",
        "schoolEndTime",
    }
    curated = spark.read.parquet(input_uri).cache()
    missing_columns = sorted(required_columns - set(curated.columns))
    if missing_columns:
        raise FeatureJobError(f"Curated input is missing columns: {missing_columns}")

    actual_count = curated.count()
    if actual_count != expected_count:
        raise FeatureJobError(
            f"Curated row count mismatch: summary={expected_count}, parquet={actual_count}"
        )
    null_key_count = curated.filter(
        F.col("childProfileId").isNull() | F.col("aggDate").isNull()
    ).count()
    if null_key_count:
        raise FeatureJobError(f"Curated input contains {null_key_count} null profile/date keys")
    duplicate_key_count = (
        curated.groupBy("childProfileId", "aggDate")
        .count()
        .filter(F.col("count") > 1)
        .count()
    )
    if duplicate_key_count:
        raise FeatureJobError(
            f"Curated input contains {duplicate_key_count} duplicate profile/date keys"
        )
    return curated


def build_rolling_features(curated: Any) -> Any:
    """Append leakage-free 7-day and 30-day features to every curated row."""
    from pyspark.sql import Window
    from pyspark.sql import functions as F

    working = curated.withColumn("_calendarDay", F.unix_date("aggDate"))
    for days, suffix in WINDOWS:
        history_window = (
            Window.partitionBy("childProfileId")
            .orderBy(F.col("_calendarDay"))
            .rangeBetween(-days, -1)
        )
        history_days = f"historyDays{suffix}"
        ready = f"featuresReady{suffix}"
        working = working.withColumn(history_days, F.count(F.lit(1)).over(history_window))
        working = working.withColumn(ready, F.col(history_days) == F.lit(days))

        for measurement in MEASUREMENT_FIELDS:
            average = f"{measurement}Avg{suffix}"
            standard_deviation = f"{measurement}Std{suffix}"
            difference = f"{measurement}Difference{suffix}"
            z_score = f"{measurement}ZScore{suffix}"

            rolling_average = F.avg(F.col(measurement)).over(history_window)
            rolling_stddev = F.stddev_pop(F.col(measurement)).over(history_window)
            working = working.withColumn(
                average,
                F.when(F.col(ready), rolling_average).otherwise(F.lit(None).cast("double")),
            )
            working = working.withColumn(
                standard_deviation,
                F.when(F.col(ready), rolling_stddev).otherwise(F.lit(None).cast("double")),
            )
            working = working.withColumn(
                difference,
                F.when(
                    F.col(ready), F.col(measurement).cast("double") - F.col(average)
                ).otherwise(F.lit(None).cast("double")),
            )
            working = working.withColumn(
                z_score,
                F.when(
                    F.col(ready) & (F.col(standard_deviation) > F.lit(0.0)),
                    F.col(difference) / F.col(standard_deviation),
                ).otherwise(F.lit(None).cast("double")),
            )

    original_columns = curated.columns
    control_columns = [
        "historyDays7d",
        "historyDays30d",
        "featuresReady7d",
        "featuresReady30d",
    ]
    feature_columns = [
        f"{measurement}{metric}{suffix}"
        for measurement in MEASUREMENT_FIELDS
        for suffix in ("7d", "30d")
        for metric in ("Avg", "Std", "Difference", "ZScore")
    ]
    return working.select(*original_columns, *control_columns, *feature_columns)


def validate_features(features: Any, expected_count: int) -> dict[str, int]:
    from pyspark.sql import functions as F

    output_count = features.count()
    if output_count != expected_count:
        raise FeatureJobError(
            f"Feature row count mismatch: input={expected_count}, output={output_count}"
        )

    ready_7d_count = features.filter(F.col("featuresReady7d")).count()
    ready_30d_count = features.filter(F.col("featuresReady30d")).count()
    ready_both_count = features.filter(
        F.col("featuresReady7d") & F.col("featuresReady30d")
    ).count()
    invalid_readiness_count = features.filter(
        F.col("featuresReady30d") & ~F.col("featuresReady7d")
    ).count()
    if invalid_readiness_count:
        raise FeatureJobError("A 30-day-ready row was unexpectedly not 7-day ready")

    numeric_feature_columns = [
        column
        for column in features.columns
        if column.endswith(("Avg7d", "Std7d", "Difference7d", "ZScore7d",
                            "Avg30d", "Std30d", "Difference30d", "ZScore30d"))
    ]
    invalid_number_condition = None
    for column in numeric_feature_columns:
        condition = F.isnan(F.col(column)) | (F.abs(F.col(column)) == F.lit(float("inf")))
        invalid_number_condition = (
            condition if invalid_number_condition is None else invalid_number_condition | condition
        )
    if invalid_number_condition is not None and features.filter(invalid_number_condition).count():
        raise FeatureJobError("Feature output contains NaN or infinite values")

    return {
        "outputRecordCount": output_count,
        "ready7dRecordCount": ready_7d_count,
        "ready30dRecordCount": ready_30d_count,
        "readyBothRecordCount": ready_both_count,
    }


def write_feature_output(
    s3_client: Any,
    features: Any,
    arguments: dict[str, str],
    input_uri: str,
    counts: dict[str, int],
    started_at: str,
) -> dict[str, Any]:
    features_bucket = arguments["features_bucket"]
    run_id = arguments["run_id"]
    job_run_id = arguments["JOB_RUN_ID"]
    output_prefix = f"daily-communication/run_id={run_id}/data/"
    summary_prefix = f"daily-communication-validation/run_id={run_id}/"
    staging_root = f"daily-communication-staging/run_id={run_id}/job_run_id={job_run_id}/"
    staging_data_prefix = f"{staging_root}data/"

    for prefix in (output_prefix, summary_prefix):
        if prefix_has_objects(s3_client, features_bucket, prefix):
            raise FeatureJobError(
                f"Refusing to overwrite existing output: s3://{features_bucket}/{prefix}"
            )
    if prefix_has_objects(s3_client, features_bucket, staging_root):
        raise FeatureJobError(
            f"Unexpected existing staging output: s3://{features_bucket}/{staging_root}"
        )

    features.write.mode("errorifexists").option("compression", "snappy").parquet(
        f"s3://{features_bucket}/{staging_data_prefix}"
    )
    output_uri = f"s3://{features_bucket}/{output_prefix}"
    summary = {
        "runId": run_id,
        "jobRunId": job_run_id,
        "startedAt": started_at,
        "completedAt": utc_now_text(),
        "status": "COMPLETED",
        "inputUri": input_uri,
        "outputUri": output_uri,
        "inputRecordCount": counts["outputRecordCount"],
        **counts,
    }

    copied_keys: list[str] = []
    try:
        copied_keys = publish_staged_prefix(
            s3_client, features_bucket, staging_data_prefix, output_prefix
        )
        s3_client.put_object(
            Bucket=features_bucket,
            Key=f"{summary_prefix}summary.json",
            Body=(json.dumps(summary, indent=2, sort_keys=True) + "\n").encode("utf-8"),
            ContentType="application/json",
            ServerSideEncryption="AES256",
        )
    except Exception:
        delete_keys(s3_client, features_bucket, copied_keys)
        raise
    finally:
        delete_keys(
            s3_client,
            features_bucket,
            list_keys(s3_client, features_bucket, staging_root),
        )
    return summary


def resolve_glue_arguments(argv: list[str]) -> dict[str, str]:
    try:
        from awsglue.utils import getResolvedOptions
    except ImportError as exc:
        raise RuntimeError("This entry point must run in an AWS Glue Python environment") from exc
    return getResolvedOptions(
        argv, ["JOB_NAME", "run_id", "curated_bucket", "features_bucket"]
    )


def main() -> None:
    import boto3
    from awsglue.context import GlueContext
    from pyspark.context import SparkContext

    started_at = utc_now_text()
    arguments = resolve_glue_arguments(sys.argv)
    s3_client = boto3.client("s3")
    input_uri, expected_count = preflight_curated_run(
        s3_client, arguments["curated_bucket"], arguments["run_id"]
    )
    print(json.dumps({
        "event": "CURATED_RUN_PREFLIGHT_PASSED",
        "runId": arguments["run_id"],
        "inputUri": input_uri,
        "expectedRecordCount": expected_count,
    }, sort_keys=True))

    spark = GlueContext(SparkContext.getOrCreate()).spark_session
    curated = read_and_validate_curated(spark, input_uri, expected_count)
    print(json.dumps({
        "event": "CURATED_RECORDS_VALIDATED",
        "runId": arguments["run_id"],
        "inputRecordCount": expected_count,
    }, sort_keys=True))

    features = build_rolling_features(curated).cache()
    counts = validate_features(features, expected_count)
    print(json.dumps({
        "event": "ROLLING_FEATURES_VALIDATED",
        "runId": arguments["run_id"],
        **counts,
    }, sort_keys=True))

    summary = write_feature_output(
        s3_client, features, arguments, input_uri, counts, started_at
    )
    print(json.dumps({"event": "FEATURE_RUN_PUBLISHED", **summary}, sort_keys=True))


if __name__ == "__main__":
    main()
