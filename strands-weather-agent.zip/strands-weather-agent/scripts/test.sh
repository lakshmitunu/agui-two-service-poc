#!/usr/bin/env bash
# 1) unit tests  2) smoke tests against the running container (run ./scripts/deploy.sh first)
set -euo pipefail
cd "$(dirname "$0")/.."
BASE=${BASE_URL:-http://localhost:8000}
pass() { echo "  PASS  $1"; }
fail() { echo "  FAIL  $1"; exit 1; }
field() { python3 -c "import sys,json; d=json.load(sys.stdin); print(eval('d'+sys.argv[1]))" "$1"; }

echo "== Unit tests =="
uv run pytest -q

echo "== Smoke tests against $BASE =="
curl -fsS "$BASE/healthz" >/dev/null || fail "service not reachable (run ./scripts/deploy.sh)"
pass "healthz"
PROVIDER=$(curl -fsS "$BASE/readyz" | field "['provider']")
echo "  provider: $PROVIDER"

R=$(curl -fsS -X POST "$BASE/v1/chat" -H 'content-type: application/json' \
     -d '{"message":"What is the weather in Paris?"}')
echo "$R" | python3 -m json.tool | sed 's/^/    /'
[[ $(echo "$R" | field "['tool_calls']") -ge 1 ]] && pass "agent called weather tools" || fail "no tool calls"
[[ $(echo "$R" | field "['usage']['output_tokens']") -gt 0 ]] && pass "usage reported" || fail "no usage"
R2=$(curl -fsS -X POST "$BASE/v1/chat" -H 'content-type: application/json' \
     -d '{"message":"What is the weather in Tokyo?"}')
echo "  second request cache_read_tokens=$(echo "$R2" | field "['usage']['cache_read_tokens']") (>0 means prompt cache hit)"

if [[ "$PROVIDER" == "stub" ]]; then
  L=$(curl -fsS -X POST "$BASE/v1/chat" -H 'content-type: application/json' \
       -d '{"message":"[stub:loop] keep checking"}')
  [[ $(echo "$L" | field "['limit_hit']") != "None" ]] && pass "limits enforced (limit_hit=$(echo "$L" | field "['limit_hit']"))" || fail "limit not enforced"
else
  echo "  (limit-trigger test skipped: only available with LLM_PROVIDER=stub)"
fi
echo "All checks passed. Logs: docker compose logs agent | tail   Traces: http://localhost:16686"
