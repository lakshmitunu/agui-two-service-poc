from fastapi.testclient import TestClient

from weather_agent.api.app import app


def test_chat_endpoint_returns_usage_and_request_id(monkeypatch, mock_weather):
    monkeypatch.setenv("LLM_PROVIDER", "stub")
    monkeypatch.setenv("OTEL_ENABLED", "false")
    with TestClient(app) as client:
        assert client.get("/healthz").json()["status"] == "ok"
        r = client.post("/v1/chat", json={"message": "Weather in Paris?"}, headers={"x-request-id": "abc123"})
    assert r.status_code == 200
    body = r.json()
    assert body["request_id"] == "abc123" and r.headers["x-request-id"] == "abc123"
    assert body["usage"]["cost_usd"] > 0 and body["tool_calls"] == 2


def test_empty_message_rejected(monkeypatch):
    monkeypatch.setenv("OTEL_ENABLED", "false")
    with TestClient(app) as client:
        assert client.post("/v1/chat", json={"message": ""}).status_code == 422
