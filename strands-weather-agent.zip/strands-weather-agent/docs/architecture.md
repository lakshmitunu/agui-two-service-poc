# Architecture and concept diagrams

All diagrams are [Mermaid](https://mermaid.js.org); they render on GitHub, in VS Code (Markdown Preview Mermaid Support) and at mermaid.live.

Contents: 1. System overview · 2. Agent loop and turn limit · 3. Tool-call limits · 4. Prompt caching · 5. Observability pipeline · 6. Token and cost accounting · 7. Docker topology · 8. Sequence diagrams

---

## 1. System overview

```mermaid
flowchart LR
    client["Client<br/>curl / app"] -->|"POST /v1/chat"| api

    subgraph container["agent container (FastAPI)"]
        api["API layer<br/>request-id middleware"] --> svc["Agent service<br/>run_agent()"]
        svc --> factory["Agent factory<br/>1 Agent per request"]
        factory --> agent["Strands Agent<br/>event loop"]
        hooks["Hooks<br/>LimitsHook + LoggingHook"] -.->|"lifecycle events"| agent
        agent --> tools["Tools<br/>geocode / current / forecast<br/>air quality / alerts"]
        svc --> usage["Usage + cost<br/>calculator"]
    end

    agent <-->|"messages + tools<br/>(cache breakpoints)"| claude["Claude API<br/>Anthropic"]
    tools -->|HTTPS| om["Open-Meteo<br/>geocoding, weather, AQI"]
    tools -->|HTTPS| nws["NWS<br/>US alerts"]

    api -->|"JSON logs (stdout)"| logs[("docker logs")]
    hooks -->|"JSON logs"| logs
    usage -->|"request.completed"| logs
    agent -->|"OTLP spans"| otel["OTel Collector"]
    otel --> jaeger["Jaeger UI<br/>:16686"]
```

**Layering rule:** `api` knows HTTP, `agent` knows Strands, `tools` know weather APIs, `observability` knows logs/OTEL/cost. Nothing points upward, so each layer can be tested alone.

---

## 2. Concept: agent loop and the turn limit

One **turn** = one model call. The loop repeats until the model answers without requesting a tool, or a limit stops it.

```mermaid
flowchart TD
    start(["request"]) --> bm["BeforeModelCallEvent<br/>LimitsHook"]
    bm --> chk{"turns >= MAX_TURNS?"}
    chk -- "yes" --> cancel["event.cancel = message<br/>limit_hit = max_turns"]
    cancel --> done
    chk -- "no" --> inc["turns += 1"]
    inc --> model["Model call (Claude)"]
    model --> stop{"stop_reason"}
    stop -- "tool_use" --> tools["Run requested tools<br/>(see diagram 3)"]
    tools --> bm
    stop -- "end_turn" --> done(["final answer"])
```

Why it matters: without a cap, a confused model can loop (call tool, misread, call again) and burn money. The cap is enforced **outside** the model, in code, so a prompt can never talk its way around it.

---

## 3. Concept: tool-call limits

```mermaid
flowchart TD
    req["Model requests tool X"] --> bt["BeforeToolCallEvent<br/>LimitsHook"]
    bt --> a{"total calls >= MAX_TOOL_CALLS?"}
    a -- "yes" --> block
    a -- "no" --> b{"calls of X >= MAX_CALLS_PER_TOOL?"}
    b -- "yes" --> block["event.cancel_tool = message<br/>tool is NOT executed<br/>limit_hit recorded"]
    b -- "no" --> count["counters += 1"] --> run["Execute tool<br/>HTTP call to weather API"]
    run --> res["tool result to model"]
    block --> err["error tool result to model:<br/>'limit reached, answer with what you have'"]
    res --> next["next turn"]
    err --> next
```

Two levels on purpose: the **total** cap bounds cost, the **per-tool** cap catches one tool being hammered. Blocked calls return an *explanation* to the model so it can degrade gracefully instead of failing.

---

## 4. Concept: prompt caching

The provider caches a **prefix** of the request. Order is fixed: `tools` then `system` then `messages`. A breakpoint (`cache_control`) says "cache everything up to here". Any change before a breakpoint invalidates it.

```mermaid
flowchart LR
    subgraph prefix["Request prefix, in order"]
        direction LR
        t["Tool definitions<br/>5 tools"] --> s["System prompt<br/>static, 1000+ tokens"] --> m1["Messages so far<br/>user + tool results"] --> m2["New content<br/>this turn"]
    end
    bp1(["breakpoint 1<br/>tools_ttl"]) -.-> t
    bp2(["breakpoint 2<br/>system_prompt_ttl"]) -.-> s
    bp3(["breakpoint 3<br/>last user message"]) -.-> m1
    m2 --> bill["Billed at base input rate"]
    prefix --> cached["Prefix before the breakpoint:<br/>first time = cache WRITE (1.25x)<br/>later within TTL = cache READ (0.1x)"]
```

Lifecycle of one cache entry:

```mermaid
stateDiagram-v2
    [*] --> Cold
    Cold --> Warm: "first call writes prefix (cache_write tokens, 1.25x)"
    Warm --> Warm: "call with identical prefix (cache_read tokens, 0.1x, TTL refreshed)"
    Warm --> Cold: "TTL expires (5 min default) or prefix changed"
```

Rules this project follows: keep the system prompt **static** (no timestamps or user data), keep tool order stable, and make the prefix **large enough** (minimum is about 1024 tokens for Sonnet-class models and higher for some others, below it nothing is cached and you will see zero cache tokens).

---

## 5. Concept: observability pipeline (logs, traces, usage)

```mermaid
flowchart TD
    req["HTTP request"] --> mw["Middleware<br/>creates request_id,<br/>binds to log context"]
    mw --> e1["log request.received"]
    e1 --> loop["Agent loop"]
    loop --> e2["log model.call"]
    loop --> e3["log agent.reasoning<br/>text + tool_requests per turn"]
    loop --> e4["log tool.call / tool.result<br/>args, status, duration"]
    loop --> e5["log limit.hit"]
    loop --> e6["log request.completed<br/>tokens, cache, cost, per-turn"]

    loop -.-> spans["OTEL spans (Strands built-in):<br/>invoke_agent, event_loop_cycle,<br/>chat, execute_tool"]
    spans --> col["OTel Collector"] --> jg["Jaeger"]

    e1 & e2 & e3 & e4 & e5 & e6 --> stdout[("stdout JSON")]

    stdout <-. "join key: trace_id" .-> jg
    stdout <-. "join key: request_id" .-> spans
```

Every log line carries `request_id` and `trace_id`, and the root agent span carries `request.id`. From a customer-reported request id you can find the logs, and from a log line you can open the exact trace.

---

## 6. Concept: token and cost accounting

```mermaid
flowchart LR
    resp["Claude response usage"] --> i["input_tokens<br/>uncached input"]
    resp --> w["cache_creation_input_tokens<br/>cache WRITE"]
    resp --> r["cache_read_input_tokens<br/>cache READ"]
    resp --> o["output_tokens"]

    i -->|"x input price"| ci["input cost"]
    w -->|"x input price x 1.25"| cw["cache write cost"]
    r -->|"x input price x 0.10"| cr["cache read cost"]
    o -->|"x output price"| co["output cost"]

    ci & cw & cr & co --> total["request cost_usd"]
    i & w & r -->|"all at base input price"| unc["uncached_equivalent_usd<br/>(what it would cost with no caching)"]
    total --> save["savings = uncached_equivalent - cost"]
    unc --> save
```

The four buckets are **disjoint** in Anthropic's API. Caution when reading OTEL: Strands' `gen_ai.usage.input_tokens` span attribute is the **sum** of all three input buckets, while this service's `input_tokens` field is the uncached bucket only. Prices live in `.env` so you can update them without code changes.

---

## 7. Docker deployment topology

```mermaid
flowchart LR
    dev["You<br/>curl, browser"] -->|"localhost:8000"| agent
    dev -->|"localhost:16686"| jaeger
    envf[".env<br/>LLM_PROVIDER, ANTHROPIC_API_KEY,<br/>limits, pricing"] -.->|"env_file"| agent

    subgraph net["docker compose network"]
        agent["agent<br/>python:3.12-slim, non-root<br/>:8000"] -->|"OTLP/HTTP :4318"| col["otel-collector<br/>contrib 0.111"]
        col -->|"OTLP/gRPC :4317"| jaeger["jaeger all-in-one<br/>UI :16686"]
    end

    agent -->|HTTPS| ext1["api.anthropic.com"]
    agent -->|HTTPS| ext2["open-meteo.com / weather.gov"]
```

Going from offline to real Claude is an `.env` change only: `LLM_PROVIDER=anthropic` and `ANTHROPIC_API_KEY=...`, then `./scripts/deploy.sh`.

---

## 8. Sequence diagrams

### 8a. Full request: two tool calls, cache write then reads

```mermaid
sequenceDiagram
    autonumber
    actor C as Client
    participant A as FastAPI
    participant S as Agent service
    participant G as Strands Agent
    participant H as Hooks
    participant L as Claude API
    participant T as Weather tools
    participant O as OTel then Jaeger

    C->>A: POST /v1/chat "Weather in Paris?"
    A->>A: create request_id, bind to log context
    A->>S: run_agent(question, request_id)
    S->>S: log request.received
    S->>G: build Agent (fresh state), invoke
    G-->>O: start span invoke_agent (request.id)

    rect rgb(235, 245, 255)
    Note over G,L: Turn 1 (cache WRITE)
    G->>H: BeforeModelCall (turns 0 to 1, under limit)
    G->>L: tools + system + user msg (cache breakpoints)
    L-->>G: text + tool_use geocode_location (usage: cache_write)
    G->>H: AfterModelCall, log agent.reasoning
    G->>H: BeforeToolCall (count 1, allowed)
    G->>T: geocode_location("Paris")
    T-->>G: coordinates
    G->>H: AfterToolCall, log tool.result
    end

    rect rgb(235, 255, 240)
    Note over G,L: Turn 2 (cache READ)
    G->>H: BeforeModelCall (turns 1 to 2)
    G->>L: same prefix + tool result
    L-->>G: tool_use get_current_weather (usage: cache_read)
    G->>T: get_current_weather(lat, lon)
    T-->>G: temperature, wind, conditions
    end

    rect rgb(235, 255, 240)
    Note over G,L: Turn 3 (cache READ, final)
    G->>H: BeforeModelCall (turns 2 to 3)
    G->>L: prefix + both tool results
    L-->>G: final answer (end_turn)
    end

    G-->>O: end spans (chat, execute_tool, token attributes)
    G-->>S: AgentResult + metrics
    S->>S: sum usage, compute cost, log request.completed
    S-->>A: answer + usage + cost
    A-->>C: 200 JSON (x-request-id header)
```

### 8b. Limit exceeded: model keeps asking for tools

```mermaid
sequenceDiagram
    autonumber
    actor C as Client
    participant G as Strands Agent
    participant H as LimitsHook
    participant L as Claude API
    participant T as Weather tools

    C->>G: question (MAX_TOOL_CALLS=2, MAX_TURNS=6)
    loop turns 1 and 2
        G->>H: BeforeModelCall (allowed)
        G->>L: request
        L-->>G: tool_use
        G->>H: BeforeToolCall (count under 2, allowed)
        G->>T: execute
        T-->>G: result
    end
    G->>H: BeforeModelCall (turn 3, allowed)
    G->>L: request
    L-->>G: tool_use again
    G->>H: BeforeToolCall
    H-->>G: cancel_tool = "limit reached, answer with what you have", log limit.hit
    Note over G,T: tool NOT executed
    G->>H: BeforeModelCall (turn 4)
    G->>L: request incl. the blocked-call explanation
    L-->>G: final answer from existing data (end_turn)
    G-->>C: answer, limit_hit = max_tool_calls
    Note over G,H: if the model ignores the message and keeps asking, MAX_TURNS cancels the model call and the loop ends
```
