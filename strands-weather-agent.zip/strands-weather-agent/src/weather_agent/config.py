"""Central configuration. Everything tunable comes from environment variables / .env."""

from functools import lru_cache
from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- LLM -------------------------------------------------------------
    # "stub" runs a scripted offline model so the whole pipeline works without a key.
    # Switch to "anthropic" and set ANTHROPIC_API_KEY to use real Claude.
    llm_provider: Literal["anthropic", "stub"] = "stub"
    anthropic_api_key: SecretStr | None = None
    model_id: str = "claude-sonnet-5-5"
    max_output_tokens: int = Field(default=1024, ge=64)
    temperature: float = Field(default=0.2, ge=0, le=1)

    # --- Prompt caching --------------------------------------------------
    prompt_caching_enabled: bool = True
    cache_ttl: str | None = None  # None = provider default (5m); "1h" for the extended TTL

    # --- Guardrails ------------------------------------------------------
    max_turns: int = Field(default=6, ge=1)  # max model calls per request
    max_tool_calls: int = Field(default=8, ge=0)  # max tool calls per request (all tools)
    max_calls_per_tool: int = Field(default=4, ge=0)  # max calls of any single tool per request

    # --- Pricing (USD per million tokens). VERIFY against current Anthropic pricing. ---
    price_input_per_mtok: float = 3.0
    price_output_per_mtok: float = 15.0
    cache_write_multiplier: float = 1.25  # 5-minute cache writes cost 1.25x base input
    cache_read_multiplier: float = 0.10  # cache reads cost 0.1x base input

    # --- Observability ---------------------------------------------------
    log_level: str = "INFO"
    log_format: Literal["json", "console"] = "json"
    log_message_chars: int = 500  # truncate user messages / reasoning text in logs
    otel_enabled: bool = True
    otel_console_exporter: bool = False
    otel_service_name: str = "strands-weather-agent"
    # Standard OTel env var; the SDK reads it directly. Empty = no OTLP export.
    otel_exporter_otlp_endpoint: str = ""

    # --- Weather APIs ----------------------------------------------------
    http_timeout_seconds: float = 10.0
    open_meteo_forecast_url: str = "https://api.open-meteo.com/v1/forecast"
    open_meteo_geocoding_url: str = "https://geocoding-api.open-meteo.com/v1/search"
    open_meteo_air_quality_url: str = "https://air-quality-api.open-meteo.com/v1/air-quality"
    nws_alerts_url: str = "https://api.weather.gov/alerts/active"
    nws_user_agent: str = "strands-weather-agent-learning (contact: you@example.com)"


@lru_cache
def get_settings() -> Settings:
    return Settings()
