"""Strands weather agent: a learning project for agent limits, caching, logging, OTEL and cost."""

__version__ = "0.1.0"
