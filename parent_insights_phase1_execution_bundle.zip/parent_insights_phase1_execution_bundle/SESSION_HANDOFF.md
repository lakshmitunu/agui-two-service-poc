# VSF Parent Insights - Phase 1 Session Handoff

## Objective

Build personalized communication anomaly detection using historical call and text activity.

The first ML comparison will be:

```text
Baseline: personalized rolling averages and Z-scores
Candidate: Isolation Forest
```

Isolation Forest will be selected only if it provides useful improvement over the simpler baseline.

## Current status

### Phase 1A - AWS foundation: complete

Region:

```text
us-east-2
```

AWS CLI profile:

```text
parent-insights-personal
```

CloudFormation stack:

```text
vsf-parent-insights
```

Created resources:

```text
S3: vsf-parent-insights-raw
S3: vsf-parent-insights-curated
S3: vsf-parent-insights-features
S3: vsf-parent-insights-models
Glue database: vsf_parent_insights
IAM role: vsf-parent-insights-glue-role
IAM role: vsf-parent-insights-sagemaker-role
```

All S3 buckets have:

- Versioning enabled
- AES-256 server-side encryption
- All public-access settings blocked

AWS Budget creation was intentionally postponed.

The deployment script uses a CloudFormation change set, verifies existing buckets, displays proposed changes, requires typing `apply`, and exits cleanly when no changes exist.

## Phase 1B - Data preparation: current checkpoint

Project root:

```text
/Volumes/work/codex_projects/parent_insights
```

Data-preparation folder:

```text
/Volumes/work/codex_projects/parent_insights/phase1b-data-preparation
```

Completed files:

```text
daily-communication-data-contract.md
daily-communication.schema.json
profile-config.json
generate_daily_history.py
daily-history.jsonl
prepare_raw_history.py
```

### Agreed daily fields

```text
childProfileId
aggDate
timezone
communicationStatus
callCount
textCount
nightCount
nightStartTime
nightEndTime
schoolCount
schoolStartTime
schoolEndTime
```

Definitions:

- `callCount`: all daily calls
- `textCount`: all daily texts
- `nightCount`: calls inside the configured night window
- `schoolCount`: calls inside the configured school window
- Night and school calls are subsets of total calls
- Weekend school calls must be zero

Screen time, security, location, driving, events, identity/display fields, watchlists, and source trend percentages are excluded from ML version 1.

### Synthetic history

```text
Profiles: 10
Days per profile: 60
Records: 600
Date range: 2026-04-06 through 2026-06-04
Intentional anomalies: none
```

Each profile has documented hidden normal behavior in `profile-config.json`. These settings are used only to generate synthetic history and are not provided to the ML model.

### Raw batch

Local batch:

```text
/Volumes/work/codex_projects/parent_insights/raw-batches/run_id=20260830T055411Z
```

Contents:

```text
part-00000.jsonl.gz
manifest.json
_SUCCESS
```

Verified manifest:

```text
profileCount: 10
recordCount: 600
fileCount: 1
status: COMPLETE
```

Uploaded and verified at:

```text
s3://vsf-parent-insights-raw/daily-communication/history/run_id=20260830T055411Z/
```

The older `source=synthetic` prefix was removed. The current historical path is the authoritative one.

## Next task

Create and understand Glue Job 1:

```text
Raw JSONL Gzip
→ Read only a completed run with _SUCCESS
→ Validate the 12-field contract and cross-field rules
→ Valid records to curated Parquet with Snappy compression
→ Invalid records to quarantine with failure reasons
→ Produce a validation summary
```

The raw data must remain unchanged.

Do not create the feature job yet. First implement Glue Job 1, run it against the 600-record batch, and inspect the curated and quarantine results.

## Remaining Phase 1 steps

1. Implement and run Glue Job 1: raw to curated.
2. Verify curated Parquet and quarantine results.
3. Implement Glue Job 2: 7-day and 30-day features.
4. Review features for selected profiles.
5. Build the rolling-average/Z-score baseline.
6. Train and evaluate Isolation Forest.
7. Compare both approaches and register the selected model.

## Suggested prompt for a new session

```text
Continue the VSF Parent Insights Phase 1 implementation using the handoff summary at /Volumes/work/codex_projects/parent_insights/SESSION_HANDOFF.md. Work one step at a time and explain each step briefly because I am learning machine learning. Start with the design of Glue Job 1: raw JSONL Gzip to validated curated Parquet. Do not create multiple components at once.
```
