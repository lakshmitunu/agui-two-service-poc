#!/usr/bin/env python3
import argparse
import gzip
import hashlib
import json
from datetime import date, datetime, timezone
from pathlib import Path


REQUIRED_FIELDS = {
    "childProfileId",
    "aggDate",
    "timezone",
    "communicationStatus",
    "callCount",
    "textCount",
    "nightCount",
    "nightStartTime",
    "nightEndTime",
    "schoolCount",
    "schoolStartTime",
    "schoolEndTime",
}


def parse_args():
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Package daily communication history as a raw ingestion batch.")
    parser.add_argument("--input", type=Path, default=script_dir / "daily-history.jsonl")
    parser.add_argument("--output-root", type=Path, default=script_dir.parent / "raw-batches")
    parser.add_argument("--records-per-part", type=int, default=25000)
    return parser.parse_args()


def validate_record(record, line_number):
    missing = REQUIRED_FIELDS - set(record)
    if missing:
        raise ValueError(f"Line {line_number}: missing fields {sorted(missing)}")

    activity_date = date.fromisoformat(record["aggDate"])
    counts = [record["callCount"], record["textCount"], record["nightCount"], record["schoolCount"]]
    if any(not isinstance(value, int) or value < 0 for value in counts):
        raise ValueError(f"Line {line_number}: counts must be nonnegative integers")
    if record["nightCount"] + record["schoolCount"] > record["callCount"]:
        raise ValueError(f"Line {line_number}: night and school calls exceed total calls")
    if activity_date.weekday() >= 5 and record["schoolCount"] != 0:
        raise ValueError(f"Line {line_number}: weekend schoolCount must be zero")
    if record["communicationStatus"] == "INACTIVE" and any(counts):
        raise ValueError(f"Line {line_number}: inactive record contains activity")
    return activity_date


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_part(run_dir, part_number, records):
    path = run_dir / f"part-{part_number:05d}.jsonl.gz"
    with gzip.open(path, "wt", encoding="utf-8", newline="\n") as output:
        for record in records:
            output.write(json.dumps(record, separators=(",", ":")) + "\n")
    return {
        "name": path.name,
        "recordCount": len(records),
        "compressedBytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def main():
    args = parse_args()
    if args.records_per_part < 1:
        raise ValueError("--records-per-part must be greater than zero")

    generated_at = datetime.now(timezone.utc)
    run_id = generated_at.strftime("%Y%m%dT%H%M%SZ")
    run_dir = args.output_root / f"run_id={run_id}"
    run_dir.mkdir(parents=True, exist_ok=False)

    profiles = set()
    record_keys = set()
    dates = []
    part_records = []
    parts = []
    total_records = 0

    with args.input.open("r", encoding="utf-8") as source:
        for line_number, line in enumerate(source, start=1):
            if not line.strip():
                continue
            record = json.loads(line)
            activity_date = validate_record(record, line_number)
            key = (record["childProfileId"], record["aggDate"])
            if key in record_keys:
                raise ValueError(f"Line {line_number}: duplicate profile/date key {key}")
            record_keys.add(key)
            profiles.add(record["childProfileId"])
            dates.append(activity_date)
            part_records.append(record)
            total_records += 1

            if len(part_records) == args.records_per_part:
                parts.append(write_part(run_dir, len(parts), part_records))
                part_records = []

    if part_records:
        parts.append(write_part(run_dir, len(parts), part_records))
    if not parts:
        raise ValueError("Input history contains no records")

    manifest = {
        "schemaVersion": "1.0",
        "runId": run_id,
        "generatedAt": generated_at.isoformat().replace("+00:00", "Z"),
        "sourceFile": args.input.name,
        "startDate": min(dates).isoformat(),
        "endDate": max(dates).isoformat(),
        "profileCount": len(profiles),
        "recordCount": total_records,
        "fileCount": len(parts),
        "status": "COMPLETE",
        "files": parts,
    }
    (run_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    (run_dir / "_SUCCESS").touch()

    print(f"Created raw batch: {run_dir}")
    print(f"Records: {total_records}; profiles: {len(profiles)}; parts: {len(parts)}")


if __name__ == "__main__":
    main()
