# Parent Insights - Phase 1A AWS Setup

The automation creates the Phase 1A data foundation in `us-east-2`:

- Raw historical data bucket
- Curated data bucket
- Feature data bucket
- Model artifact bucket
- AWS Glue Data Catalog database: `vsf_parent_insights`
- AWS Glue execution role: `vsf-parent-insights-glue-role`
- SageMaker training execution role: `vsf-parent-insights-sagemaker-role`

All buckets block public access, use S3-managed encryption, enable versioning, and carry project/environment tags.

## Defaults

```text
AWS profile: parent-insights-personal
AWS Region: us-east-2
CloudFormation stack: vsf-parent-insights
```

The resulting buckets are:

```text
vsf-parent-insights-raw
vsf-parent-insights-curated
vsf-parent-insights-features
vsf-parent-insights-models
```

## Deploy

```bash
chmod +x deploy.sh cleanup.sh
./deploy.sh
```

For an existing stack, the deployment script first verifies all managed buckets, creates a CloudFormation change set, displays the exact proposed changes, and requires typing `apply`. It exits without deployment when no changes exist.

## Cleanup

Cleanup permanently removes every object and version in the stack's buckets before deleting the stack:

```bash
./cleanup.sh
```

The script requires typing the exact stack name before deletion.

## Verify bucket protection

The verification checks versioning, S3-managed encryption, and all public-access-block settings:

```bash
./verify-buckets.sh
```

## Verify the Glue Data Catalog database

```bash
./verify-glue.sh
```

## Verify the Glue execution role

```bash
./verify-glue-role.sh
```

## Verify the SageMaker execution role

```bash
./verify-sagemaker-role.sh
```
