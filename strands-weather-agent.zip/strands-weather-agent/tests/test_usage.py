from weather_agent.config import Settings
from weather_agent.observability.usage import TokenUsage, compute_cost


def test_cost_math_and_cache_savings():
    s = Settings(_env_file=None, price_input_per_mtok=3.0, price_output_per_mtok=15.0,
                 cache_write_multiplier=1.25, cache_read_multiplier=0.1)
    t = TokenUsage(input_tokens=1000, output_tokens=500, cache_read_tokens=10000, cache_write_tokens=2000)
    c = compute_cost(t, s)
    assert c.input_usd == 0.003
    assert c.output_usd == 0.0075
    assert c.cache_write_usd == 0.0075  # 2000 * 3e-6 * 1.25
    assert c.cache_read_usd == 0.003  # 10000 * 3e-6 * 0.1
    assert c.total_usd == 0.021
    assert c.uncached_equivalent_usd > c.total_usd  # caching saved money
    assert t.cache_hit_ratio == round(10000 / 13000, 4)


def test_from_strands_handles_missing_cache_fields():
    t = TokenUsage.from_strands({"inputTokens": 10, "outputTokens": 5, "totalTokens": 15})
    assert (t.cache_read_tokens, t.cache_write_tokens) == (0, 0)
