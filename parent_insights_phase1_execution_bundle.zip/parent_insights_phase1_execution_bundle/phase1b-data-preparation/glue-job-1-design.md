# Glue Job 1 Design: Raw Daily Communication to Curated Parquet

## At a glance

### Input

One completed raw ingestion run:

```text
s3://vsf-parent-insights-raw/daily-communication/history/run_id=<run-id>/
```

It contains:

- one or more `part-*.jsonl.gz` data files;
- `manifest.json`, which describes the expected files and record counts;
- `_SUCCESS`, which signals that raw-batch creation finished.

### What the job does

1. Confirms the raw run is complete and matches its manifest.
2. Reads only the data files named in the manifest.
3. Validates every record against the 12-field contract.
4. Checks cross-field rules and duplicate profile/date keys.
5. Separates valid records from invalid records.
6. Reconciles all record counts and writes a validation summary.

This is data preparation, not ML training. It makes the historical data reliable before features or anomaly models use it.

### Output

The job writes three run-specific results:

| Result | Format | Location |
|---|---|---|
| Valid curated records | Snappy Parquet | `s3://vsf-parent-insights-curated/daily-communication/run_id=<run-id>/data/` |
| Invalid quarantined records | Snappy Parquet | `s3://vsf-parent-insights-curated/daily-communication-quarantine/run_id=<run-id>/data/` |
| Validation summary | JSON | `s3://vsf-parent-insights-curated/daily-communication-validation/run_id=<run-id>/summary.json` |

The raw input is never changed.

### Flow diagram

```mermaid
flowchart LR
    A["Raw run<br/>JSONL Gzip + manifest + _SUCCESS"]
    B{"Run complete<br/>and manifest valid?"}
    C["Read only manifest-listed files"]
    D["Validate 12-field contract<br/>and cross-field rules"]
    E{"Record valid?"}
    F["Curated Parquet<br/>Snappy compressed"]
    G["Quarantine Parquet<br/>with failure reasons"]
    H["Validation summary JSON"]
    X["Fail job<br/>write no final output"]

    A --> B
    B -- No --> X
    B -- Yes --> C
    C --> D
    D --> E
    E -- Yes --> F
    E -- No --> G
    F --> H
    G --> H
```

## 1. Purpose and boundary

Glue Job 1 converts one immutable, completed raw ingestion run into validated data for later machine-learning work.

```text
Raw .jsonl.gz run
  -> run-level checks
  -> record and dataset validation
  -> valid curated Parquet
  -> invalid quarantine Parquet
  -> validation summary JSON
```

This job does not calculate rolling features, anomaly scores, or model inputs. Those belong to later jobs.

## 2. Job arguments

The job processes exactly one run, supplied explicitly:

| Argument | Example | Purpose |
|---|---|---|
| `--run-id` | `20260830T055411Z` | Prevents the job from accidentally mixing ingestion runs. |
| `--raw-bucket` | `vsf-parent-insights-raw` | Raw source bucket. |
| `--curated-bucket` | `vsf-parent-insights-curated` | Destination bucket for valid, quarantined, and summary data. |

The input prefix is derived rather than accepted as a free-form path:

```text
s3://<raw-bucket>/daily-communication/history/run_id=<run-id>/
```

## 3. Run-level preflight checks

### Preflight step: input, action, and output

**Input:** `--run-id`, `--raw-bucket`, `_SUCCESS`, `manifest.json`, and the raw `part-*.jsonl.gz` objects for that run.

**What it does:** checks completion markers, manifest structure and totals, safe part names, object existence, compressed sizes, SHA-256 checksums, and whether unexpected part files are present.

**Output:** a verified manifest and an ordered list of exact S3 part URIs held in job memory. This step writes no S3 data. A failed check raises an error and stops the job.

```mermaid
flowchart TD
    A["run_id + raw bucket"] --> B["Build exact raw run prefix"]
    B --> C{"_SUCCESS exists?"}
    C -- No --> X["Fail preflight"]
    C -- Yes --> D["Load and validate manifest"]
    D --> E{"Manifest complete<br/>and totals consistent?"}
    E -- No --> X
    E -- Yes --> F["Verify listed objects<br/>size + SHA-256"]
    F --> G{"All files match and<br/>no unlisted parts?"}
    G -- No --> X
    G -- Yes --> H["Return verified manifest<br/>+ exact S3 part URIs"]
```

The driver performs these checks before starting a Spark transformation:

1. `_SUCCESS` exists.
2. `manifest.json` exists and is valid JSON.
3. `manifest.status` is `COMPLETE`.
4. `manifest.runId` equals `--run-id`.
5. The manifest's file list is nonempty and contains unique, safe names matching `part-*.jsonl.gz`.
6. Every listed part exists and its compressed byte size and SHA-256 digest match the manifest.
7. No unlisted `part-*.jsonl.gz` object exists under the run prefix.

If any preflight check fails, the job fails before writing output. This is different from quarantining a bad record: a broken or incomplete run cannot be trusted as a dataset.

Spark reads only the exact part paths named by the verified manifest. It never reads the whole prefix with a wildcard.

## 4. Record ingestion strategy

### Ingestion step: input, action, and output

**Input:** the ordered, exact `partUris` returned by the successful raw-run preflight.

**What it does:** Spark decompresses each `.jsonl.gz` object, reads one physical line as one record, retains its S3 source filename, calculates a stable SHA-256 fingerprint, and counts all input lines.

**Output:** an in-memory Spark DataFrame with `rawRecord`, `sourceFile`, and `recordFingerprint`. The physical input count must equal `manifest.recordCount`; otherwise the job fails before record parsing or curated writes.

```mermaid
flowchart LR
    A["Verified manifest<br/>+ exact part URIs"]
    B["Spark reads JSONL Gzip<br/>as text lines"]
    C["Add sourceFile"]
    D["Add SHA-256<br/>recordFingerprint"]
    E["Count physical records"]
    F{"Count equals<br/>manifest count?"}
    G["Return in-memory<br/>raw-record DataFrame"]
    X["Fail job;<br/>write no curated data"]

    A --> B --> C --> D --> E --> F
    F -- Yes --> G
    F -- No --> X
```

Spark reads the Gzip files as text, preserving:

- `rawRecord`: the original JSON line
- `sourceFile`: the S3 object that contained it
- `recordFingerprint`: SHA-256 of `rawRecord`, used as a stable quarantine identifier

Each line is parsed in permissive mode. Malformed JSON becomes an invalid record rather than crashing the complete job.

The parser retains the input object's keys before projecting the 12 curated fields. This is required to detect unexpected fields; reading directly into a 12-field struct could silently discard them.

## 5. Validation rules and reason codes

### JSON parsing and structural-validation step

**Input:** the in-memory Spark DataFrame produced by ingestion:

```text
rawRecord
sourceFile
recordFingerprint
```

The current sample input file is:

```text
s3://vsf-parent-insights-raw/daily-communication/history/
run_id=20260830T055411Z/part-00000.jsonl.gz
```

After Gzip decompression, one input line looks like:

```json
{
  "childProfileId": 9001,
  "aggDate": "2026-06-04",
  "timezone": "America/New_York",
  "communicationStatus": "ACTIVE",
  "callCount": 12,
  "textCount": 25,
  "nightCount": 3,
  "nightStartTime": "21:00",
  "nightEndTime": "06:00",
  "schoolCount": 5,
  "schoolStartTime": "08:00",
  "schoolEndTime": "15:00"
}
```

Spark initially holds that complete line in `rawRecord`; `sourceFile` identifies the S3 object, and `recordFingerprint` identifies the exact line contents.

**What it does:** parses each raw line as one JSON object, retains the original input keys so unexpected fields cannot be silently discarded, and checks the required 12 fields for nullability, JSON type, permitted values, and basic single-field constraints.

**Output:** one in-memory validation DataFrame containing the recoverable 12 contract values plus `failureReasons`. A row with an empty `failureReasons` array is structurally valid; a row with one or more reasons is structurally invalid. This step does not yet apply cross-field rules or write S3 output.

Example structurally valid output:

```json
{
  "childProfileId": 9001,
  "aggDate": "2026-06-04",
  "timezone": "America/New_York",
  "communicationStatus": "ACTIVE",
  "callCount": 12,
  "textCount": 25,
  "nightCount": 3,
  "nightStartTime": "21:00",
  "nightEndTime": "06:00",
  "schoolCount": 5,
  "schoolStartTime": "08:00",
  "schoolEndTime": "15:00",
  "failureReasons": []
}
```

Example invalid input line:

```json
{
  "childProfileId": 9001,
  "aggDate": "2026-06-04",
  "timezone": "America/New_York",
  "communicationStatus": "ACTIVE",
  "callCount": "twelve",
  "textCount": 25,
  "nightCount": 3,
  "nightStartTime": "21:00",
  "nightEndTime": "06:00",
  "schoolCount": 5,
  "schoolStartTime": "08:00",
  "schoolEndTime": "15:00",
  "displayName": "Example Child"
}
```

Example structurally invalid output:

```json
{
  "childProfileId": 9001,
  "aggDate": "2026-06-04",
  "callCount": null,
  "failureReasons": [
    "INVALID_TYPE:callCount",
    "UNEXPECTED_FIELD:displayName"
  ]
}
```

This is still an intermediate Spark result held in memory. Valid curated Parquet and invalid quarantine Parquet are written only after cross-field and duplicate validation also finish.

```mermaid
flowchart TD
    A["In-memory raw records"]
    B["Parse each line as<br/>one JSON object"]
    C{"Valid JSON object?"}
    D["Capture input keys and<br/>project 12 contract fields"]
    E["Check missing and<br/>unexpected fields"]
    F["Check JSON types and<br/>single-field constraints"]
    G["Attach all applicable<br/>failureReasons"]
    H["Structurally valid row<br/>empty failureReasons"]
    I["Structurally invalid row<br/>one or more reasons"]

    A --> B --> C
    C -- No --> I
    C -- Yes --> D --> E --> F --> G
    G --> H
    G --> I
```

Parsing is permissive at the dataset level: one malformed line must not crash the complete Spark read. Validation is strict at the record level: JSON strings are not accepted for integer fields, decimal numbers are not accepted as integers, booleans are not integers, and the JSON root must be an object.

The parser collects all independently applicable structural reasons for a record. Rules that depend on a successfully typed value are evaluated only after that prerequisite passes, preventing misleading secondary failures.

An invalid record may have more than one reason. `failureReasons` is an array so that one job run gives a complete diagnosis.

### Shape and type rules

| Reason code | Condition |
|---|---|
| `MALFORMED_JSON` | The line is not one valid JSON object. |
| `MISSING_FIELD:<field>` | A required field is absent or null. |
| `UNEXPECTED_FIELD:<field>` | A key is not one of the agreed 12 fields. |
| `INVALID_TYPE:<field>` | A field is not its contract type; booleans and decimal values are not integers. |
| `INVALID_CHILD_PROFILE_ID` | `childProfileId` is less than 1. |
| `NEGATIVE_COUNT:<field>` | A count is less than zero. |
| `INVALID_DATE` | `aggDate` is not a real `YYYY-MM-DD` calendar date. |
| `INVALID_TIME:<field>` | A time is not `HH:MM` in the 24-hour range. |
| `INVALID_TIMEZONE` | `timezone` is not a recognized IANA zone name. |
| `INVALID_COMMUNICATION_STATUS` | Status is not `ACTIVE` or `INACTIVE`. |

### Cross-field rules

| Reason code | Condition |
|---|---|
| `NIGHT_COUNT_EXCEEDS_CALL_COUNT` | `nightCount > callCount`. |
| `SCHOOL_COUNT_EXCEEDS_CALL_COUNT` | `schoolCount > callCount`. |
| `DISJOINT_WINDOW_COUNTS_EXCEED_CALL_COUNT` | Night and school windows do not overlap, but their counts sum to more than `callCount`. |
| `INACTIVE_WITH_ACTIVITY` | An `INACTIVE` record has any nonzero count. |
| `WEEKEND_SCHOOL_ACTIVITY` | Saturday or Sunday has a nonzero `schoolCount`. |

Window overlap is calculated on a 24-hour clock. A window that crosses midnight, such as `21:00` to `06:00`, is split into two intervals before comparing it with the school window. Start is inclusive and end is exclusive, matching the data contract.

### Dataset-level rule

| Reason code | Condition |
|---|---|
| `DUPLICATE_PROFILE_DATE` | More than one otherwise valid record has the same `childProfileId + aggDate`. |

All members of a duplicate key are quarantined. Keeping an arbitrary first row would make the ML history depend on Spark execution order.

Rules that require a successfully parsed value are evaluated only when their prerequisite fields are valid. This avoids misleading secondary errors.

## 6. Outputs

All outputs are isolated by `run_id`:

```text
s3://vsf-parent-insights-curated/daily-communication/run_id=<run-id>/data/
s3://vsf-parent-insights-curated/daily-communication-quarantine/run_id=<run-id>/data/
s3://vsf-parent-insights-curated/daily-communication-validation/run_id=<run-id>/summary.json
```

### Valid output

Valid rows contain exactly the 12 contract fields. `aggDate` is stored as Parquet `date`; identifiers and counts are stored as integral values; the remaining fields are strings. Data is written as Parquet with Snappy compression.

The first implementation will not add physical date partitions. This batch has only 600 rows, and tiny partitions would create many tiny S3 objects. Partitioning can be revisited when real data volume and query patterns are known.

### Quarantine output

Quarantine is also Snappy-compressed Parquet and contains:

```text
runId
sourceFile
recordFingerprint
rawRecord
childProfileId (nullable, when recoverable)
aggDate (nullable, when recoverable)
failureReasons
```

The raw bucket is never modified.

### Validation summary

The single JSON summary contains at least:

```text
runId
startedAt
completedAt
status
manifestRecordCount
inputRecordCount
validRecordCount
invalidRecordCount
duplicateKeyCount
failureReasonCounts
validOutputUri
quarantineOutputUri
```

The job succeeds when processing completes, even if some rows are quarantined, but the summary reports `status: COMPLETED_WITH_INVALID_RECORDS`. A run-level preflight failure or an output-count reconciliation failure makes the Glue job fail.

The following invariant must hold before completion:

```text
inputRecordCount = validRecordCount + invalidRecordCount = manifestRecordCount
```

## 7. Rerun behavior

The first implementation is fail-safe: if any output already exists for the same `run_id`, the job stops without overwriting it. Raw runs are immutable, so the same run should not produce changing curated results. A deliberate replacement procedure can be designed later if job logic changes.

Spark writes data to temporary run-scoped prefixes first. After record counts reconcile, the job promotes the outputs and writes `summary.json` last. The summary therefore acts as the curated run's completion marker.

## 8. Initial acceptance criteria

For `run_id=20260830T055411Z`:

- preflight accepts the verified one-file manifest;
- `inputRecordCount` is 600;
- `validRecordCount` is 600;
- `invalidRecordCount` is 0;
- curated Parquet contains 10 profiles and 60 dates per profile;
- the curated schema has exactly the 12 contracted columns and expected types;
- the quarantine dataset is empty or absent, as documented by the summary;
- the raw S3 objects remain byte-for-byte unchanged.

Before calling the validator complete, a separate small test run should intentionally exercise every reason code. That tests the validation logic; the clean 600-row batch alone tests only the happy path.
