from weather_agent.tools import ALL_TOOLS
from weather_agent.tools.open_meteo import geocode_location, get_current_weather


def test_registry_exposes_five_tools():
    assert len(ALL_TOOLS) == 5


def test_geocode_and_current(mock_weather):
    geo = geocode_location(name="Paris")
    assert geo["matches"][0]["latitude"] == 48.85
    wx = get_current_weather(latitude=48.85, longitude=2.35)
    assert wx["conditions"] == "overcast" and wx["temperature_c"] == 14.2


def test_upstream_failure_is_returned_not_raised(respx_mock):
    respx_mock.get("https://geocoding-api.open-meteo.com/v1/search").respond(status_code=503)
    assert "error" in geocode_location(name="Paris")
