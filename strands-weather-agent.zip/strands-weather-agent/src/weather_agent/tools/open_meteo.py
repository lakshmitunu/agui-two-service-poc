"""Open-Meteo tools (free, no API key). Tools never raise: errors are returned as data so the
model can recover or explain, instead of crashing the loop."""

from strands import tool

from weather_agent.clients.http import UpstreamError, get_json
from weather_agent.config import get_settings

WMO_CODES = {
    0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast",
    45: "fog", 48: "rime fog", 51: "light drizzle", 53: "drizzle", 55: "dense drizzle",
    61: "light rain", 63: "rain", 65: "heavy rain", 71: "light snow", 73: "snow", 75: "heavy snow",
    80: "rain showers", 81: "heavy rain showers", 82: "violent rain showers",
    95: "thunderstorm", 96: "thunderstorm with hail", 99: "severe thunderstorm with hail",
}


def _describe(code: int | None) -> str:
    return WMO_CODES.get(code, f"weather code {code}") if code is not None else "unknown"


@tool
def geocode_location(name: str) -> dict:
    """Convert a place name (city, town) into coordinates. Call this first for any weather question.

    Args:
        name: Place name, e.g. "Paris" or "Austin, Texas".
    """
    s = get_settings()
    try:
        data = get_json(s.open_meteo_geocoding_url, {"name": name, "count": 3, "language": "en"})
    except UpstreamError as e:
        return {"error": str(e)}
    results = data.get("results") or []
    if not results:
        return {"error": f"no location found for '{name}'"}
    return {
        "matches": [
            {
                "name": r["name"],
                "region": r.get("admin1"),
                "country": r.get("country"),
                "latitude": r["latitude"],
                "longitude": r["longitude"],
                "timezone": r.get("timezone"),
            }
            for r in results
        ]
    }


@tool
def get_current_weather(latitude: float, longitude: float) -> dict:
    """Get current weather conditions for coordinates (temperature in C, wind in km/h).

    Args:
        latitude: Latitude in decimal degrees.
        longitude: Longitude in decimal degrees.
    """
    s = get_settings()
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "current": "temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m",
        "timezone": "auto",
    }
    try:
        cur = get_json(s.open_meteo_forecast_url, params).get("current", {})
    except UpstreamError as e:
        return {"error": str(e)}
    return {
        "time": cur.get("time"),
        "conditions": _describe(cur.get("weather_code")),
        "temperature_c": cur.get("temperature_2m"),
        "feels_like_c": cur.get("apparent_temperature"),
        "humidity_pct": cur.get("relative_humidity_2m"),
        "precipitation_mm": cur.get("precipitation"),
        "wind_kmh": cur.get("wind_speed_10m"),
    }


@tool
def get_forecast(latitude: float, longitude: float, days: int = 3) -> dict:
    """Get a daily forecast (max/min temperature in C, precipitation probability, conditions).

    Args:
        latitude: Latitude in decimal degrees.
        longitude: Longitude in decimal degrees.
        days: Number of days, 1 to 7.
    """
    s = get_settings()
    days = max(1, min(int(days), 7))
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max",
        "forecast_days": days,
        "timezone": "auto",
    }
    try:
        d = get_json(s.open_meteo_forecast_url, params).get("daily", {})
    except UpstreamError as e:
        return {"error": str(e)}
    return {
        "days": [
            {
                "date": d["time"][i],
                "conditions": _describe(d["weather_code"][i]),
                "max_c": d["temperature_2m_max"][i],
                "min_c": d["temperature_2m_min"][i],
                "precip_probability_pct": d["precipitation_probability_max"][i],
            }
            for i in range(len(d.get("time", [])))
        ]
    }


@tool
def get_air_quality(latitude: float, longitude: float) -> dict:
    """Get current air quality (European AQI, PM2.5, PM10) for coordinates.

    Args:
        latitude: Latitude in decimal degrees.
        longitude: Longitude in decimal degrees.
    """
    s = get_settings()
    params = {"latitude": latitude, "longitude": longitude, "current": "european_aqi,pm2_5,pm10"}
    try:
        cur = get_json(s.open_meteo_air_quality_url, params).get("current", {})
    except UpstreamError as e:
        return {"error": str(e)}
    return {"european_aqi": cur.get("european_aqi"), "pm2_5": cur.get("pm2_5"), "pm10": cur.get("pm10")}
