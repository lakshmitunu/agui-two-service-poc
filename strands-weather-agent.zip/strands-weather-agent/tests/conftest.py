import pytest

from weather_agent.agent.stub_model import StubModel
from weather_agent.config import Settings, get_settings


@pytest.fixture(autouse=True)
def _reset():
    get_settings.cache_clear()
    StubModel._cache_warm = False
    yield
    get_settings.cache_clear()


@pytest.fixture
def settings() -> Settings:
    return Settings(
        _env_file=None,
        llm_provider="stub",
        otel_enabled=False,
        max_turns=6,
        max_tool_calls=8,
        max_calls_per_tool=4,
    )


GEO = {"results": [{"name": "Paris", "admin1": "Ile-de-France", "country": "France",
                    "latitude": 48.85, "longitude": 2.35, "timezone": "Europe/Paris"}]}
CURRENT = {"current": {"time": "2026-10-20T12:00", "weather_code": 3, "temperature_2m": 14.2,
                       "apparent_temperature": 12.9, "relative_humidity_2m": 70,
                       "precipitation": 0.0, "wind_speed_10m": 11.0}}


@pytest.fixture
def mock_weather(respx_mock):
    respx_mock.get("https://geocoding-api.open-meteo.com/v1/search").respond(json=GEO)
    respx_mock.get("https://api.open-meteo.com/v1/forecast").respond(json=CURRENT)
    return respx_mock
