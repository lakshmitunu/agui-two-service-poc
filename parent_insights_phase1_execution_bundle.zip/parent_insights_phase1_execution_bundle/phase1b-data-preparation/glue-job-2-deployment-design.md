# Glue Job 2 Production Deployment Design

## At a glance

### Input

| Input | Current value |
|---|---|
| Reviewed Glue source | `phase1b-data-preparation/daily_communication_curated_to_features.py` |
| Curated data format | Snappy-compressed Parquet |
| Curated run | `s3://vsf-parent-insights-curated/daily-communication/run_id=20260830T055411Z/data/` |
| Glue Job 1 summary | `s3://vsf-parent-insights-curated/daily-communication-validation/run_id=20260830T055411Z/summary.json` |
| Expected records | 600 |
| Glue execution role | `vsf-parent-insights-glue-role` |
| AWS profile and region | `parent-insights-personal`, `us-east-2` |
| First Job 2 release | `v1.0` |

### What the deployment does

1. Performs read-only checks of the AWS account, buckets, role, curated input, and Glue Job 1 summary.
2. Calculates the reviewed Python file's SHA-256 checksum.
3. Displays the exact deployment plan and waits for the operator to type `apply`.
4. Uploads or verifies an immutable `v1.0` script release in the artifact bucket.
5. Creates or updates the AWS Glue job and points it to that exact S3 script.
6. Displays the execution plan and waits for a separate `run` approval.
7. Starts Glue Job 2 only after the operator types `run`.
8. Waits for completion and displays the final state and validation summary.

### Output

| Output | Location |
|---|---|
| Versioned Glue script | `s3://vsf-parent-insights-artifacts/glue/jobs/daily-communication-curated-to-features/releases/v1.0/daily_communication_curated_to_features.py` |
| AWS Glue job | `vsf-parent-insights-curated-to-features` |
| Feature data | `s3://vsf-parent-insights-features/daily-communication/run_id=20260830T055411Z/data/` |
| Feature summary | `s3://vsf-parent-insights-features/daily-communication-validation/run_id=20260830T055411Z/summary.json` |
| Runtime logs | CloudWatch Logs for the Glue job run |

The feature data is Snappy-compressed Parquet. The summary is human-readable JSON.

## Deployment and execution flow

```mermaid
flowchart TD
    A["Run Job 2 deployment script"]
    B["Read-only AWS checks"]
    C["Verify curated Parquet prefix<br/>and Job 1 summary"]
    D["Calculate local script SHA-256"]
    E["Display artifact, Glue settings,<br/>input, and output plan"]
    F{"Operator types apply?"}
    G["Upload or verify immutable<br/>v1.0 Python artifact"]
    H["Verify uploaded checksum"]
    I["Create or update Glue Job 2"]
    J["Verify saved ScriptLocation"]
    K{"Operator types run?"}
    L["Start job with explicit run_id"]
    M["Glue downloads the exact<br/>versioned Python script"]
    N["Read validated curated Parquet"]
    O["Calculate 7-day and<br/>30-day features"]
    P["Validate feature counts<br/>and numeric safety"]
    Q["Publish feature Parquet"]
    R["Write JSON summary last"]
    S["Display final Glue state<br/>and output locations"]
    X["Stop without AWS changes"]
    Y["Leave job deployed;<br/>do not execute"]

    A --> B --> C --> D --> E --> F
    F -- No --> X
    F -- Yes --> G --> H --> I --> J --> K
    K -- No --> Y
    K -- Yes --> L --> M --> N --> O --> P --> Q --> R --> S
```

## 1. Files involved

### File that will be uploaded

```text
phase1b-data-preparation/daily_communication_curated_to_features.py
```

This file contains the Glue Job 2 feature calculations and S3 publication safeguards.

### Deployment script that will be created next

```text
phase1b-data-preparation/deploy_daily_communication_curated_to_features.sh
```

This shell script will perform the controlled upload, Glue job creation or update, approval prompts, execution, wait, and result display.

### Test files used before deployment

```text
phase1b-data-preparation/test_daily_communication_curated_to_features.py
phase1b-data-preparation/run_glue_job_2_tests.sh
```

The six local Spark tests must pass before a release is deployed.

## 2. Versioned artifact standard

The first release will use:

```text
s3://vsf-parent-insights-artifacts/
glue/jobs/daily-communication-curated-to-features/
releases/v1.0/
daily_communication_curated_to_features.py
```

Displayed as one URI:

```text
s3://vsf-parent-insights-artifacts/glue/jobs/daily-communication-curated-to-features/releases/v1.0/daily_communication_curated_to_features.py
```

Rules:

1. `v1.0` is a readable release identifier.
2. The source filename describes its purpose; it does not use `_1` or `_2`.
3. An existing release key must never be overwritten with different content.
4. SHA-256 verifies that the uploaded bytes match the locally reviewed file.
5. A code change requires a new version such as `v1.1`.
6. Rollback deliberately repoints the Glue job to an earlier verified release.

## 3. Glue job configuration

| Setting | Job 2 configuration | Reason |
|---|---|---|
| Job name | `vsf-parent-insights-curated-to-features` | Describes the transformation rather than using a sequence number. |
| Command | `glueetl` | The job uses Spark DataFrames and window calculations. |
| Glue runtime | `5.0` | Matches the locally tested Spark `3.5.4` behavior. |
| Python | Runtime Python 3 | Supplied by Glue 5.0. |
| IAM role | `vsf-parent-insights-glue-role` | Existing Phase 1 Glue execution role. |
| Worker type | `G.1X` | General-purpose worker suitable for the small Phase 1 feature workload. |
| Worker count | `2` | AWS Glue Spark requires a distributed driver/executor allocation; two is the small production starting point. |
| Maximum concurrency | `1` | Prevents two runs from publishing the same `run_id` simultaneously. |
| Retries | `0` | Contract and output-lock failures require investigation rather than blind retry. |
| Timeout | `30` minutes | Finite protection for a workload expected to finish much sooner. |
| Job bookmarks | Disabled | An explicit `run_id` selects the complete batch. |
| Metrics | Enabled | Supports operational monitoring. |
| Continuous logging | Enabled | Makes structured progress events available in CloudWatch. |

The initial capacity is intentionally small. Worker sizing can be revisited using actual execution time, worker utilization, shuffle size, and cost after the first successful run.

## 4. Runtime arguments

Stored as Glue job defaults:

```text
--curated_bucket=vsf-parent-insights-curated
--features_bucket=vsf-parent-insights-features
--job-bookmark-option=job-bookmark-disable
--enable-metrics=true
--enable-continuous-cloudwatch-log=true
```

Required for each execution:

```text
--run_id=<YYYYMMDDTHHMMSSZ>
```

For the current run:

```text
--run_id=20260830T055411Z
```

The `run_id` is not saved as a default. This prevents the Glue console's **Run** button from silently reprocessing an old run.

`JOB_NAME` and `JOB_RUN_ID` are supplied automatically by AWS Glue. The Python script must not register `JOB_RUN_ID` as a custom argument.

## 5. What happens when Job 2 executes

### Step 1: preflight the curated run

The job reads:

```text
s3://vsf-parent-insights-curated/daily-communication-validation/run_id=20260830T055411Z/summary.json
```

It verifies:

- the summary is valid JSON;
- `runId` matches the requested run;
- the Job 1 status is complete;
- `validOutputUri` points to the expected curated prefix;
- `validRecordCount` is positive;
- the curated Parquet prefix contains objects.

### Step 2: validate curated Parquet

The job verifies:

- all 12 curated columns exist;
- Parquet row count matches Job 1's `validRecordCount`;
- profile/date keys are not null;
- every profile/date key is unique.

### Step 3: calculate personalized features

For every profile/date record, the job calculates:

```text
7-day history:  D-7 through D-1
30-day history: D-30 through D-1
```

For calls, texts, night calls, and school-time calls, it adds:

```text
average
population standard deviation
current-minus-average difference
Z-score
```

It also adds history counts and readiness flags. The current day is excluded from its own history.

### Step 4: validate the output

The job verifies:

- output count equals input count;
- a 30-day-ready row is also 7-day ready;
- no numeric feature is NaN or infinite;
- zero standard deviation produces a null Z-score.

### Step 5: publish safely

The job first writes to a run-specific staging prefix. After validation succeeds, it copies the staged Parquet objects to the final prefix and writes `summary.json` last.

It refuses to overwrite either final output prefix for an existing `run_id`.

## 6. Expected result for the current run

### Feature Parquet

```text
s3://vsf-parent-insights-features/daily-communication/run_id=20260830T055411Z/data/
```

Expected counts:

```text
Input feature candidates:           600
Output feature rows:                600
Rows ready for 7-day features:      530
Rows ready for 30-day features:     300
Rows ready for both windows:        300
```

### Feature summary JSON

```text
s3://vsf-parent-insights-features/daily-communication-validation/run_id=20260830T055411Z/summary.json
```

Expected shape:

```json
{
  "runId": "20260830T055411Z",
  "jobRunId": "jr_example",
  "status": "COMPLETED",
  "inputUri": "s3://vsf-parent-insights-curated/daily-communication/run_id=20260830T055411Z/data/",
  "outputUri": "s3://vsf-parent-insights-features/daily-communication/run_id=20260830T055411Z/data/",
  "inputRecordCount": 600,
  "outputRecordCount": 600,
  "ready7dRecordCount": 530,
  "ready30dRecordCount": 300,
  "readyBothRecordCount": 300
}
```

## 7. Approval gates

### Gate 1: deployment approval

Before changing AWS, the deployment script will display:

- AWS account, caller, profile, and region;
- local source path and SHA-256;
- exact versioned S3 artifact URI;
- whether the artifact will be uploaded or reused;
- whether the Glue job will be created or updated;
- role, runtime, worker, timeout, and concurrency settings;
- curated input and feature output locations.

It will require:

```text
Type 'apply' to upload the artifact and create or update Glue Job 2:
```

Anything else stops without making the planned changes.

### Gate 2: execution approval

After deployment and verification, it will require:

```text
Type 'run' to execute Glue Job 2 for run_id=20260830T055411Z:
```

Anything else leaves the job deployed without starting it.

## 8. Operator command

After the deployment shell script is implemented, the operator will run:

```bash
cd /Volumes/work/codex_projects/parent_insights
bash ./phase1b-data-preparation/deploy_daily_communication_curated_to_features.sh \
  --release-version v1.0 \
  --run-id 20260830T055411Z
```

The equivalent AWS execution command will be:

```bash
aws glue start-job-run \
  --profile parent-insights-personal \
  --region us-east-2 \
  --job-name vsf-parent-insights-curated-to-features \
  --arguments '{"--run_id":"20260830T055411Z","--curated_bucket":"vsf-parent-insights-curated","--features_bucket":"vsf-parent-insights-features"}'
```

The deployment script—not the operator—will issue this command only after the operator types `run`.

## 9. IAM scope

Glue Job 2 needs:

- read/list access to the curated daily-communication and validation prefixes;
- write/list/delete access to its feature staging, final data, and validation prefixes;
- read access to its versioned script release in the artifact bucket;
- CloudWatch logging permissions.

The deployment identity uploads the script. The Glue execution role only reads it.

The Job 2 artifact-read inline policy must use its own policy name or safely extend the existing artifact policy. It must not remove Job 1's permission to read its deployed script.

## 10. Failure and recovery behavior

| Failure | Behavior |
|---|---|
| AWS dependency check fails | Stop before mutation. |
| Operator does not type `apply` | Make no planned AWS changes. |
| Release key exists with different bytes | Stop and require a new release version. |
| Upload checksum does not match | Do not create or update the job. |
| Operator does not type `run` | Leave the verified deployment in place; do not execute. |
| Curated summary or Parquet validation fails | Write no final feature output. |
| Feature calculation validation fails | Write no completion summary; remove staging objects. |
| Final publication fails | Remove newly copied final objects and staging objects. |
| Existing output is found for the run | Refuse to overwrite it. |
| Glue job fails | Preserve CloudWatch logs and display the Glue error message. |

## 11. Acceptance criteria

- All six local Spark tests pass before deployment.
- The deployed script checksum equals the reviewed local script checksum.
- Glue Job 2 points to the exact `v1.0` release, not a mutable `latest` path.
- The job cannot be intentionally launched by the deployment script without an explicit `run_id` and `run` approval.
- The curated bucket remains unchanged.
- The feature run publishes exactly 600 rows.
- Readiness counts are 530 for 7-day and 300 for 30-day/both.
- Output contains no NaN or infinite feature values.
- Feature output uses Snappy-compressed Parquet.
- The JSON validation summary is written only after feature Parquet publication succeeds.
- CloudWatch contains `CURATED_RUN_PREFLIGHT_PASSED`, `CURATED_RECORDS_VALIDATED`, `ROLLING_FEATURES_VALIDATED`, and `FEATURE_RUN_PUBLISHED` events.

## 12. Next implementation step

Create only:

```text
phase1b-data-preparation/deploy_daily_communication_curated_to_features.sh
```

Review that shell script before executing it. Creating the script will not itself upload an artifact, change AWS, or start the Glue job.
