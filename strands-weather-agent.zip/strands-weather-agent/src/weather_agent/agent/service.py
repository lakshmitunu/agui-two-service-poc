"""Runs one request through the agent and produces the full accounting record."""

import time
from dataclasses import asdict, dataclass

from strands.models import Model

from weather_agent.agent.factory import build_agent
from weather_agent.config import Settings
from weather_agent.observability.logging import get_logger, truncate
from weather_agent.observability.usage import Cost, TokenUsage, compute_cost

log = get_logger()


@dataclass
class AgentRun:
    answer: str
    stop_reason: str
    turns: int
    tool_calls: int
    tool_calls_blocked: int
    limit_hit: str | None
    latency_ms: int
    tokens: TokenUsage
    cost: Cost
    per_turn: list[dict]


async def run_agent(question: str, request_id: str, s: Settings, model: Model | None = None) -> AgentRun:
    log.info("request.received", question=truncate(question, s.log_message_chars), provider=s.llm_provider, model=s.model_id)
    agent, state = build_agent(s, request_id, model)

    started = time.perf_counter()
    result = await agent.invoke_async(question)
    latency_ms = round((time.perf_counter() - started) * 1000)

    invocation = result.metrics.agent_invocations[-1]
    tokens = TokenUsage.from_strands(invocation.usage)
    cost = compute_cost(tokens, s)

    # Per-model-call breakdown: shows the cache write on turn 1 and cache reads on later turns.
    per_turn = []
    for i, cycle in enumerate(invocation.cycles, start=1):
        t = TokenUsage.from_strands(cycle.usage)
        per_turn.append({"turn": i, **asdict(t), "cost_usd": compute_cost(t, s).total_usd})

    answer = "".join(b.get("text", "") for b in result.message.get("content", []))
    run = AgentRun(
        answer=answer,
        stop_reason=result.stop_reason,
        turns=state.turns,
        tool_calls=state.tool_calls,
        tool_calls_blocked=state.tool_calls_blocked,
        limit_hit=state.limit_hit,
        latency_ms=latency_ms,
        tokens=tokens,
        cost=cost,
        per_turn=per_turn,
    )
    log.info(
        "request.completed",
        stop_reason=run.stop_reason,
        turns=run.turns,
        tool_calls=run.tool_calls,
        tool_calls_blocked=run.tool_calls_blocked,
        limit_hit=run.limit_hit,
        latency_ms=latency_ms,
        input_tokens=tokens.input_tokens,
        output_tokens=tokens.output_tokens,
        cache_read_tokens=tokens.cache_read_tokens,
        cache_write_tokens=tokens.cache_write_tokens,
        cache_hit_ratio=tokens.cache_hit_ratio,
        cost_usd=cost.total_usd,
        uncached_equivalent_usd=cost.uncached_equivalent_usd,
        per_turn=per_turn,
    )
    return run
