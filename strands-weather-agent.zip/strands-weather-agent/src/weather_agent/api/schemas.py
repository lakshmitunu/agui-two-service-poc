from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000, examples=["What's the weather in Paris?"])


class UsageOut(BaseModel):
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int
    cache_write_tokens: int
    cache_hit_ratio: float
    cost_usd: float
    uncached_equivalent_usd: float
    cost_breakdown_usd: dict[str, float]
    per_turn: list[dict]


class ChatResponse(BaseModel):
    request_id: str
    provider: str
    answer: str
    stop_reason: str
    turns: int
    tool_calls: int
    tool_calls_blocked: int
    limit_hit: str | None
    latency_ms: int
    usage: UsageOut
