#!/usr/bin/env python3
import json
import random
from datetime import date, timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "profile-config.json"
OUTPUT_PATH = BASE_DIR / "daily-history.jsonl"


def nonnegative_gaussian(rng, mean, standard_deviation):
    return max(0, int(round(rng.gauss(mean, standard_deviation))))


def generate_record(rng, profile, activity_date):
    is_weekend = activity_date.weekday() >= 5

    if rng.random() < profile["inactiveDayProbability"]:
        call_count = 0
        text_count = 0
        night_count = 0
        school_count = 0
        status = "INACTIVE"
    else:
        status = "ACTIVE"
        call_mean = profile["averageCallsWeekend"] if is_weekend else profile["averageCallsWeekday"]
        text_mean = profile["averageTextsWeekend"] if is_weekend else profile["averageTextsWeekday"]

        call_count = nonnegative_gaussian(rng, call_mean, profile["callStandardDeviation"])
        text_count = nonnegative_gaussian(rng, text_mean, profile["textStandardDeviation"])

        night_deviation = max(0.5, profile["averageNightCalls"] * 0.5)
        night_count = min(
            call_count,
            nonnegative_gaussian(rng, profile["averageNightCalls"], night_deviation),
        )

        if is_weekend:
            school_count = 0
        else:
            school_deviation = max(0.5, profile["averageSchoolCallsWeekday"] * 0.35)
            school_count = nonnegative_gaussian(
                rng,
                profile["averageSchoolCallsWeekday"],
                school_deviation,
            )
            school_count = min(school_count, max(0, call_count - night_count))

    return {
        "childProfileId": profile["childProfileId"],
        "aggDate": activity_date.isoformat(),
        "timezone": profile["timezone"],
        "communicationStatus": status,
        "callCount": call_count,
        "textCount": text_count,
        "nightCount": night_count,
        "nightStartTime": profile["nightStartTime"],
        "nightEndTime": profile["nightEndTime"],
        "schoolCount": school_count,
        "schoolStartTime": profile["schoolStartTime"],
        "schoolEndTime": profile["schoolEndTime"],
    }


def validate(records, expected_profiles, expected_days):
    expected_count = expected_profiles * expected_days
    if len(records) != expected_count:
        raise ValueError(f"Expected {expected_count} records, found {len(records)}")

    keys = {(record["childProfileId"], record["aggDate"]) for record in records}
    if len(keys) != len(records):
        raise ValueError("Duplicate childProfileId + aggDate records found")

    for record in records:
        counts = [record["callCount"], record["textCount"], record["nightCount"], record["schoolCount"]]
        if any(not isinstance(value, int) or value < 0 for value in counts):
            raise ValueError(f"Invalid count in record: {record}")
        if record["nightCount"] + record["schoolCount"] > record["callCount"]:
            raise ValueError(f"Call subsets exceed callCount: {record}")
        if date.fromisoformat(record["aggDate"]).weekday() >= 5 and record["schoolCount"] != 0:
            raise ValueError(f"Weekend schoolCount must be zero: {record}")
        if record["communicationStatus"] == "INACTIVE" and any(counts):
            raise ValueError(f"Inactive record contains activity: {record}")


def main():
    config = json.loads(CONFIG_PATH.read_text())
    rng = random.Random(config["randomSeed"])
    start_date = date.fromisoformat(config["historyStartDate"])
    history_days = config["historyDays"]

    records = []
    for profile in config["profiles"]:
        for day_offset in range(history_days):
            records.append(generate_record(rng, profile, start_date + timedelta(days=day_offset)))

    validate(records, len(config["profiles"]), history_days)

    with OUTPUT_PATH.open("w", encoding="utf-8") as output:
        for record in records:
            output.write(json.dumps(record, separators=(",", ":")) + "\n")

    print(f"Generated {len(records)} records at {OUTPUT_PATH}")
    print(f"Profiles: {len(config['profiles'])}")
    print(f"Dates: {records[0]['aggDate']} through {records[-1]['aggDate']}")


if __name__ == "__main__":
    main()
