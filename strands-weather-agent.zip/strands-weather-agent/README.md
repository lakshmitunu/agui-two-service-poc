# Strands Weather Agent

A small, production-shaped agent built with the [Strands Agents SDK](https://strandsagents.com) to learn:
**agent loop limits, tool-call limits, prompt caching, structured logging, OpenTelemetry, and per-request token cost.**

Weather data comes from free public APIs (Open-Meteo, US NWS), no weather key needed.

```
POST /v1/chat  ->  Strands agent loop  <->  Claude
                        |  ^
                  tools |  | hooks (limits + logging)
                        v  |
              Open-Meteo / NWS      logs (JSON) + OTEL traces + token cost
```

Full diagrams for every concept, plus sequence diagrams: **[docs/architecture.md](docs/architecture.md)**.

## Quick start (Docker, no API key needed)

Requires Docker. `LLM_PROVIDER=stub` (the default) runs an offline scripted model, so the whole pipeline works before you have a key. The weather tools still call the real APIs.

```bash
./scripts/deploy.sh      # builds + starts agent, OTel collector, Jaeger; waits until healthy
./scripts/test.sh        # unit tests + smoke tests against the running container
```

Then try it:

```bash
curl -s localhost:8000/v1/chat -H 'content-type: application/json' \
  -d '{"message":"What is the weather in Paris?"}' | python3 -m json.tool
```

- API docs: http://localhost:8000/docs
- Traces: http://localhost:16686 (service `strands-weather-agent`)
- Logs: `docker compose logs -f agent`
- Stop: `docker compose down`

## Switching to real Claude (only `.env` changes)

```bash
# .env
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-...
MODEL_ID=claude-sonnet-5-5
```

```bash
./scripts/deploy.sh && ./scripts/test.sh
```

> With the stub, token counts and cache numbers are **synthetic** (they mimic a first-call cache write and later reads). Real numbers appear only with a real key. Update the `PRICE_*` values in `.env` to match current Anthropic pricing for your model.

## Layout

```
src/weather_agent/
  config.py                 all settings from env (limits, model, pricing, otel)
  main.py, api/             FastAPI app, request-id middleware, schemas
  agent/
    factory.py              builds the model (cache config) and one Agent per request
    service.py              runs a request, computes usage + cost, logs request.completed
    prompts.py              static system prompt (cache-friendly)
    stub_model.py           offline scripted model for key-less runs and tests
    hooks/limits.py         turn limit + tool-call limits
    hooks/logging_hook.py   reasoning / tool call / tool result logs
  tools/                    @tool functions: open_meteo.py, nws.py, registry in __init__.py
  clients/http.py           shared HTTP: timeout, retries, errors as data
  observability/            logging.py (structlog JSON), telemetry.py (OTEL), usage.py (cost)
tests/                      unit tests (stub model + mocked HTTP)
deploy/otel-collector.yaml  collector pipeline: OTLP in, Jaeger out
scripts/                    deploy.sh, test.sh
```

## Concepts and where to see them

| Concept | Where in code | How to observe it |
|---|---|---|
| **Turn limit** (`MAX_TURNS`) | `hooks/limits.py` `_before_model` sets `event.cancel` | send `[stub:loop] ...` with stub, set `MAX_TURNS=2`, see `limit_hit: max_turns` |
| **Tool-call limits** (`MAX_TOOL_CALLS`, `MAX_CALLS_PER_TOOL`) | `hooks/limits.py` `_before_tool` sets `event.cancel_tool` | `limit.hit` log line, `tool_calls_blocked` in the response |
| **Prompt caching** | `factory.py` `CacheConfig` (tools + system + last message) | `cache_write_tokens` on the first call, `cache_read_tokens` afterwards; `per_turn` shows it per model call |
| **Request logging** | `api/app.py` middleware, `service.py` | `request.received` with `request_id` |
| **Agent reasoning** | `hooks/logging_hook.py` | `agent.reasoning`: model text, `tool_requests`, `stop_reason` each turn |
| **OTEL** | `observability/telemetry.py` (Strands emits spans) | Jaeger: `invoke_agent` > `execute_event_loop_cycle` > `chat` / `execute_tool` |
| **Token cost** | `observability/usage.py` | `request.completed` log and `usage` in the response |

### Reading a request in the logs

Every line is JSON with `request_id` and `trace_id`. Filter one request:

```bash
docker compose logs agent --no-log-prefix | grep <request_id> | python3 -c "
import sys,json
for l in sys.stdin:
    d=json.loads(l); print(d['event'], {k:v for k,v in d.items() if k not in ('event','request_id','trace_id','span_id','timestamp','level')})"
```

Events in order: `request.received`, then per turn `model.call`, `agent.reasoning`, `tool.call`, `tool.result`, finally `request.completed` (tokens, cache, cost, per-turn breakdown). `limit.hit` appears when a guardrail fires.

### Token fields, and a trap

| Field | Meaning | Price |
|---|---|---|
| `input_tokens` | uncached input | base |
| `cache_write_tokens` | written to cache | base x 1.25 (5-minute TTL) |
| `cache_read_tokens` | served from cache | base x 0.1 |
| `output_tokens` | generated | output rate |

These four are disjoint. In OTEL spans, `gen_ai.usage.input_tokens` is the **sum** of the first three, so it will not match the API field of the same name. `cache_hit_ratio = cache_read / (input + cache_read + cache_write)`.

### Prompt caching gotchas

- Anthropic caches only prefixes above a minimum size (about 1024 tokens for Sonnet-class; some models need more). If you see zero cache tokens on a real key, the prefix is probably too small or changed between calls.
- The system prompt must be **static**. A timestamp in it would defeat the cache on every call.
- Entries expire after the TTL (5 minutes by default; set `CACHE_TTL=1h` for longer). Cache is shared across requests, so the first request after expiry pays the write again.

## Local development (no Docker)

```bash
uv sync
cp .env.example .env
uv run pytest
LOG_FORMAT=console OTEL_ENABLED=false uv run python -m weather_agent.main
```

## Extending

- **New tool:** add a `@tool` function in `src/weather_agent/tools/` and list it in `tools/__init__.py`. Return errors as data, never raise.
- **New limit:** add a counter to `RequestState` and a check in `LimitsHook`.
- **Bedrock instead of the direct API:** swap the model in `agent/factory.py:build_model`; nothing else changes.

## Not included on purpose

Auth, rate limiting per client, persistent conversation memory, streaming responses. They matter in production but would hide the concepts this project is meant to teach.
