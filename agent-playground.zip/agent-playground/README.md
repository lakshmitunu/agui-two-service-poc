# Agent Playground

A Streamlit chat playground for testing an agent API. Enter a session ID, a domain and (optionally) a port, ask a question, and the reply streams in live.

> Your agent, live and unfiltered.

## Features

- Session ID field with a "Generate new ID" button
- Domain and port inputs. The port defaults to `8081` when left blank
- Live streaming of the reply, with dancing dots until the first chunk arrives
- User and agent avatars: real photos, `assets/user.jpg` and `assets/agent.jpg` (512 px display copies; full-resolution crops are in `assets/originals/`). To use your own, replace those two files (png, jpg, jpeg, webp or svg; keep them square, about 512 px, because every message embeds the image)
- AI-generated-content disclaimer under the input
- Clear chat and Export transcript
- Readable errors when the server is unreachable or returns an HTTP error

## Requirements

- Python 3.9 or newer
- An agent API that streams its reply (see "API contract")

## Setup and run

Run these from inside the project folder.

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Windows (PowerShell):

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

The app opens at http://localhost:8501.

## Using it

1. Enter a **Domain**, for example `support`.
2. Leave **Port** blank to use `8081`, or enter another port.
3. Type a question and press Enter or the send button.

The app calls:

```
POST http://localhost:{port}/{domain}/chat/stream
```

The exact URL is shown under "Endpoint" in the sidebar.

## API contract

Request body (JSON):

```json
{ "session_id": "sess-1a2b3c4d", "question": "What's the status of order 48213?" }
```

Response: a streamed body, either

- plain chunked text, or
- Server-Sent Events (`Content-Type: text/event-stream`) with `data:` lines. A `data` value may be plain text or JSON containing a `content`, `text`, or `delta` field. `data: [DONE]` ends the stream.

If your API uses different field names, edit `stream_reply()` in `app.py`.

## Try it without a real agent

`mock_server.py` fakes the endpoint on port 8081 and streams a reply word by word.

Terminal 1:

```bash
python mock_server.py
```

Terminal 2:

```bash
streamlit run app.py
```

Use any domain, for example `support`.

## Project layout

```
app.py              Streamlit app (UI, styling, streaming client)
mock_server.py      Fake streaming API for local testing
requirements.txt    Python dependencies
assets/             Avatar images (user.jpg, agent.jpg, originals/, SVG fallbacks)
.streamlit/         Dark theme config
```

## Troubleshooting

- `no such file or directory: .venv/bin/streamlit`: you are not in the project folder, or you haven't created the virtual environment yet. Run the setup commands above from the project folder.
- "Couldn't reach ...": your agent isn't running, or the port is wrong.
- "The API returned 404": check the domain value.
- Port 8501 already in use: `streamlit run app.py --server.port 8502`

## Image credits

Both photos are from Unsplash and are free to use under the Unsplash License:

- `assets/user.jpg`: "a man in a blue shirt smiling at the camera", photo by Danny Postma (https://unsplash.com/photos/zNxOw2JFNKs)
- `assets/agent.jpg`: "a smiling woman wearing a headset at a computer", photo by BaljkanN 4 (https://unsplash.com/photos/wnpf3Q5pkXA)

They are placeholders. Replace them with your own images before any public release.
