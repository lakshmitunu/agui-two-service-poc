#!/usr/bin/env python3
import json
import unittest

from daily_communication_raw_to_curated import (
    CONTRACT_FIELDS,
    parse_and_validate_structure,
    validate_cross_fields,
    windows_overlap,
)


def valid_record():
    return {
        "childProfileId": 9001,
        "aggDate": "2026-06-04",
        "timezone": "America/New_York",
        "communicationStatus": "ACTIVE",
        "callCount": 12,
        "textCount": 25,
        "nightCount": 3,
        "nightStartTime": "21:00",
        "nightEndTime": "06:00",
        "schoolCount": 5,
        "schoolStartTime": "08:00",
        "schoolEndTime": "15:00",
    }


def parsed_values(record):
    result = parse_and_validate_structure(json.dumps(record))
    return dict(zip(CONTRACT_FIELDS, result[:-1])), result[-1]


class StructuralValidationTests(unittest.TestCase):
    def test_valid_record_has_no_reasons(self):
        values, reasons = parsed_values(valid_record())
        self.assertEqual([], reasons)
        self.assertEqual(9001, values["childProfileId"])

    def test_malformed_json(self):
        result = parse_and_validate_structure("{not-json")
        self.assertEqual(["MALFORMED_JSON"], result[-1])

    def test_non_object_json_is_malformed(self):
        result = parse_and_validate_structure("[1,2,3]")
        self.assertEqual(["MALFORMED_JSON"], result[-1])

    def test_missing_and_unexpected_fields(self):
        record = valid_record()
        del record["textCount"]
        record["displayName"] = "Example Child"
        _, reasons = parsed_values(record)
        self.assertIn("MISSING_FIELD:textCount", reasons)
        self.assertIn("UNEXPECTED_FIELD:displayName", reasons)

    def test_string_decimal_and_boolean_are_not_integers(self):
        for invalid_value in ("12", 12.5, True):
            with self.subTest(invalid_value=invalid_value):
                record = valid_record()
                record["callCount"] = invalid_value
                values, reasons = parsed_values(record)
                self.assertIsNone(values["callCount"])
                self.assertIn("INVALID_TYPE:callCount", reasons)

    def test_invalid_date_time_timezone_status_and_negative_count(self):
        record = valid_record()
        record.update(
            {
                "aggDate": "2026-02-30",
                "timezone": "EST",
                "communicationStatus": "UNKNOWN",
                "callCount": -1,
                "nightStartTime": "25:00",
            }
        )
        _, reasons = parsed_values(record)
        self.assertIn("INVALID_DATE", reasons)
        self.assertIn("INVALID_TIMEZONE", reasons)
        self.assertIn("INVALID_COMMUNICATION_STATUS", reasons)
        self.assertIn("NEGATIVE_COUNT:callCount", reasons)
        self.assertIn("INVALID_TIME:nightStartTime", reasons)


class CrossFieldValidationTests(unittest.TestCase):
    def cross_reasons(self, record):
        return validate_cross_fields(*[record[field] for field in CONTRACT_FIELDS])

    def test_cross_midnight_night_window_does_not_overlap_school(self):
        self.assertFalse(windows_overlap("21:00", "06:00", "08:00", "15:00"))

    def test_touching_windows_do_not_overlap(self):
        self.assertFalse(windows_overlap("06:00", "08:00", "08:00", "15:00"))

    def test_overlapping_windows_are_detected(self):
        self.assertTrue(windows_overlap("06:00", "09:00", "08:00", "15:00"))

    def test_subset_counts_and_disjoint_sum(self):
        record = valid_record()
        record.update({"callCount": 4, "nightCount": 5, "schoolCount": 3})
        reasons = self.cross_reasons(record)
        self.assertIn("NIGHT_COUNT_EXCEEDS_CALL_COUNT", reasons)
        self.assertIn("DISJOINT_WINDOW_COUNTS_EXCEED_CALL_COUNT", reasons)

    def test_invalid_negative_prerequisite_does_not_create_secondary_reason(self):
        record = valid_record()
        record.update({"callCount": -1, "nightCount": 0, "schoolCount": 0})
        reasons = self.cross_reasons(record)
        self.assertNotIn("NIGHT_COUNT_EXCEEDS_CALL_COUNT", reasons)
        self.assertNotIn("SCHOOL_COUNT_EXCEEDS_CALL_COUNT", reasons)
        self.assertNotIn("DISJOINT_WINDOW_COUNTS_EXCEED_CALL_COUNT", reasons)

    def test_inactive_record_with_activity(self):
        record = valid_record()
        record["communicationStatus"] = "INACTIVE"
        self.assertIn("INACTIVE_WITH_ACTIVITY", self.cross_reasons(record))

    def test_weekend_school_activity(self):
        record = valid_record()
        record["aggDate"] = "2026-05-30"
        self.assertIn("WEEKEND_SCHOOL_ACTIVITY", self.cross_reasons(record))


if __name__ == "__main__":
    unittest.main()
