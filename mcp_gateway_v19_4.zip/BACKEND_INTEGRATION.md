# V19 backend integration

The HTML is a frontend. These are proposed contracts for your existing backend, not a deployed service. There are no simulated keys, sessions, verification results, or unmasked responses. The original V18.8 pages and endpoints remain unchanged.

## Configure routes

Defaults are same-origin. Before the application script, optionally set:

```html
<script>
window.MCP_AGENT_CREATE_ENDPOINT = '/api/agents';
window.MCP_CONTROL_PLANE_ENDPOINTS = {
  verify: '/api/mcp/verify',
  test: '/api/mcp/test',
  sessions: '/api/sessions'
};
</script>
```

Requests use JSON, `credentials: 'same-origin'`, and `cache: 'no-store'`. Session requests send the entered key in `x-api-key`; MCP requests send either `x-api-key` or `Authorization: Bearer …`, according to the selected authentication mode. Backend validation, authorization, CSRF handling, gateway destination allowlisting, timeouts, and audit logging belong in your integration. Cross-origin route overrides require appropriate CORS and authentication support.

## Agent creation

`POST /api/agents`

```json
{"name":"support-agent","owner":"Team","description":"Customer support","tools":["pause_internet"]}
```

Success:

```json
{"agent":{"id":"ag-123","createdAt":"2026-10-31T12:00:00Z","expiresAt":null,"status":"ACTIVE"},"apiKey":"BACKEND_ISSUED_KEY"}
```

`agent.id` and `apiKey` must be nonempty strings. No expiry is collected or sent. The table retains Expires At for an optional backend value. The key is displayed only after success, with Copy and Done controls. Keys are cleared on navigation, dismissal, page exit, or starting another creation. Only an allowlist of agent metadata and the current tool registry is cached locally. Enforce actual one-time credential disclosure on the backend. An uncertain response is not automatically retried.

## Verify gateway

`POST /api/mcp/verify`

```json
{"endpoint":"https://gateway.example.com/mcp","authType":"x-api-key"}
```

Success:

```json
{"connected":true,"tools":[{"name":"pause_internet"}]}
```

The frontend only reports verified when `connected` is exactly true. `tools` may contain tool-name strings or objects with a name. The backend performs MCP transport/protocol negotiation and discovery. No direct gateway request is made by the HTML. Only HTTPS endpoint URLs without embedded credentials, query strings, or fragments are accepted by this UI.

## Test message

`POST /api/mcp/test`

```json
{"endpoint":"https://gateway.example.com/mcp","authType":"x-api-key","message":"List the tools available to this agent"}
```

Success:

```json
{"response":"The agent can use pause_internet."}
```

This is an application-level test endpoint, not a native MCP message. Your backend supplies any agent/LLM orchestration needed to interpret the message. `authType` can also be `bearer`.

## Create session

`POST /api/sessions`

```json
{"customerId":"customer-123","ttlSeconds":600,"maskingMode":"deterministic","includeMapping":false,"sessionId":"optional-client-id"}
```

Customer ID and API Key are mandatory. The key is sent in the `x-api-key` header, not the JSON body. Session TTL is entered in minutes (default 10, range 1–1440) and converted to seconds for the request. Include Mapping is an optional unchecked checkbox, transmitted as a boolean. Blank Session ID is omitted. Agent ID and initial message are not collected.

Masking uses the existing styled dropdown component with `deterministic`, `deterministic_presidio`, and `deterministic_presidio_comprehend` values. Map these contract values to your backend as needed.

Success:

```json
{"sessionId":"s-123"}
```

The frontend also accepts the previously documented `{ "session": { "id": "s-123" } }` response with optional session metadata. On success, it displays formatted JSON containing `sessionId` and populates the unmask Session ID. Optional `maskedResponse` still populates the unmask response field. No client-side ID or successful response is fabricated. Include Mapping is forwarded to your backend; this UI displays only the returned session ID, not mapping contents.

The Sample cURL disclosure is intentionally a placeholder pending your backend example. It contains no invented command or credentials.

## List sessions

`GET /api/sessions`

```json
{"sessions":[{"id":"s-123","agentId":"ag-123","createdAt":"2026-10-31T12:00:00Z","expiresAt":"2026-10-31T13:00:00Z","status":"ACTIVE","maskingMode":"deterministic"}]}
```

Refresh loads this list. Search, Inspect and Use in Playground operate on the returned metadata. Inspect does not fetch conversation history. Backend controls which records the caller can see. This version expects the complete list, with no pagination contract.

## Unmask response

`POST /api/sessions/{encoded-session-id}/unmask`

```json
{"response":"Hello [NAME_1]"}
```

Success:

```json
{"response":"Hello Example"}
```

Backend must check session ownership, TTL, separate unmask authorization and audit requirements. Use HTTP 401/403 for authentication/authorization failures. A successful HTTP response with a string `response` is displayed as plain text. It is never cached. Hide response, editing the session/key/response input, switching to the session list, or leaving the page clears the revealed result. Late responses after navigation are discarded.

## Client configuration template

The MCP page generates a JSON template with `YOUR_AGENT_KEY`; actual keys are not inserted. Adapt the transport and configuration schema to your client. It is a generic template, not a guarantee that every MCP client accepts this format.

## Validation limits

All inline JavaScript passes syntax checks. Isolated tests using DOM stubs and simulated backend responses cover success, errors, validation, metadata allowlists, copy fallback, sensitive-data clearing, and suppression of late responses. HTML IDs, navigation targets, original page preservation, and ZIP integrity are checked. Browser rendering and live backend integration remain unverified; the local-file browser preview was blocked by browser security policy.

## V19.2: Local configuration generation

Get Configuration makes no network request. A nonempty agent key generates the client configuration locally and reveals Remove → Add → Verify → Try. The entered key is included in the copyable configuration, never persisted, and cleared from the generated configuration on key edits or navigation. Generation does not validate credentials.

Set `window.MCP_GATEWAY_URL` before the application script to your actual gateway URL. If unset, the template uses `https://YOUR_GATEWAY_HOST/mcp`; replace that placeholder before connecting. No `/api/mcp/configuration` endpoint is required. Verify and Try retain the previously documented backend contracts.

The architecture is an embedded SVG based on the supplied dark reference: control plane, data plane, central gateway, connected components and capability badges. It is open by default and scrolls horizontally on narrow screens.

## V19.4 command cards

Get Configuration generates four copyable Claude Code commands locally: remove nexusai, add nexusai with HTTP transport and the entered key, list/get to verify, and start Claude with a sample prompt shown as a comment. Commands are never executed by this HTML. Set window.MCP_GATEWAY_URL or replace the URL placeholder in the copied command. All command cards use equal dimensions. Command syntax reference: https://code.claude.com/docs/en/mcp . The architecture title is MCP Gateway Architecture and the diagram renders at full width.
