"""Entrypoint: `uvicorn weather_agent.main:app` or `python -m weather_agent.main`."""

import uvicorn

from weather_agent.api.app import app

__all__ = ["app"]

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, log_config=None)
