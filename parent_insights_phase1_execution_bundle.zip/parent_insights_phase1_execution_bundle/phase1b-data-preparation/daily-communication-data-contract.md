# VSF Parent Insights - Daily Communication Data Contract

## Purpose

Define one consistent daily communication record per child profile for historical-data preparation and machine-learning feature generation.

## Record grain

One record represents one child profile on one calendar date in the profile's configured timezone.

The unique record key is:

```text
childProfileId + aggDate
```

## Fields

| Field | Type | Required | Definition |
|---|---|---:|---|
| `childProfileId` | integer | Yes | Synthetic or pseudonymous child-profile identifier. |
| `aggDate` | date string | Yes | Activity date in `YYYY-MM-DD` format. |
| `timezone` | string | Yes | IANA timezone, such as `America/New_York`. |
| `communicationStatus` | string | Yes | `ACTIVE` or `INACTIVE`. |
| `callCount` | integer | Yes | Total calls during the activity date. |
| `textCount` | integer | Yes | Total texts during the activity date. |
| `nightCount` | integer | Yes | Calls occurring inside the configured night window. |
| `nightStartTime` | time string | Yes | Inclusive night-window start in `HH:MM` 24-hour format. |
| `nightEndTime` | time string | Yes | Exclusive night-window end in `HH:MM` 24-hour format. The window may cross midnight. |
| `schoolCount` | integer | Yes | Calls occurring inside the configured school window. |
| `schoolStartTime` | time string | Yes | Inclusive school-window start in `HH:MM` 24-hour format. |
| `schoolEndTime` | time string | Yes | Exclusive school-window end in `HH:MM` 24-hour format. |

## Validation rules

1. There must be exactly one record per `childProfileId` and `aggDate`.
2. All counts must be whole numbers greater than or equal to zero.
3. `nightCount` must be less than or equal to `callCount`.
4. `schoolCount` must be less than or equal to `callCount`.
5. If the night and school windows do not overlap, `nightCount + schoolCount` must be less than or equal to `callCount`.
6. If `communicationStatus` is `INACTIVE`, all four counts must be zero.
7. `aggDate` must be a valid calendar date.
8. Time values must use 24-hour `HH:MM` format.
9. `timezone` must be a recognized IANA timezone. Abbreviations such as `EST` are not accepted.
10. Unexpected fields are rejected from the curated ML record.

Cross-field rules such as `nightCount <= callCount` are enforced by the data-validation job because standard JSON Schema does not compare two fields directly.

## Valid example

```json
{
  "childProfileId": 9001,
  "aggDate": "2026-06-04",
  "timezone": "America/New_York",
  "communicationStatus": "ACTIVE",
  "callCount": 12,
  "textCount": 25,
  "nightCount": 3,
  "nightStartTime": "21:00",
  "nightEndTime": "06:00",
  "schoolCount": 5,
  "schoolStartTime": "08:00",
  "schoolEndTime": "15:00"
}
```

## Fields deliberately excluded

The first model does not use identity/display fields, watchlist data, source trend percentages, screen time, security, location, driving, or events.

Rolling averages, percentage changes, persistence, ratios, and anomaly scores will be calculated later from these daily measurements.
