"""Offline scripted model (LLM_PROVIDER=stub). NOT an LLM: a tiny deterministic state machine that
speaks the same streaming protocol as a real provider, so you can exercise the full pipeline
(hooks, limits, logging, OTEL spans, usage/cost, Docker) without an API key.

Behaviour:
  1. no tool results yet      -> reasoning text + geocode_location(<city parsed from message>)
  2. geocode done             -> reasoning text + get_current_weather(lat, lon)
  3. weather done             -> final answer built from the tool result
  Message containing "[stub:loop]" never finishes: it keeps calling tools, which is how you
  trigger the turn / tool-call limits on demand.

Token usage is SYNTHETIC (clearly flagged by provider=stub in the response): the first call in the
process reports a cache write, later calls report cache reads, mimicking real caching.
"""

import ast
import json
import re
import uuid
from collections.abc import AsyncIterable
from typing import Any

from strands.models import Model

SYNTHETIC_PREFIX_TOKENS = 1500  # pretend size of tools + system prompt


def _blocks(messages: list[dict], key: str) -> list[dict]:
    return [b[key] for m in messages for b in m.get("content", []) if key in b]


def _parse_result(tool_result: dict) -> dict:
    for block in tool_result.get("content", []):
        if "json" in block:
            return block["json"]
        if "text" in block:
            for loader in (json.loads, ast.literal_eval):
                try:
                    parsed = loader(block["text"])
                    if isinstance(parsed, dict):
                        return parsed
                except Exception:  # noqa: BLE001
                    continue
    return {}


class StubModel(Model):
    _cache_warm = False  # process-wide, like a provider-side cache

    def __init__(self, **config: Any) -> None:
        self.config: dict[str, Any] = {"model_id": "stub-weather-model", **config}

    def update_config(self, **model_config: Any) -> None:
        self.config.update(model_config)

    def get_config(self) -> Any:
        return self.config

    def structured_output(self, output_model, prompt, system_prompt=None, **kwargs):  # type: ignore[override]
        raise NotImplementedError("StubModel does not support structured output")

    # ------------------------------------------------------------------
    def _decide(self, messages: list[dict]) -> tuple[str, str | None, dict | None]:
        """Return (reasoning_text, tool_name | None, tool_input | None)."""
        first_user = next((m for m in messages if m["role"] == "user"), {"content": []})
        question = " ".join(b.get("text", "") for b in first_user["content"])
        used = [b["name"] for b in _blocks(messages, "toolUse")]
        results = [_parse_result(r) for r in _blocks(messages, "toolResult")]

        if "[stub:loop]" in question:
            return "I will keep checking the weather again to be sure.", "get_current_weather", {
                "latitude": 0.0,
                "longitude": 0.0,
            }
        if "geocode_location" not in used:
            m = re.search(r"\b(?:in|for|at)\s+([A-Z][\w .'-]*?)(?:[?.!,]|$)", question)
            city = (m.group(1).strip() if m else "London")
            return f"I need coordinates for {city} first.", "geocode_location", {"name": city}
        if "get_current_weather" not in used:
            geo = next((r["matches"][0] for r in results if r.get("matches")), None)
            if not geo:
                return "I could not find that place, so I cannot look up the weather.", None, None
            return "Now I have coordinates; fetching current conditions.", "get_current_weather", {
                "latitude": geo["latitude"],
                "longitude": geo["longitude"],
            }
        wx = next((r for r in results if "temperature_c" in r), {})
        if not wx:
            return "The weather service returned no usable data, so I cannot answer reliably.", None, None
        return (
            f"Right now it is {wx['temperature_c']} C with {wx['conditions']} "
            f"(feels like {wx['feels_like_c']} C, wind {wx['wind_kmh']} km/h). [stub model answer]",
            None,
            None,
        )

    async def stream(self, messages, tool_specs=None, system_prompt=None, *, tool_choice=None,
                     system_prompt_content=None, invocation_state=None, **kwargs) -> AsyncIterable[dict]:  # type: ignore[override,misc]
        text, tool_name, tool_input = self._decide(messages)
        yield {"messageStart": {"role": "assistant"}}
        yield {"contentBlockStart": {"start": {}}}
        yield {"contentBlockDelta": {"delta": {"text": text}}}
        yield {"contentBlockStop": {}}
        if tool_name:
            yield {"contentBlockStart": {"start": {"toolUse": {"toolUseId": f"stub-{uuid.uuid4().hex[:12]}", "name": tool_name}}}}
            yield {"contentBlockDelta": {"delta": {"toolUse": {"input": json.dumps(tool_input)}}}}
            yield {"contentBlockStop": {}}
        yield {"messageStop": {"stopReason": "tool_use" if tool_name else "end_turn"}}

        usage: dict[str, int] = {"inputTokens": 40 + 25 * len(messages), "outputTokens": 30 + len(text) // 4}
        if StubModel._cache_warm:
            usage["cacheReadInputTokens"] = SYNTHETIC_PREFIX_TOKENS
        else:
            usage["cacheWriteInputTokens"] = SYNTHETIC_PREFIX_TOKENS
            StubModel._cache_warm = True
        usage["totalTokens"] = sum(usage.values())
        yield {"metadata": {"usage": usage, "metrics": {"latencyMs": 5}}}
