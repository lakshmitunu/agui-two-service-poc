"""FastAPI app: request-id middleware, health probes, and POST /v1/chat."""

import uuid
from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI, HTTPException, Request

from weather_agent import __version__
from weather_agent.agent.service import run_agent
from weather_agent.api.schemas import ChatRequest, ChatResponse, UsageOut
from weather_agent.config import get_settings
from weather_agent.observability.logging import configure_logging, get_logger
from weather_agent.observability.telemetry import setup_telemetry

log = get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    configure_logging(s)
    setup_telemetry(s)
    log.info(
        "service.started",
        version=__version__,
        provider=s.llm_provider,
        model=s.model_id,
        max_turns=s.max_turns,
        max_tool_calls=s.max_tool_calls,
        max_calls_per_tool=s.max_calls_per_tool,
        prompt_caching=s.prompt_caching_enabled,
    )
    yield
    log.info("service.stopped")


app = FastAPI(title="Strands Weather Agent", version=__version__, lifespan=lifespan)


@app.middleware("http")
async def request_context(request: Request, call_next):
    request_id = request.headers.get("x-request-id") or uuid.uuid4().hex
    structlog.contextvars.clear_contextvars()
    structlog.contextvars.bind_contextvars(request_id=request_id)
    request.state.request_id = request_id
    response = await call_next(request)
    response.headers["x-request-id"] = request_id
    return response


@app.get("/healthz")
async def healthz():
    return {"status": "ok", "version": __version__}


@app.get("/readyz")
async def readyz():
    s = get_settings()
    if s.llm_provider == "anthropic" and s.anthropic_api_key is None:
        raise HTTPException(503, "ANTHROPIC_API_KEY not configured")
    return {"status": "ready", "provider": s.llm_provider, "model": s.model_id}


@app.post("/v1/chat", response_model=ChatResponse)
async def chat(body: ChatRequest, request: Request) -> ChatResponse:
    s = get_settings()
    request_id = request.state.request_id
    try:
        run = await run_agent(body.message, request_id, s)
    except Exception as e:  # noqa: BLE001 - last-resort boundary; details go to logs, not the client
        log.exception("request.failed", error=type(e).__name__)
        raise HTTPException(502, f"agent failed: {type(e).__name__}") from e
    t, c = run.tokens, run.cost
    return ChatResponse(
        request_id=request_id,
        provider=s.llm_provider,
        answer=run.answer,
        stop_reason=run.stop_reason,
        turns=run.turns,
        tool_calls=run.tool_calls,
        tool_calls_blocked=run.tool_calls_blocked,
        limit_hit=run.limit_hit,
        latency_ms=run.latency_ms,
        usage=UsageOut(
            input_tokens=t.input_tokens,
            output_tokens=t.output_tokens,
            cache_read_tokens=t.cache_read_tokens,
            cache_write_tokens=t.cache_write_tokens,
            cache_hit_ratio=t.cache_hit_ratio,
            cost_usd=c.total_usd,
            uncached_equivalent_usd=c.uncached_equivalent_usd,
            cost_breakdown_usd={
                "input": c.input_usd,
                "output": c.output_usd,
                "cache_write": c.cache_write_usd,
                "cache_read": c.cache_read_usd,
            },
            per_turn=run.per_turn,
        ),
    )
