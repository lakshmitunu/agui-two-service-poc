# Glue Job 2 Design: Personalized Rolling Features

## 1. Purpose

Glue Job 2 converts validated daily communication measurements into personalized historical features for anomaly detection.

It does not decide that a record is anomalous and does not train a model. It calculates evidence that the later rolling-Z-score baseline and Isolation Forest can use.

```text
Validated daily Parquet
→ compare each completed day with that child's earlier days
→ calculate 7-day and 30-day behavior features
→ feature Parquet for modeling
```

## 2. Input

### Input location

For the current completed run:

```text
s3://vsf-parent-insights-curated/daily-communication/
run_id=20260830T055411Z/data/
```

The input is Snappy-compressed Parquet produced by Glue Job 1.

### Input shape

```text
10 child profiles
× 60 completed daily records per profile
= 600 records
```

Each profile has one record for every date from `2026-04-06` through `2026-06-04`.

### Example input record

This is a JSON representation of one input Parquet row:

```json
{
  "childProfileId": 9001,
  "aggDate": "2026-06-04",
  "timezone": "America/New_York",
  "communicationStatus": "ACTIVE",
  "callCount": 13,
  "textCount": 22,
  "nightCount": 2,
  "nightStartTime": "21:00",
  "nightEndTime": "06:00",
  "schoolCount": 2,
  "schoolStartTime": "08:00",
  "schoolEndTime": "15:00"
}
```

The production input is Parquet. JSON is used in this document only because it is easier for a person to read.

## 3. Output

### Output location and format

```text
s3://vsf-parent-insights-features/daily-communication/
run_id=20260830T055411Z/data/
```

The production output will also be Snappy-compressed Parquet. One output row is produced for every input profile/date row, so the expected output is 600 rows.

The complete JSON example in section 7 represents one output Parquet row.

## 4. Processing flow

```mermaid
flowchart TD
    A["Validated daily Parquet<br/>600 profile/date rows"]
    B["For each profile/date,<br/>identify earlier calendar days"]
    C["Count available days in<br/>7-day and 30-day windows"]
    D["Mark each window<br/>ready or warming up"]
    E["Calculate rolling averages"]
    F["Calculate population<br/>standard deviations"]
    G["Calculate current-minus-average<br/>differences"]
    H["Calculate personalized Z-scores"]
    I["Preserve original daily fields<br/>and append features"]
    J["Write Snappy feature Parquet"]

    A --> B --> C --> D --> E --> F --> G --> H --> I --> J
```

## 5. Window rules

For a record dated `D`:

```text
7-day history:  D-7 through D-1
30-day history: D-30 through D-1
Current day:    D, excluded from both histories
```

These are calendar-day windows, not merely the previous seven or thirty available rows.

The current day is excluded to prevent data leakage. A value must not influence the historical baseline used to evaluate itself.

### Readiness rules

```text
featuresReady7d  = true only when all 7 earlier calendar days exist
featuresReady30d = true only when all 30 earlier calendar days exist
```

When a window is not ready, its average, standard deviation, difference, and Z-score fields are `null`.

For each 60-day profile:

```text
Days 1–7:   neither window is ready
Days 8–30:  7-day ready; 30-day warming up
Days 31–60: both windows are ready
```

Across ten profiles:

```text
Total feature rows:                 600
Rows with complete 7-day history:   530
Rows with complete 30-day history:  300
Rows ready for both windows:         300
```

## 6. Real example, step by step

The example evaluates profile `9001` on `2026-06-04`, its 60th record.

### Step 1: retain today's measurements

```text
callCount:   13
textCount:   22
nightCount:   2
schoolCount:  2
```

Why: these are the current observations being compared with personal history. The later model needs both the current values and their historical context.

### Step 2: select the earlier 7 calendar days

For calls, the history is:

| Date | `callCount` |
|---|---:|
| 2026-05-28 | 8 |
| 2026-05-29 | 9 |
| 2026-05-30 | 6 |
| 2026-05-31 | 10 |
| 2026-06-01 | 7 |
| 2026-06-02 | 11 |
| 2026-06-03 | 9 |

June 4's value of 13 is not included.

### Step 3: count history and mark readiness

```text
historyDays7d:      7
historyDays30d:    30
featuresReady7d: true
featuresReady30d: true
```

Why: readiness prevents a partial window from being mistaken for a complete baseline. It also lets model training select comparable rows.

### Step 4: calculate the average

For 7-day calls:

```text
callCountAvg7d
= (8 + 9 + 6 + 10 + 7 + 11 + 9) / 7
= 60 / 7
= 8.5714
```

For 30-day calls:

```text
callCountAvg30d = 9.4000
```

Why: the average estimates the child's recent normal level. The 7-day average reacts quickly; the 30-day average is more stable.

### Step 5: calculate population standard deviation

Formula for a window containing `N` days:

```text
standard deviation
= square root of [sum((historical value - average)²) / N]
```

For calls:

```text
callCountStd7d:  1.5908
callCountStd30d: 1.9596
```

Why: standard deviation measures this child's normal variability. The same difference is more unusual for a consistent child than for a naturally variable child.

### Step 6: calculate current-minus-average difference

Formula:

```text
difference = current value - historical average
```

For calls:

```text
callCountDifference7d  = 13 - 8.5714 = 4.4286
callCountDifference30d = 13 - 9.4000 = 3.6000
```

Why: the difference preserves direction and size in the original unit. Positive means above normal; negative means below normal.

### Step 7: calculate the personalized Z-score

Formula:

```text
Z-score = difference / historical standard deviation
```

For calls:

```text
callCountZScore7d  = 4.4286 / 1.5908 = 2.7839
callCountZScore30d = 3.6000 / 1.9596 = 1.8371
```

Why: Z-score expresses the difference in units of that child's normal variability. It makes behavior more comparable across children with different activity levels.

Interpretation:

```text
2.7839: calls are quite unusual compared with the recent week
1.8371: calls are elevated, but less unusual compared with the month
```

Glue Job 2 records this evidence; it does not create an alert.

### Step 8: repeat the same calculations for all four measurements

| Measurement | Current | Avg 7d | Std 7d | Difference 7d | Z 7d | Avg 30d | Std 30d | Difference 30d | Z 30d |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Calls | 13 | 8.5714 | 1.5908 | 4.4286 | 2.7839 | 9.4000 | 1.9596 | 3.6000 | 1.8371 |
| Texts | 22 | 25.1429 | 5.6170 | -3.1429 | -0.5595 | 26.7667 | 5.8917 | -4.7667 | -0.8090 |
| Night calls | 2 | 1.0000 | 0.5345 | 1.0000 | 1.8708 | 1.0333 | 0.5467 | 0.9667 | 1.7682 |
| School calls | 2 | 1.2857 | 1.0302 | 0.7143 | 0.6934 | 1.3333 | 0.9775 | 0.6667 | 0.6820 |

## 7. Complete example output record

Values are rounded here for readability. Parquet retains full double precision.

```json
{
  "childProfileId": 9001,
  "aggDate": "2026-06-04",
  "timezone": "America/New_York",
  "communicationStatus": "ACTIVE",

  "callCount": 13,
  "textCount": 22,
  "nightCount": 2,
  "nightStartTime": "21:00",
  "nightEndTime": "06:00",
  "schoolCount": 2,
  "schoolStartTime": "08:00",
  "schoolEndTime": "15:00",

  "historyDays7d": 7,
  "historyDays30d": 30,
  "featuresReady7d": true,
  "featuresReady30d": true,

  "callCountAvg7d": 8.5714,
  "callCountStd7d": 1.5908,
  "callCountDifference7d": 4.4286,
  "callCountZScore7d": 2.7839,
  "callCountAvg30d": 9.4000,
  "callCountStd30d": 1.9596,
  "callCountDifference30d": 3.6000,
  "callCountZScore30d": 1.8371,

  "textCountAvg7d": 25.1429,
  "textCountStd7d": 5.6170,
  "textCountDifference7d": -3.1429,
  "textCountZScore7d": -0.5595,
  "textCountAvg30d": 26.7667,
  "textCountStd30d": 5.8917,
  "textCountDifference30d": -4.7667,
  "textCountZScore30d": -0.8090,

  "nightCountAvg7d": 1.0000,
  "nightCountStd7d": 0.5345,
  "nightCountDifference7d": 1.0000,
  "nightCountZScore7d": 1.8708,
  "nightCountAvg30d": 1.0333,
  "nightCountStd30d": 0.5467,
  "nightCountDifference30d": 0.9667,
  "nightCountZScore30d": 1.7682,

  "schoolCountAvg7d": 1.2857,
  "schoolCountStd7d": 1.0302,
  "schoolCountDifference7d": 0.7143,
  "schoolCountZScore7d": 0.6934,
  "schoolCountAvg30d": 1.3333,
  "schoolCountStd30d": 0.9775,
  "schoolCountDifference30d": 0.6667,
  "schoolCountZScore30d": 0.6820
}
```

## 8. Attribute dictionary and anomaly purpose

### Original fields retained for lineage and interpretation

| Attribute | Description | Why retain it for anomaly work? |
|---|---|---|
| `childProfileId` | Child whose daily behavior is represented. | Ensures behavior is personalized and allows traceability. |
| `aggDate` | Completed calendar day being evaluated. | Establishes the event date and prevents future data from entering its history. |
| `timezone` | IANA timezone used for the daily boundary. | Explains which local calendar day the counts represent. |
| `communicationStatus` | `ACTIVE` or `INACTIVE`. | Helps interpret zeros; an inactive day may represent meaningful behavior. |
| `callCount` | Current day's total calls. | Primary current observation for call anomalies. |
| `textCount` | Current day's total texts. | Primary current observation for text anomalies. |
| `nightCount` | Current day's calls in the night window. | Detects changes in late-night communication behavior. |
| `nightStartTime` | Inclusive configured night start. | Preserves the definition used to create `nightCount`. |
| `nightEndTime` | Exclusive configured night end. | Preserves the definition used to create `nightCount`. |
| `schoolCount` | Current day's calls in the school window. | Detects changes in school-time communication behavior. |
| `schoolStartTime` | Inclusive configured school start. | Preserves the definition used to create `schoolCount`. |
| `schoolEndTime` | Exclusive configured school end. | Preserves the definition used to create `schoolCount`. |

### History and readiness fields

| Attribute | Calculation | Why needed? |
|---|---|---|
| `historyDays7d` | Count of earlier records from `D-7` through `D-1`. | Makes missing or incomplete recent history visible. |
| `historyDays30d` | Count of earlier records from `D-30` through `D-1`. | Makes missing or incomplete long-term history visible. |
| `featuresReady7d` | `historyDays7d == 7`. | Prevents partial seven-day statistics from entering comparable model rows. |
| `featuresReady30d` | `historyDays30d == 30`. | Identifies rows with a complete stable monthly baseline. |

### Feature suffix meanings

Every measurement—`callCount`, `textCount`, `nightCount`, and `schoolCount`—receives the same feature family.

| Suffix | Calculation | Anomaly-detection purpose |
|---|---|---|
| `Avg7d` | Average over `D-7` through `D-1`. | Fast-changing recent personal baseline. |
| `Std7d` | Population standard deviation over the earlier seven days. | Measures recent personal variability. |
| `Difference7d` | Current minus `Avg7d`. | Shows magnitude and direction in the original count unit. |
| `ZScore7d` | `Difference7d / Std7d`. | Shows how unusual today is relative to recent variability. |
| `Avg30d` | Average over `D-30` through `D-1`. | More stable long-term personal baseline. |
| `Std30d` | Population standard deviation over the earlier thirty days. | Measures longer-term personal variability. |
| `Difference30d` | Current minus `Avg30d`. | Shows long-term deviation in the original unit. |
| `ZScore30d` | `Difference30d / Std30d`. | Shows how unusual today is relative to longer-term variability. |

### Concrete feature fields

| Fields | Description and reason |
|---|---|
| `callCountAvg7d`, `callCountStd7d`, `callCountDifference7d`, `callCountZScore7d` | Recent call baseline, variability, raw deviation, and standardized unusualness. |
| `callCountAvg30d`, `callCountStd30d`, `callCountDifference30d`, `callCountZScore30d` | Stable call baseline and longer-term unusualness. |
| `textCountAvg7d`, `textCountStd7d`, `textCountDifference7d`, `textCountZScore7d` | Recent text baseline, variability, raw deviation, and standardized unusualness. |
| `textCountAvg30d`, `textCountStd30d`, `textCountDifference30d`, `textCountZScore30d` | Stable text baseline and longer-term unusualness. |
| `nightCountAvg7d`, `nightCountStd7d`, `nightCountDifference7d`, `nightCountZScore7d` | Detects short-term changes in night-call behavior. |
| `nightCountAvg30d`, `nightCountStd30d`, `nightCountDifference30d`, `nightCountZScore30d` | Detects whether night-call changes are also unusual over a month. |
| `schoolCountAvg7d`, `schoolCountStd7d`, `schoolCountDifference7d`, `schoolCountZScore7d` | Detects short-term changes in school-time calls. |
| `schoolCountAvg30d`, `schoolCountStd30d`, `schoolCountDifference30d`, `schoolCountZScore30d` | Detects whether school-time changes are also unusual over a month. |

## 9. Null and zero-variance behavior

If a window is not ready:

```text
average = null
standard deviation = null
difference = null
Z-score = null
```

If a complete window has standard deviation zero:

```text
average = calculated normally
standard deviation = 0
difference = calculated normally
Z-score = null
```

Division by zero must never produce infinity. The later baseline can treat a nonzero difference from a perfectly stable history as a separate strong signal.

## 10. Validation and acceptance criteria

For `run_id=20260830T055411Z`:

- input row count is 600;
- output row count is 600;
- profile/date remains unique;
- all 10 profiles remain present;
- each profile retains 60 dates;
- no feature for date `D` uses data from `D` or any future date;
- 530 rows have `featuresReady7d=true`;
- 300 rows have `featuresReady30d=true`;
- 300 rows have both readiness flags true;
- unready window features are null;
- no Z-score is infinite or NaN;
- output is Snappy-compressed Parquet;
- the curated input remains unchanged.

## 11. What happens after Glue Job 2

The feature dataset becomes the common input for:

```text
Baseline: rolling averages and Z-score rules
Candidate: Isolation Forest
```

Using the same feature records makes the comparison fair. Thresholds, anomaly labels, alert rules, and model training belong to later stages and are not responsibilities of Glue Job 2.
