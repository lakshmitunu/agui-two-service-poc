"""End-to-end agent loop with the stub model + mocked weather HTTP."""

from weather_agent.agent.service import run_agent


async def test_happy_path_uses_two_tools_and_reports_usage(settings, mock_weather):
    run = await run_agent("What's the weather in Paris?", "req-1", settings)
    assert run.limit_hit is None
    assert run.turns == 3 and run.tool_calls == 2
    assert "14.2" in run.answer
    assert run.tokens.cache_write_tokens > 0 and run.tokens.cache_read_tokens > 0  # write, then reads
    assert run.cost.total_usd > 0 and len(run.per_turn) == 3
    assert run.per_turn[0]["cache_write_tokens"] > 0 and run.per_turn[1]["cache_read_tokens"] > 0


async def test_turn_limit_stops_the_loop(settings, mock_weather):
    s = settings.model_copy(update={"max_turns": 2, "max_tool_calls": 50, "max_calls_per_tool": 50})
    run = await run_agent("[stub:loop] weather please", "req-2", s)
    assert run.limit_hit == "max_turns"
    assert run.turns == 2
    assert "limit" in run.answer.lower()


async def test_total_tool_limit_blocks_calls(settings, mock_weather):
    s = settings.model_copy(update={"max_turns": 10, "max_tool_calls": 2, "max_calls_per_tool": 50})
    run = await run_agent("[stub:loop] weather please", "req-3", s)
    assert run.tool_calls == 2
    assert run.tool_calls_blocked >= 1
    assert run.limit_hit in {"max_tool_calls", "max_turns"}


async def test_per_tool_limit(settings, mock_weather):
    s = settings.model_copy(update={"max_turns": 10, "max_tool_calls": 50, "max_calls_per_tool": 1})
    run = await run_agent("[stub:loop] weather please", "req-4", s)
    assert run.tool_calls == 1 and run.limit_hit == "max_calls_per_tool"
